function _worldItemSkin(it){
  if(!it)return null;
  let base=it.wtype||it.btype||it.slot||'';
  if(it.slot==='bonePart')base='bone_'+(it.part||'skull'); // 유골 부위: bone_*.png (2026-09-01)
  base=({ring1:'ring',ring2:'ring',headband:'earring',headband2:'earring'})[base]||base;
  const el=_ELKEY[it.el||0]||'phys';
  const src=_itemSkinSrc(base,el);
  const fallback=_itemSkinSrc(base,'phys');
  const cutoutSrc=_ITEM_CUTOUT_BASES.has(base)?'img/ui/item-cutouts/'+base+'_phys_cutout.png':'';
  const renderSrc=cutoutSrc||src;
  let img=_worldItemSkinCache.get(renderSrc);
  if(!img){
    img=new Image();
    img.onload=()=>{img._worldDropMasked=null;};
    if(renderSrc!==fallback)img.onerror=()=>{img.onerror=null;img._worldDropMasked=null;img.src=fallback;};
    img.src=renderSrc;_worldItemSkinCache.set(renderSrc,img);
  }
  if(!img.complete||!img.naturalWidth)return null;
  if(cutoutSrc)return img; // 알파가 보존된 투명 원화는 검정 마스킹을 다시 적용하지 않는다.
  if(!img._worldDropMasked){
    const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;
    canvas.getContext('2d').drawImage(img,0,0);
    img._worldDropMasked=_maskWorldDropBlack(canvas);
  }
  return img._worldDropMasked;
}
