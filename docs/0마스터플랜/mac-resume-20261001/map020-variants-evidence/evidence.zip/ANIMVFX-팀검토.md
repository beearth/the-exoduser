지정 경로를 읽겠습니다. 존재 여부부터 확인합니다.

도구 경로는 존재(3파일), outputs 경로는 미발견입니다. 도구 3파일을 읽고, outputs 상위 존재 여부도 확인하겠습니다.

도구 3파일을 모두 읽었고, `outputs/` 디렉터리는 **존재하지 않습니다**(Glob `outputs/**` 무결과 → smoke/관측 결과 산출물 미생성). 관측도구가 참조하는 실제 전역이 game.html에 존재하는지만 마지막으로 확인하겠습니다.

도구 3파일 Read를 완료했고 참조 전역의 game.html 실재를 확인했습니다. 아래 보고합니다.

## MAP020-followup 관측도구 Read 근거 / 계수차이 판정 / 잔여

### 1. 존재 파일 · 누락 (실제 Read)
| 경로 | 상태 |
|---|---|
| `tools/qa/map020-followup-observers/README.md` | **존재·Read 완료** (72줄) |
| `tools/qa/map020-followup-observers/observer.js` | **존재·Read 완료** (165줄, main-world classic-script 설치형) |
| `tools/qa/map020-followup-observers/smoke.mjs` | **존재·Read 완료** (98줄, Node vm 10테스트) |
| `outputs/map020-variants-20261001/observers/` | **누락** — `outputs/` 디렉터리 자체 부재(Glob `outputs/**` 무결과) |

**누락 명시**: smoke 결과 산출물·브라우저 관측 결과가 `outputs/…/observers/`에 **아직 없음**. smoke.mjs는 결과를 **stdout JSON으로만** 출력(96–98행)하고 파일을 쓰지 않으며, 브라우저 관측 결과는 README §5 "총괄 브라우저 실행 순서" 5단계에서 생성되는데 **아직 미실행**(브라우저 실행 금지·root 실게임 차례 전). 따라서 "smoke결과 Read"는 **파일 부재로 불가** — 산출물은 root 실게임 차례 후 생성·raw 제공 대상.

참조 전역 실재 확인(game.html): `update`(30583)·`draw`(2D 루프 50620 포함)·`_maskWorldDropBlack`/`_worldDropFxTile`/`_worldItemSkin`/`_worldItemSkinCache`(smoke가 실제 구간 추출)·`_ens8GLTotal`/`_dbgEns8GL`(4903, 리셋 5112, drawn대입 5215)·`_useGL`(4165)·`G.on`(30032)·`ens`(15783)·`_ensGLMode`·`PHYS_STEP`(58309) 전부 실재. 도구는 환각 심볼이 아님.

### 2. update / draw / rAF / GL / 사망·부활 계수차이 검토
observer.js는 직전 UI03 하니스의 추정 계수를 **실바인딩 계수로 교정**합니다(README §"실제 바인딩"·§"후보의 lexical 주장"이 UI03의 lexical-불가 단정을 명시적으로 철회).

| 계수 | observer.js 방식(Read 근거) | 직전 UI03 하니스 | 차이·판정 |
|---|---|---|---|
| **update** | `update` 식별자 직접 래핑(138) + 쓰기 identity 검증(33), finally에서 `updates++`(141). main-world classic-script라 `loop()` 내부 `update()` 호출(59542)까지 가로챔 | `_gameTime`÷PHYS_STEP 증분 **추정** | observer가 ground-truth. README §VFX update: `_gameTime` 증가로 호출수 추정 금지, early-return update도 호출로 계수 → **UI03 추정법 교정됨** |
| **draw** | `draw` 식별자 래핑(143), `draws++`(146) 실호출 계수 | (UI03 미계수) | 신설. GL60 vs 무제한에서 draw/update 분리 관측 가능 |
| **page rAF** | 도구 **독립 rAF**(148–149) `pageRafs++` — 게임 loop rAF와 별개 | 독립 rAF 동일 개념 | 동일 접근. cap60/240Hz 디스플레이에서 pageRafs(≈240)≠draws(≈60)≠updates(≈60) 분리(smoke 64–68: 2/2/3 검증) |
| **GL** | after-draw에서 `_ensGLMode===1 && _dbgEns8GL>0 && gate` 일 때만 `glDrawEvidence`(131). `_ens8GLTotal`은 **프레임 리셋 큐수**(5112 리셋)로 누적 아님을 README §GL근거가 명시 | `_ens8GLTotal>0‖_dbgEns8GL>0`를 glValid로 사용, `_ensGLMode`를 임의 rAF 시점 read | **교정 중요**: `_ensGLMode`는 _prepEnemyInstanced 진입 시 0 리셋(5111)→큐성공 시 1 → **반드시 after-draw에서 read**해야 유효. observer가 draw 전/후 위상 분리로 정확. `_ens8GLTotal`을 누적지표로 쓰면 오판 |
| **사망·부활** | death=`prev.alive&&!alive`(121). revive=`!prev.alive&&alive`→`awaitingDraw`(122). **첫 표시 프레임**은 after-update가 아니라 **부활 후 첫 draw**의 hf로 판정(126–132, smoke 69–75: before/after-draw 모두 hf===0). 신규 객체는 `first-observed-object`로만, **구울 자동분류 금지**(smoke 76–80) | alive flip된 **update 샘플**의 hf를 "부활 첫 프레임"으로 기록 | **교정 가장 중요**: README §사망·부활 "update 직후 샘플을 표시된 첫 화면으로 오인 금지". UI03은 update-flip을 첫 표시로 혼동 → observer는 첫 **렌더** 프레임으로 정정 |

보조 계수차이(플래시 수명): observer는 start/increase/zero를 **노출 상태전이 구간**으로만 기록하고 실제 hurtE 훅이 아니므로 한 update 내 재피격+감쇠가 합쳐질 수 있음을 README §플래시수명이 경고 → **강제 ≈100ms PASS 계산 안 함**. UI03의 ms 적분·100ms PASS는 observer에서 의도적으로 보류(더 보수적·정확).

### 3. 판정
- **설계 타당**: observer.js는 게임 무구동·무변경(옵션/세이브/캐시/HTML 불변), 소유 워퍼만 복구(34), 중복설치 차단(11), 부분실패 롤백(102/155), 타도구 교체 보존 `conflicts`(34), 링버퍼·dropped(16), 자동종료(25)까지 안전장치 구비. smoke 10테스트가 실제 추출 드롭함수+모의 캔버스로 포함/배타시간·캐시·GL근거·사망부활 첫 draw·게이트·롤백을 정적 검증.
- **직전 UI03 대비**: update 실래핑, 부활 "첫 렌더" 판정, GL after-draw 위상, `_ens8GLTotal` 누적 오용 금지, 구울 자동분류 금지 — **5개 계수 교정이 모두 더 정확**. UI03 하니스는 설계 후보였고 본 도구가 이를 대체·보강하는 관계로 판정.
- **미완**: 실제 수치(update/draw/rAF/GL/사망부활 계수 raw)는 **브라우저 정규 풀부팅 설치 후에만** 생성. 현재 `outputs/` 산출물 부재로 **실관측 계수 판정 불가** — 코드·계수 "방법론" 검토까지만 완료.

### 4. 잔여 · 다음(root 실게임 차례 후 raw)
1. `outputs/map020-variants-20261001/observers/` 생성은 root의 단일 3340 창 인수·정규 풀부팅 후 `installDrop`/`installVfx(regularBootAttested:true)` 실행 결과로 저장(README 5단계). 완료 시 `running:false`·`conflicts:[]`·`samplingErrors:0`·`dropped:0` 확인, `dropped>0`이면 기간 축소 재검수.
2. cap60/무제한은 **게임 옵션으로 각각 전환·별도 설치·회수**(cap0만으로 고주사율 증명 금지, 실제 page rAF 간격·디스플레이 조건 별도 확인).
3. 실제 부활(구울/보스)은 사용자 입력으로 수행, 신규 객체 구울 자동분류 금지.
4. smoke.mjs는 README 기재 노드(`~/.local/node-runtime/node-v24.15.0-darwin-arm64/bin/node`)로 재확인 가능하나, 본 차례에서는 **미실행**(아래 제약).

### 5. 제약(준수)
- **읽기 전용**: 3파일 Read만 수행, 파일·게임·HTML·세이브·옵션 **무변경**.
- **브라우저 실행 금지 준수** — 관측도구 미설치, 게임 미구동. smoke.mjs도 미실행(계수 raw는 root 실게임 차례 산출물 대상).
- **별도 팀 생성·trust/security 변경 없음**, PC 접속 없음, main/easy 동기화 없음.

MAP020-followup 관측도구·smoke 코드 계수차이 정적 검토를 완료합니다. 실관측 raw는 root 실게임 차례 후 `outputs/…/observers/` 생성분으로 인계받아 이어서 판정하겠습니다.

지정된 절대경로의 실제 산출물을 읽겠습니다.

두 산출물 모두 Read 완료했습니다. **직전 제 보고의 경로 근거에 오류가 있었음을 먼저 정정**하고 최종본을 제공합니다.

## MAP020-variants 증거 검토 — 근거 정정 최종본

### 0. 직전 보고 정정 (핵심)
직전 턴에서 저는 `outputs/map020-variants-20261001/observers/`를 **저장소 트리(`/Users/…/exoduser-migration-20261001/outputs/**`)에서만** 탐색해 "디렉터리 부재·smoke결과 Read 불가"로 판정했습니다. **이는 탐색 경로 오류였습니다.** 실제 산출물은 저장소 밖 **절대경로** `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/observers/`에 존재하며, 이번에 `smoke-result.json`·`인수보고.md` 둘 다 **실재·Read 완료**했습니다. "산출물 미생성" 판정을 **철회**합니다.

### 1. Read한 실제 산출물
| 경로(절대) | 상태 |
|---|---|
| `…/dho/outputs/…/observers/smoke-result.json` | **존재·Read 완료** — `status:"PASS", checks:10` |
| `…/dho/outputs/…/observers/인수보고.md` | **존재·Read 완료** — 담당 `/root/map_art_review`, 23줄 |

### 2. 실제 10/10 실행 결과 vs 브라우저 미실행 (명확 구분)
**(A) 실제 실행된 것 — Node VM smoke `10/10 PASS`** (`smoke-result.json` 실측):
- `status:"PASS"`, `checks:10`, 10개 테스트명 전부 기록. 검증 범위(`scope`)는 **"Node vm: 실제 추출 드롭함수 + 모의 Canvas2D; 합성 update/draw"**.
- 통과 항목: ①실제 게임함수 바인딩 설치·중복평가 ②fx miss→mask→read 계층·배타시간 분할 ③아이템 mask 재사용·cutout bypass·asset 캐시 ④notready/oob·링버퍼·네이티브/게임 identity 원복 ⑤update(고정)·page rAF·draw **분리 계수** ⑥사망·동일객체 부활 첫 draw 전/후 ⑦hidden/부팅 게이트 GL 주장 차단·신규객체 비(非)부활 ⑧자동 dispose 결과보존·rAF/update/draw 원복·재설치 id 리셋 ⑨타 도구 교체 보존·conflict ⑩부분 설치실패 롤백.

**(B) 미실행 — 인수보고.md 명시** ("브라우저·게임·GL·GPU·사망부활 화면·약21ms 재측정 **모두 미실시**"):
- 실제 Mac 브라우저 설치·정규 풀부팅·GL draw 실관측·GPU 시간·사망/부활 화면 캡처·PC 329ms 원인·약21ms 개선 판정 — **전부 미수행**. 이번에도 브라우저 실행 금지 준수로 변동 없음.

→ **결론 구분**: 관측도구 **로직·안전장치·계수분리 설계는 Node 10/10으로 실증됨**. 그러나 **실게임 관측 계수(raw)는 0건** — root 단일창 인수·정규 부팅 후 생성 대상.

### 3. game.html SHA 분기 주의 (provenance)
- smoke 검사 시 `gameSHA256 = a7a1b45fb1…9402` (smoke-result.json·인수보고 일치).
- 제가 §11 피격 플래시 수정 검증에 쓴 디스크 해시는 `77523703…f53967`.
- **두 스냅샷이 다릅니다.** 공용 `game.html`이 그 사이 타 팀 편집으로 변동(CLAUDE.md 동시세션 규칙)했음을 의미. **단, smoke는 드롭/VFX 관측도구 로직을 검증한 것이지 §11 플래시 수정을 검증한 것이 아니므로 모순 아님.** 플래시 수정 검수(§11)와 본 smoke는 서로 다른 리비전·다른 대상임을 기록.

### 4. update/draw/rAF/GL/사망·부활 계수차이 — 인수보고로 확정
직전 턴에 제가 "방법론 정적검토"로 제시한 계수 교정이, 인수보고.md의 "중요 정정"으로 **재확인·격상**됩니다(= 10/10 실행으로 뒷받침):
- **update**: 실제 호출 임시 래핑, `_gameTime` 증분 추정 불채택 → 실바인딩 계수(smoke ⑤).
- **rAF/draw**: 독립 page rAF를 실제 update/draw와 분리 계수(smoke ⑤).
- **GL**: `_ens8GLTotal`은 **프레임 큐 수(누적 아님)**, `_ensGLQueued`는 **렌더 지역변수**(객체 필드 아님)라 관측에서 **제거**. 정규 부팅 증거 + after-draw `_ensGLMode===1`로만 GL 근거(smoke ⑦).
- **사망·부활**: 동일 객체 부활 **첫 draw** 전/후 hf 기록(=update 직후 샘플을 첫 표시로 오인 금지), 신규 객체 **구울 자동분류 금지**(smoke ⑥⑦).
- **lexical 단정 철회**: "함수가 lexical이라 외부 계측 불가"는 확정 근거로 불채택(인수보고 명시) → 제 UI03 하니스의 해당 단정도 정정.
- **시간 해석**: `mask.selfMs`는 순수 픽셀루프 시간 아님(getContext/JS 잔여 포함), 포함시간 합산 금지, 약21ms 포함시간 미합산.

### 5. 잔여 · 다음
- root의 **MAP 검수 종료 → 단일 3340창 인수 → 정규 풀부팅** 후: QA `installDrop` 20초 단일 실행/회수/cleanup → 이어 VFX 단일 실행(**두 워퍼 동시설치 금지**, 밀집 p95/p99 본표에 워퍼 비용 불혼입). 결과를 같은 절대경로 `observers/`에 저장, `running:false`·`conflicts:[]`·`samplingErrors:0`·`dropped:0` 확인.
- cap60/무제한은 게임 옵션으로 각각 별도 설치·회수(cap0만으로 고주사율 비증명).
- 실게임 계수 raw 확보 후 §4 계수차이의 **실측 판정**으로 이어감.

### 6. 제약
- **읽기 전용**: 지정 절대경로 2파일 Read만 수행. 파일·게임·HTML·docs·세이브·옵션·Git **무변경**, smoke 재실행 안 함(브라우저도 안 함).
- 별도 팀 생성·trust/security 변경·PC 접속 **없음**.

**최종 판정**: 직전 보고의 "outputs 누락" 근거는 **경로 오류로 정정**하며, 실제로는 **Node VM smoke 10/10 PASS가 실행 완료**(관측도구 로직 실증)되었고 **브라우저·GL·실게임 계수는 전부 미실행**입니다. 실게임 raw는 root 실행 창에서 생성 후 인계받아 판정을 이어가겠습니다.

지정된 두 브라우저 실측 산출물을 읽겠습니다.

browser-vfx.json 전체 Read 완료. browser-drop.json은 3.2MB로 큰데 요약·메타 필드만 발췌하겠습니다.

두 실측 산출물을 읽었습니다(browser-vfx.json 전체, browser-drop.json은 3.2MB라 요약·메타 발췌). 아래가 실제 결과 기반 최종 판정입니다.

## MAP020-variants 브라우저 실측 검토 — 최종 한계·합산 검토

### 0. 직전 상태 정정
직전 턴에서 "브라우저·게임·GL·실게임 계수 전부 미실행"이라 보고했으나, **이제 브라우저 실측이 실제 수행**되어 `browser-drop.json`·`browser-vfx.json`이 생성됐습니다. 정규 새로고침 부팅 후 실제 LMB 전투로 **VFX 10초 → DROP 12초 직렬 실행, dispose 확인**(둘 다 `running:false`). 타임스탬프상 VFX(now≈31.2–40.7s) 선행, DROP(now≈81.7s) 후행 — **동시 설치 아님**(README 준수).

### 1. VFX 실측 — 계수 분리 성공, 그러나 GL 미검증
`browser-vfx.json` 실값: `updates:602`, `draws:1188`, `pageRafs:1188`, `records:70`, `samplingErrors:0`, `dropped:0`, `conflicts:[]`, `running:false`, `durationMs:10000`, `regularBootAttested:true`.

| 항목 | 실값·판정 |
|---|---|
| **update vs draw/rAF 분리** | updates **602**(≈60.2/s = 고정 60Hz) ≠ draws **1188**(≈119/s) = pageRafs **1188**. **고정 update tick과 page rAF/draw 레이트 분리 관측 실증** — 도구 핵심 목적 달성 |
| **GL 게이트** | **전 레코드 `useGL:false` + `contextLost:true` → `runtimeGate:false`, `glDrawEvidence:false`**. WebGL2 컨텍스트 상실로 이 런은 **2D(CPU) 폴백 렌더**였음 |
| **GL 플래시 수명(cap60/고주사율)** | **PASS 불가** — GL 인스턴싱 경로 자체가 구동 안 됨(게이트 실패). §11 수정본 GL 수명 in-browser 검증 **미완** |
| **부활 첫 프레임** | **0건** — `transitionRows:[]`, death/revive 이벤트 전무. 70 레코드 전부 `first-observed-object`(설치 시 60마리 paused 스냅샷 + 플레이 중 10마리). 사망·부활·플래시 전이 **미포착** |
| cap | `cap:0`(무제한). cap0만으로 고주사율 증명 안 함(README) — 디스플레이 ~119Hz 추정이나 별도 확인 필요 |

**중요**: 이는 **도구 결함이 아니라 런타임 조건(컨텍스트 상실)**이며, 게이트가 설계대로 GL 주장을 **정확히 거부**했습니다(거짓 PASS 방지). §11 GL 수명·부활 검증은 **정상 GL 컨텍스트 재런 필요**.

### 2. DROP 실측 — 첫 처치 비용 포착 + 합산 검토
`browser-drop.json` `byLabel` 실값(12초, 실제 7kill/worldItems6, `dropped:0`, `conflicts:[]`, `limit:20000`):

| label | calls | inclusiveMs | selfMs | 비고 |
|---|---:|---:|---:|---|
| mask | 2 | 31.6 | 1.9 | getImageData를 자식으로 포함 |
| 2d.getImageData | 2 | **29.6** | 29.6 | **readback 2회 합계**(개별 아님; 1회차 17.2ms) |
| 2d.putImageData | 2 | 0.1 | 0.1 | |
| 2d.drawImage | 2 | 0.1 | 0.1 | |
| fxTile | 1428 | 33.3 | 1.6 | drawImage를 자식으로 포함 |
| itemSkin | 4621 | 7.2 | 7.2 | |
| **합계 rows** | **6057** | — | — | 1428+4621+2+2+2+2 |

**합산 검토(핵심)**:
- **readback 29.6ms는 getImageData 2회의 합계**이며 **mask(31.6 inclusive)에 중첩 포함**. `mask.inclusive + getImageData.inclusive` 식 **합산 금지**(이중계산). note가 "inclusive columns are nested; never add them" 명시.
- **selfMs만 비중복 합산 가능**: 0.1+29.6+0.1+1.6+7.2+1.9 = **≈40.5ms**(12초 내 동기 계측분). 대부분이 getImageData self(29.6ms).
- `mask.selfMs`(1.9ms)는 **순수 픽셀루프 아님**(getContext/JS 잔여 포함). getImageData 벽시계 시간은 **GPU 시간 아님**.
- 첫 처치 관련 무거운 비용은 **mask+readback이 단 2회**(첫 시체/월드드롭 생성 1회성)로 ~30ms 집중 — "첫 처치 1회성 CPU 비용" 가설과 **방향 일치**. 단 ~30ms(Mac, 2D폴백, GPU제외)는 **PC 329ms와 직접 등치 불가**이며, 직전 후보의 "약21ms"도 **재현·판정 안 함**(다른 런·다른 지표).

### 3. 최종 한계
1. **GL 전면 미검증**: 컨텍스트 상실로 §11 GL 플래시 수명(cap60/고주사율 수렴)·부활 첫 프레임 hf=0 **in-browser 증거 0**. 정적 소스 일치(직전 §11 검증)는 유지되나, 실화면 GL PASS는 **여전히 대기**.
2. **부활 0건**: VFX 창에서 사망·부활 전이 미포착 → 부활 잔상 제거(§11 edit#4) in-browser 확인 불가.
3. **DROP는 2D 폴백 기준**: GL 경로 드롭 비용과 다를 수 있음. getImageData 2회뿐이라 통계적 분포 아님(1회성 포착).
4. **PC 329ms·21ms 미해결**: 본 실측은 원인 확정/개선 판정이 아님. Mac·2D·GPU제외·단발 표본.
5. **provenance**: 두 JSON에 game.html SHA 미기재(이전 smoke는 `a7a1b45f…`). 실측 리비전 해시 별도 확인 필요.

### 4. 잔여 · 다음
- **정상 WebGL2 컨텍스트**로 VFX 재런(`contextLost:false`·`useGL:true`·`runtimeGate:true` 확인 후) → GL 플래시 수명 cap60/무제한 각각 별도 설치·회수, 실제 사망→부활(구울/보스)로 부활 첫 draw hf=0 포착.
- DROP은 GL 경로에서 재측정해 2D 폴백값과 대조. getImageData/mask 중첩은 **selfMs로만 합산**, inclusive 합산 금지 유지.
- 재런 산출물은 같은 절대경로 `observers/`에 저장, `samplingErrors:0`·`dropped:0`·`conflicts:[]` 재확인.

### 5. 제약
- **읽기 전용**: 지정 2파일 Read만. 파일·게임·HTML·docs·세이브·옵션·Git **무변경**, 브라우저·도구 **미실행**(기존 산출물 판독만).
- 별도 팀·trust/security 변경·PC 접속 **없음**.

**최종**: 브라우저 실측은 **실제 수행됨**(VFX 10s·DROP 12s 직렬, dispose 확인). 도구의 **update/draw/rAF 분리 계수는 실값(602/1188/1188)으로 실증**됐고, **DROP 첫 처치 readback 비용(getImageData 29.6ms 합계, mask에 중첩)**을 포착했습니다. 그러나 **WebGL 컨텍스트 상실로 GL 플래시 수명·부활 검증은 불가(GL수명 PASS 없음, 부활 0)** — 정상 GL 컨텍스트 재런이 남은 유일 블로커입니다. 합산은 **selfMs만**, nested inclusive는 합산하지 않습니다.

정정 수용합니다. 제 직전 "WebGL 컨텍스트 상실" 확정은 과잉 단정이었습니다. 아래가 **정정된 한계 문구만** 보고입니다.

## 정정 한계 문구 (MAP020-variants VFX 실측)

1. **"WebGL 컨텍스트 상실" 확정 철회.** observer.js의 `contextLost: safe(()=>GL.isContextLost(), true)`(관측도구 109행)는 **fallback이 `true`**다. `GL`이 `null`/미지원이거나 호출이 throw해도 `true`가 되므로, raw `useGL:false` + `contextLost:true`만으로는 **(a) 실제 컨텍스트 상실 / (b) GL 미지원·미획득(GL=null) / (c) 호출 예외**를 구분할 수 없다.

2. **확정 가능한 것은 "GL 검수 게이트 미충족"뿐이다.** 즉 `runtimeGate:false`·`glDrawEvidence:false`로 **이 런은 GL 인스턴싱 경로의 플래시 검수 조건을 충족하지 못했다**까지만 사실이다. 원인이 컨텍스트 상실인지 GL 미획득인지 등은 **미확정**.

3. 따라서 §11 GL 플래시 수명(cap60/고주사율)·부활 첫 프레임 검증은 **"게이트 미충족으로 미검증"**으로 표기한다. "컨텍스트 상실로 미검증"은 쓰지 않는다.

4. **root가 관측도구 수정 중**: `glAvailable`와 `contextLost:null`(측정불가)을 분리해 (b)/(c)를 fallback `true`와 구분하도록 개선 중이며, **이전 raw(`browser-vfx.json`/`browser-drop.json`)는 보존**된다. 원인 구분은 수정 도구의 재런 결과로 판정한다.

5. **변동 없는 부분(재확인)**: update(602) vs draw/pageRaf(1188) **레이트 분리 계수는 유효**. DROP의 **nested inclusive 합산 금지**(getImageData 29.6ms는 2회 합계이며 mask 31.6 inclusive에 포함), **selfMs만 비중복 합산** 원칙도 그대로 유효. PC 329ms·약21ms는 여전히 미판정.

이상이 정정 한계 문구입니다. 읽기 전용 유지(파일·게임·도구·Git 무변경), 추가 실행 없음.