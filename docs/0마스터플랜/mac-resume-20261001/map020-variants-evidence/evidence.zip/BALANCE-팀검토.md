지정 경로부터 실제 존재 여부를 확인하고 읽겠습니다.

`tools/qa/map020-followup-gameplay`는 존재(6파일), `outputs/map020-variants-20261001/gameplay`는 **파일 없음**(누락). 관련 검수 파일을 읽겠습니다.

검수 하니스 확인. 핵심 구분점(`upSp:5` 데이터 필드 ≠ 현행비용함수 `_skillUpSpCost(1)=1`)을 실코드로 확정하겠습니다.

읽기 완료. 실제 Read 근거로 판정합니다. **HTML 무변경, 미실행 유지.**

## 경로 존재/읽기 현황
- `tools/qa/map020-followup-gameplay/` — **존재(6파일)**. 읽음: `balance.test.js`, `skill.test.js`, `source.mjs`. 미열람: `enemy.test.js`, `anchors.test.js`, `evidence.mjs`(이번 판정 3건에 불필요 — 잔여로 명시).
- `outputs/map020-variants-20261001/gameplay/` — **파일 없음(누락)**. 산출물 미생성 상태.

## 판정 1 — kiSlash `upSp:5` ≠ 현행비용함수 `_skillUpSpCost(1)=1`
- 실코드 `game.html:3892~3896`: `_skillUpSpCost(curLv)`, 테이블 `[0,1,1,1,1,1,1,1,1,1,1]`, `curLv=1 → nextLv=2 → _tbl[2]=1` → **반환 1**.
- 패널 실게이트/차감은 `_singleUpSp=_skillUpSpCost(slv)`(`game.html:45917`, 표시 `46191`, 일괄 `46514`)를 사용 → kiSlash Lv1→2 실제 SP 비용 = **1**.
- 데이터 필드 `upSp:5`(`SKILL_LIST`)는 **레거시**이며 현행 비용함수가 아님.
- 검수 하니스가 이를 명시적으로 분리: `balance.test.js:50` `_skillUpSpCost(1)===1`, `:51` `sk.upSp===5 ('legacy data field is not the current cost function')`.
- **→ 직전 케이스 사양(B) 정정**: "정확비용 `P.sp=upSp(=5)`"는 부정확. 현행 정확비용 = **`_skillUpSpCost(slv)` (Lv1→2 = 1 SP)**. 잔액0→거부, SP 0→거부, SP 1→성공(1 차감)이 실경계.

## 판정 2 — 533만 → 528만 후보: 정확
- `balance.test.js:86` `enhCostRaw(1000)===5280000` 단언 = **528만**. 실코드식 `(20000+1000×3500)×1.5=5,280,000`와 일치.
- 주석(`game.html:26602`) `1000강=533만`만 오기 → 후보 A(533만→528만) **정확**, 정정 불필요.

## 판정 3 — 환수주석 후보: 정확
- `balance.test.js:87~90`: +0~+9 누적 `spent===268125`, 강화분 `refund===15`, `refund !== floor(spent/2)` 단언 → 주석 "실제 강화 비용 누적합의 절반"이 **사실과 불일치**임을 하니스가 확정.
- 환수 누적식은 레거시 `ceil((1+i×0.15)×1.5)×배율`(`game.html:26708`)로 현행 `enhCostRaw`와 다름 → 후보 B(주석 정정, 식 불변) **정확**.
- 환수식 자체 무변경 지시 준수 — 주석만 후보.

## 잔여 보고
- `outputs/map020-variants-20261001/gameplay/` 산출물 **누락** → 증거 생성은 이 읽기전용 세션 범위 밖(실행·쓰기 금지).
- `balance.test.js`/`skill.test.js`는 격리 추출 하니스(실함수 vm 평가)로, 본 세션에서 **미실행**(읽기만). PASS/FAIL 보고 아님.
- 미열람 3파일(`enemy/anchors/evidence`) 및 장비 클릭 게이트 호출부 전문은 이번 3건 판정에 불요 → 잔여.
- 후보 A/B 유효, 케이스 사양 (B)만 `upSp5→_skillUpSpCost=1`로 정정. **HTML·공식·파일 무변경, 별도팀·trust/security 변경 없음.**

판정 완료, 종료합니다.

절대경로의 실제 결과를 확인하고 읽겠습니다.

실제 결과 존재 확인. 핵심 파일들을 읽겠습니다.

절대경로에 **실제 검수 결과 존재** 확인·Read 완료. 직전 보고의 2개 근거를 정정합니다. **읽기 전용, 무변경.**

---

# MAP020-variants 최종 검수 본문 (근거 정정판)

## 정정 1 — "산출물 누락" 판정 철회
- 직전 보고의 상대경로 `outputs/map020-variants-20261001/gameplay/` "파일 없음" → **오판**. 실제 산출물은 절대경로 `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/gameplay/`에 **11파일 존재**(읽음: `balance-first-run.txt`, `final-tests.txt`, `balance-comments-old-new.json`, `balance-comments-only.patch` / 미열람: `skill-first-run.txt`, `enemy-*`, `source-manifest.json`, `게임플레이-후속검수.md`, `docs-추가문구.md`).

## 정정 2 — QA 검수는 "실행 결과 존재·전 PASS"
- `final-tests.txt`: **tests 35 / pass 35 / fail 0**. `balance-first-run.txt`: balance 10/10 PASS.
- 직전 "미실행"은 **내 세션에서 미실행**이라는 뜻으로 한정. QA 팀의 격리 하니스 실행 결과물은 존재하며 전부 통과. (나는 결과 파일을 Read했을 뿐, 실행은 하지 않음 — 구분 유지.)

## 확증 — 판정 1/2/3 (증거 일치)
- `balance-first-run.txt`·`final-tests.txt` 공통 로그 (두 HTML):
  `{"upSpData":5,"actualUpSp":1,"spent":268125,"refund":15}`
  - **kiSlash `upSp:5`(레거시 데이터) ≠ 현행 `_skillUpSpCost(1)=1`** → 판정 1 확증.
  - `enhCostRaw(1000)=5,280,000`(=528만), 533만 아님 → 판정 2 확증.
  - +0~+9 누적 지출 **268,125**, 강화분 환수 **15**, `refund ≠ floor(spent/2)` → 판정 3 확증.

## 정정 3 — 환수주석 후보 문구를 **권위 산출물본**으로 교체
직전 후보 B의 new 문구는 의미는 같으나 표현이 달랐음. 공식 산출물 `balance-comments-old-new.json`(해시 보증, `applied:false`)의 old/new를 최종본으로 채택:

```diff
# game.html:26602  /  game-easy-test.html:25736
- return Math.max(20000,Math.ceil((20000+n*3500)*1.5)); // 최소 2만(=1만악의), 0강=3만, 100강=55.5만, 1000강=533만
+ return Math.max(20000,Math.ceil((20000+n*3500)*1.5)); // 최소 2만(=1만악의), 0강=3만, 100강=55.5만, 1000강=528만

# game.html:26703  /  game-easy-test.html:25837
- // 강화 투자분 50% 환수: 실제 강화 비용 누적합의 절반
+ // 강화분 환수는 레거시 단위누적식의 50%이며 현행 enhCostRaw 지출의 50%가 아님.
+ // 레거시 누적항: ceil(max(1,ceil((1+i*0.15)*1.5))*등급배율). PM-013-D 설계 대기.
```

## 정정 4 — 대상은 **양쪽 공용 HTML 2파일 × 2곳**
- 직전엔 `game.html`만 기재. 실제 산출물은 `game-easy-test.html`도 동일 후보 포함:
  - `game.html`: 26602(533→528), 26703(환수주석)
  - `game-easy-test.html`: 25736(533→528), 25837(환수주석)
- `inputSha256`/`candidateSha256` 기록으로 old 문구가 현행 파일과 일치함이 해시 보증됨.

## 상태·잔여
- 모든 후보 `"applied": false` — **미적용**. 공용HTML 단독 편집자(총괄) 적용 대기. 환수식·경제수치·공식 **불변**(주석만).
- 미열람 산출물(`skill-first-run.txt`, `enemy-*`, `게임플레이-후속검수.md`, `docs-추가문구.md`)은 이번 3건 근거 정정에 불요 → 잔여.
- **읽기 전용 준수, HTML·파일·trust/security·별도팀 변경 없음.**

근거 정정 완료, 종료합니다.
