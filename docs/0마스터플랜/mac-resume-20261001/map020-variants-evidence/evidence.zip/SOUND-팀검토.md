지정하신 경로의 실제 존재 여부를 먼저 확인하겠습니다.

`outputs/map020-variants-20261001/` 경로는 **부재**(Glob 0건). `tools/qa/map020-followup-build/sound-audit.py`와 SOUND 증거 JSON은 존재합니다. 실제 decode 결과를 담은 파일들을 읽겠습니다.

`sound-audit.py`를 확인했습니다. 실제 decode 결과 영수증이 담긴 SOUND 증거 JSON들을 읽겠습니다.

후보 13개 파일명을 확인했습니다. 실제 decode 결과 영수증과 참조 문서를 읽겠습니다.

영수증·참조문서를 확인했습니다. `SOUND_TEAM_LEAD.md`·`S02_BGM_COMPRESSION_20260930.md`는 **부재**(Glob 0건). decode 실제 결과는 `sound-audit.py`가 외부 소유 디렉터리에 기록하므로, 그 경로 존재 여부를 확인하겠습니다.

decode 실제 결과가 외부 소유 디렉터리에 존재합니다. 실제 결과 JSON을 읽겠습니다.

decode 실제 결과(`sound-result.json`)를 직접 읽었습니다. 경로 존재/부재를 사실로 구분해 보고합니다.

## 경로 존재 사실 (Read 근거)

| 경로 | 상태 |
|---|---|
| `tools/qa/map020-followup-build/sound-audit.py` | **존재**(읽음) — S-02 추출+네이티브 probe 스크립트 |
| 프로젝트 상대 `outputs/map020-variants-20261001/` | **부재**(Glob 0건) |
| 외부 소유 `…/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/build-item-sound/sound-result.json` | **존재**(읽음) — 실제 decode 결과 |
| 추출본 `…/build-item-sound/sound-receipt-01/` (9후보+README+측정3) | **존재**(13개) |
| `docs/6사운드디자인/SOUND_TEAM_LEAD.md`·`S02_BGM_COMPRESSION_20260930.md` | **부재**(Glob 0건, README가 참조하나 Mac 트리에 없음) |

> 프로비넌스: `sound-result.json`의 `sourceHead=bc7cc037…`은 현재 세션 스냅샷 HEAD(`dd4c12b9`)와 다름 — 실행은 더 뒤 HEAD에서 수행됨. `sourceRef=49851bd…`(SOUND 브랜치)에서 `git cat-file`로 추출.

## decode 실제 결과 (기계 구조·프리픽스, 청취 아님)

**무결성**: 13 blob 전부 `sha1(blob) == oid` 검증 통과, 후보 9 + README + 측정3 = 13개(스크립트 `entries!=13` 게이트 충족).

**duration 대조 (afinfo estimated / 유효프레임)**

| 곡 | 원본 WAV | MP3 256k | OGG q6 | Opus 160k | 유효프레임(공통) |
|---|---|---|---|---|---|
| Ashes Under the Banner | 420.0s | 420.024 | 420.0 | 420.0065 | 20,160,000 |
| 흰눈의 맹세 | 347.48s | 347.52 | 347.48 | 347.4865 | 16,679,040 |
| 네메시아의 강림2 | 145.0s | 145.032 | 145.0 | 145.0065 | 6,960,000 |

- **유효프레임(valid frames)이 세 포맷 모두 원본과 완전 일치** → 문서의 "MP3/Opus 샘플수 일치"가 실제 afinfo로 재확인됨. MP3 +~24~40ms, Opus +6.5ms는 인코더 priming/remainder 패딩(MP3 576+remainder, Opus 312+648)이며 유효 오디오 길이는 동일. OGG는 estimated까지 원본과 동일.

**decode/컨테이너 판정**
- `nativeDecode`(CoreAudio ExtAudioFileRead, 첫 4096프레임): **9/9 PASS**, 전부 48000Hz·2ch·osstatus 0·finite.
- `container`(Ogg 페이지 경계/시퀀스/EOS): OGG·Opus **6/6 PASS**. MP3 3개는 Ogg 컨테이너가 아니라 이 구조검사 비대상(미실패).
- `counts`: candidates 9 / nativePrefixDecodePass **9** / containerPass **6**.
- 프리픽스 peak: 곡별로 원본과 근접(예: 네메시아 wav 0.647 ↔ opus 0.697) — 첫 85ms 표본일 뿐 품질 판정 아님.

## 판정 (decode vs 청취 분리)

- **decode 계약 = 통과**: 9후보 모두 열림·구조 정상·샘플수 원본 일치·포맷 메타 정상. 손상/열림 실패 후보 **0건**.
- **청취 = 미실시(별도)**: `sound-result.json` `limits` 명시 — "No listening, waveform quality, full-track decode, loop seam measurement, browser playback, game/package integration." 즉 **기계 구조 PASS일 뿐 가청 품질 검증 아님**.

## 잔여 보고

1. **실청취 A/B 미실시** — 볼륨 정합·왜곡(Ashes 고역, 흰눈 합창 잔향)은 귀로만 판정 가능, 미완료.
2. **loop seam 미측정** — 네메시아의 강림2 반복 이음부는 첫 4096프레임만 디코드했으므로 **전혀 검증 안 됨**. full-track decode도 미실시.
3. **패키지 반영 미실시** — 채택 포맷→런타임 `t:bgm/*.mp3` 경로 반영·사용자 설정 보존은 별도 배정 대기.
4. **도구 한계 주석** — ffprobe/ffmpeg 부재로 CoreAudio만 사용. "네이티브 디코드 미지원은 도구 한계이지 후보 손상 증거 아님"(limits). 단 이번엔 9/9 PASS라 해당 없음.

**요약**: decode(구조·샘플수·열림)는 9/9 통과로 실제 확인됨. 청취·루프 이음부·전곡 디코드·패키지 반영은 미실시로 분리. 새 인코딩·병합·삭제·게임 실행·파일 수정 없음, 프로젝트 읽기 전용 유지. 결과 저장은 총괄이 수행. 종료합니다.
