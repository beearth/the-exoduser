수신: MAP020-variants 후속 — 지정 harness/outputs 읽고 cutout 실패→phys RGB 마스킹 누락 재현을 독립검토합니다. 먼저 경로 실존부터 확인합니다.

ITEM harness 3종 실존, 단 `outputs/map020-variants-20261001/`는 **미존재**. 실존하는 harness부터 읽고 outputs 경로를 넓게 확인합니다.

Harness 읽기 완료. 결함 로직 재현을 코드로 확정하기 위해 `_ITEM_CUTOUT_BASES` 멤버십과 관련 에셋 실존을 확인합니다.

독립검토 완료. 실제 Read 근거로 결함을 재현 확정했습니다.

## 1. Read 근거 (실존 / 누락)

**실존 (읽음):**
- Harness: `tools/qa/map020-followup-build/item-audit.cjs` (전문 읽음), 같은 폴더 `build-audit.py`·`sound-audit.py` 존재.
- `game.html`: `_ITEM_CUTOUT_BASES`(26321)에 **belt·shield·armor 포함 확인**, `_worldItemSkin`(26386~26411), cutoutSrc(26394), 폴백 onerror(26400), 문제 가드(26404).
- 에셋: `img/ui/item-cutouts/{belt,shield,armor}_phys_cutout.png` 3종·`output/imagegen/item-skins/{belt,shield,armor}_phys.png` 3종 **모두 실존**.

**누락 (명시):**
- `outputs/map020-variants-20261001/` **전체 미존재**, 지정한 `build-item-sound` 산출물 **미존재** → outputs 측 근거 없음(경로 작성중 추정). outputs 기반 재현 불가, harness+소스 기반으로만 검토.

## 2. 결함 재현 판정 (독립)

**결함 위치:** `_worldItemSkin` 26404 `if(cutoutSrc)return img;` — **실제 로드된 이미지가 아니라 "base가 컷아웃 베이스인가"로 분기**.

**재현 경로 (코드 추적):** 컷아웃 404 → onerror(26400) `img.src=fallback`(= `*_phys.png`, 불투명 RGB) → 재호출 시 `cutoutSrc` 여전히 truthy → **마스킹 생략하고 불투명 phys 반환** → 월드 바닥에 불투명 배경 사각형(검정→알파 변환 누락).

**harness 교차검증:** 47~51행이 결정적 재현 — `fi.fail()`→src=`belt_phys.png`(48행 PASS), `fi.succeed()`→`maskCalls===0` → 관측 50행 `REPRODUCED_DEFECT`(expectedMaskCalls:1), 51행 `opaque physical fallback is masked`는 **FAIL로 결함 노출**(42행 주석대로 "report defect, do not fix game"). 나의 코드 추적 결론과 일치.

**범위 한정:** 인벤토리 DOM(`_itemSkin`)은 CSS 표시라 동일 결함 없음 — 결함은 **월드 드롭 캔버스 경로(`_worldItemSkin`) 국한**. belt/shield/armor 컷아웃 파일이 현존하므로 현 배포에서 이 3종은 미발현(정상 투명); 결함은 **컷아웃 파일 누락/404 시 발현되는 잠재결함**.

## 3. 최소수정후보 (HTML 미작성 · 코드블록만)

실제 로드된 것이 컷아웃일 때만 마스킹을 생략하도록, 폴백 발생 플래그 1개 + 가드 1개만 변경:

```js
// _worldItemSkin — 26400행 (폴백 시 플래그 세팅 추가)
// before: if(renderSrc!==fallback)img.onerror=()=>{img.onerror=null;img._worldDropMasked=null;img.src=fallback;};
   if(renderSrc!==fallback)img.onerror=()=>{img.onerror=null;img._fellBack=true;img._worldDropMasked=null;img.src=fallback;};

// _worldItemSkin — 26404행 (가드를 "실제 로드 소스" 기준으로)
// before: if(cutoutSrc)return img;
   if(cutoutSrc && !img._fellBack)return img; // 컷아웃이 실제 로드된 경우만 마스킹 생략; 폴백(불투명 phys)은 마스킹 경로로 진행
```

- **값 불변**(uniqueId/효과/드롭/저장 무관), 캔버스 경로만 교정. 플래그는 캐시된 img에 영속 → 재호출·캐시 호환.
- 정상 컷아웃 로드: `_fellBack` 미설정 → 종전대로 무마스킹. 비컷아웃 불투명(ring 등): `cutoutSrc=''` → 종전대로 마스킹. 폴백 phys: `_fellBack=true` → 마스킹 1회 → 불투명 배경 제거.
- 적용 시 harness 기대: 관측 50행 `maskCalls===1`, 51행 PASS로 전환(이번엔 **미적용·미실행**).

## 4. 잔여 보고

- `outputs/map020-variants-20261001/` 및 `build-item-sound` 산출물 생성/저장은 총괄 몫(미존재).
- 다른 컷아웃 베이스(axe/boots/bracelet/cape/crossbow/earring/gloves/helmet/necklace/pants/sword)의 컷아웃 파일 실존 여부 미점검 — 결함 발현 가능 범위라 필요 시 별도 1건.
- `build-audit.py`·`sound-audit.py` 내용 미독(이번 범위=ITEM cutout) → 빌드/사운드 audit 잔여.
- **미실행 제약:** VM harness·수정후보 모두 이번에 실행·적용 안 함. 읽기 전용 유지, 파일/게임/trust·security 무변경, 별도 팀 미생성.

독립검토·최소수정후보 완성. 적용·실행·산출 저장은 총괄에 위임하고 종료합니다.

수신: 절대경로의 실제 실행 증거를 Read 후 "outputs 미존재" 근거를 정정합니다.

경로 실존 확인(이전 "미존재" 근거 오류). 실제 ITEM 실행 증거를 Read합니다.

실제 실행 증거 Read 완료. 이전 보고의 두 근거(경로 미존재·미실행)를 정정한 **최종본문**입니다.

---

# MAP020-variants ITEM 검토 — 최종본 (근거 정정)

## 근거 정정

| 항목 | 이전 보고(오류) | 정정(실제 Read 근거) |
|---|---|---|
| outputs 경로 | "`outputs/map020-variants-20261001/` 전체 미존재" | **실존**. 결과는 리포 밖 절대경로 `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/build-item-sound/` 에 있음. 이전엔 리포 내 상대경로만 Glob해 놓친 오류. |
| 실행 여부 | "harness 미실행(읽기 전용)" | ITEM harness **실제 실행됨**. `item-result.json` 기준 **25 PASS / 1 FAIL**, `execution-receipt.json` `itemExitCode:1`, `itemKnownFailure:"game.html opaque physical fallback is masked"`. (미실행은 내 세션 한정이었고, 빌드세션이 이미 실행·기록) |

## 결함 재현 — 실제 실행 결과로 확정

- **유일 FAIL = `game.html opaque physical fallback is masked`** → 정확히 "cutout 실패→phys RGB 마스킹 누락" 결함. 관측 `REPRODUCED_DEFECT`: `maskCalls:0 / expectedMaskCalls:1`, `fallbackSrc:"output/imagegen/item-skins/belt_phys.png"`.
- **대조군 통과:** `game-easy-test.html`은 `PASS_COMPARISON`(`maskCalls:1`). 해당 파일은 `hasCutout:false`(belt가 컷아웃 베이스 아님)라 폴백 phys가 정상 마스킹됨 → 결함은 **belt/shield/armor가 컷아웃 베이스인 game.html에 국한** 확정.
- **PNG 메타 근거(실측):** 컷아웃 `*_phys_cutout.png` = 1254² **colorType6 alpha:true**(유일 투명), 폴백 `*_phys.png` = 256² **colorType2 alpha:false**(불투명). → 폴백 phys는 반드시 마스킹 필요한데 현행이 생략 = 결함 성립. (원본 ui-XX.png 1024²·후보 1920² 모두 colorType2 alpha:false 보존 확인)

## 결함 위치 (소스, 변경 없음)

- `_worldItemSkin` 26404 `if(cutoutSrc)return img;` — 실제 로드 소스가 아니라 "base가 컷아웃 베이스인가"로 분기 → 컷아웃 404 후 onerror(26400)가 불투명 phys로 교체돼도 마스킹 생략. (인벤 DOM `_itemSkin`은 무관, 월드 드롭 캔버스 경로 국한)

## 최소수정후보 — 후속 독립항목으로 유지 (미적용)

```js
// 26400: 폴백 시 플래그 세팅
   if(renderSrc!==fallback)img.onerror=()=>{img.onerror=null;img._fellBack=true;img._worldDropMasked=null;img.src=fallback;};
// 26404: 실제 로드가 컷아웃일 때만 마스킹 생략
   if(cutoutSrc && !img._fellBack)return img;
```
적용 시 기대: 관측 `maskCalls:1`, FAIL 체크 PASS 전환. 값 불변·캐시 호환. **이번엔 미적용**(후속 독립 검증 항목으로 유지).

## 잔여 보고

- 같은 폴더에 `sound-result.json`·`build-result.json`·`sound-receipt-01/`(13개 추출파일 readback 검증)·`실행결과-및-docs인수문구.md` 존재 → **사운드/빌드 audit은 이번 ITEM 범위 외, 잔여**.
- `execution-receipt.json`에 head 커밋·tool 4종 sha256·`buildInputsChangedAfterAudit:[]`(audit 후 입력 불변) 기록 확인.
- **읽기 전용 유지** — 파일/게임/HTML/trust·security 무변경, 별도 팀 미생성. 최소수정 적용·docs 인수·결과 저장은 총괄 위임.

---

근거 정정 반영한 최종본문 제공 완료. 종료합니다.
