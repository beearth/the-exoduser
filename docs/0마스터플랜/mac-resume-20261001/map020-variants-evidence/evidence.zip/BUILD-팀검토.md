MAP020-variants 20261001 독립 검토 완료 — 도구 3종(`tools/qa/map020-followup-build/{build-audit.py,item-audit.cjs,sound-audit.py}`)과 결과 3종(`build-result.json`·`item-result.json`·`sound-result.json` + `sound-receipt-01/`)을 실제 Read했습니다. 경로는 작성 완료 상태(누락 파일 없음). 저장소 읽기 전용 유지, 새 팀·신뢰/보안 변경·도구 실행 없음.

## Read 근거 (실제 확인)
- **HEAD 정합**: 세 결과 모두 `head/sourceHead = bc7cc0375…`. 결과의 입력 SHA(`game.html a7a1b45f…`, `game-easy-test.html 2e133bda…`, `ch1-boundary-edge.js 6274c941…`, `ui-refinement.css 9a02e776…`)가 현재 작업트리 직접 Read값과 일치 → 결과는 **현재 소스 반영**(git 실행 없이 SHA 교차대조로 확인).
- **build-audit 파싱 유효성**: 도구가 요구하는 `FILES`(build-nwjs.mjs:35)·`OPTIONAL_FILES`(:74)·`DIRS`(:137)·`OPTIONAL_DIRS`(:139) 4개 리터럴 모두 실존 → 정규식 추출 정상.
- **item-audit 의존성**: `node_modules/acorn/package.json` 실존 확인 → AST 추출 가능. VM은 Image/DOM/canvas **스텁**(item-audit.cjs:19–20)으로 실픽셀 미렌더.
- **sound-audit 안전가드**: 쓰기 대상이 소유 출력 디렉터리로 제한(ALLOWED parents 검사, 기존 목적지 거부, git blob sha1 재검증 — sound-audit.py:12–14,85), 원본 WAV 제자리 읽기·재인코딩/삭제 없음.

## 판정 (결과별)
- **BUILD = PASS(25)/WARN(2)/FAIL(0)**: WARN 2건은 `credits.html`(옵션 파일)·`output/imagegen/forge-tabs-v3`(옵션 디렉터리)로 둘 다 OPTIONAL 집합에 정당히 포함 → FAIL 아님. game.html 참조 69개·easy 52개 전부 실존+패키지 포함, boundary-edge는 game.html 로드/easy 가드 no-op, UI 캐시키 두 HTML 모두 `v=20261001-combat-status22` 일치, 개발 PORT(env·1–65535·HOST·EXODUSER_SAVE_DIR)·패키지 3347/userdata/EXODUSER-INTEGRATION 격리 전부 PASS. **직전 cache22·easy no-op 인수 내용과 모순 없음.**
- **ITEM = PASS(25)/FAIL(1) — 실제 결함 재현**: FAIL은 `game.html opaque physical fallback is masked`(maskCalls=0, 기대1). 컷아웃 이미지 실패→불투명 physical PNG 폴백 시 game.html `_worldItemSkin`이 원래 cutoutSrc로 분기해 `_maskWorldDropBlack` 알파키를 **호출하지 않음** → 월드 드롭에서 불투명 배경 노출 가능. easy판은 `_ITEM_CUTOUT_BASES` 부재(hasCutout=false)로 비컷아웃 경로라 1회 마스킹 PASS. 도구는 정책대로 **게임 미수정·결함만 보고**(REPRODUCED_DEFECT). uniqueId는 여전히 공용 스킨 사용, 원화+seedream 후보 자산 22종 경로 전부 존재(채택 0/22 불변).
- **SOUND = 후보9 네이티브 프리픽스 디코드 9/9 PASS, 컨테이너 6/6 PASS**: mp3는 컨테이너 검사 비대상이라 6(정상). 길이 원본 420.0/347.48/145.0s와 후보 일치, prefixPeak가 트랙별 원본과 동행(Ashes~0.0009·흰눈~0.003·네메시아~0.65). 추출·git blob 무결성 검증 통과.

## 잔여·한계 (QA 실측 전 미해결)
1. **ITEM FAIL 1건은 게임 로직 결함**(도구 버그 아님) → 월드 드롭 불투명 폴백 마스킹 누락. 총괄 수정 판단 필요, 이번 세션 미수정.
2. **세 도구 모두 정적/스텁/컨테이너 수준** — 실제 빌드·브라우저 렌더·오디오 청취·HTTP·패키지/세이브 재기동 없음. 완료 전 QA 실측(1x 스크린샷·청취·패키지 빌드) 필수.
3. **build-audit는 에셋 디렉터리 내부 재귀 해시 미수행**(상위 폴더 존재만) — 개별 에셋 누락은 패키지 빌드 단계에서만 포착.
4. **SOUND 측정 JSONL(chromium/ffmpeg/survey)은 구팀 수치** — 이번 도구가 재측정하지 않음(청취 미검수 정책 일치), Mac 실청취 전 채택 불가.

읽기 도구만 사용, 도구 미실행·파일/Git/서버 무변경·PC 접속 없음. QA 실측 종료 및 입력 SHA 확정 전 패키지 실행 대기 유지합니다. 완료 후 종료합니다.
