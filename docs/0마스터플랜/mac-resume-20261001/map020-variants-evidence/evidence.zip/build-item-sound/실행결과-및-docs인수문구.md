# BUILD·ITEM·SOUND 후속 실제 실행 결과

기준 HEAD `bc7cc03756b57fb999a67ca60a29f1fe852df24c`, Mac 실행. 기존 지원 담당 `/root/build_backlog_review`가 처리했으며 새 팀·CLI를 열지 않았다. 코드 소유는 `tools/qa/map020-followup-build/`, 결과 소유는 이 폴더다. 생산 HTML·맵·UI·공용 테스트·docs 원문·Git 인덱스·커밋·원격을 변경하지 않았다.

## BUILD — 정적 인수 실행 완료

`build-audit.py` 결과 **25 PASS / 2 WARN / 0 FAIL**, 종료0. 옵션 누락 `credits.html`, `output/imagegen/forge-tabs-v3`만 WARN이다. 필수 단일파일/디렉터리 존재, 본편69·쉬운판52개 실제 script/link 참조와 패키지 포함 경로, UI 캐시 양쪽 `20261001-combat-status22` 일치, main boundary 태그+가드 호출/easy 태그 없는 가드 호출, 개발 환경변수·패키지3347 격리를 검사했다. 입력95파일 SHA256은 `build-result.json`에 있다.

후보의 고정 cache21을 사용하지 않고 후속 정정을 반영했다. 전체 HTML에 src/href 정규식을 적용하면 인라인 JS 템플릿의 동적 문자열을 파일로 오인할 수 있어 Python HTMLParser로 실제 script/link 태그만 수집하도록 고쳤다. `FILES` 외 `DIRS`와 옵션 디렉터리도 검사한다.

한계: Windows x64 빌더 계약의 **소스 검사**다. NW.js 빌드·Mac 패키지·전체 에셋 폴더 해시·HTTP 로드·저장 재실행·프레임 성능 검수가 아니다. 개발3340은 운영 계약이며 이 도구가 실행 프로세스를 검증한 값이 아니다.

## ITEM — 1개 소스 결함 재현

`item-audit.cjs` 결과 **25 PASS / 1 FAIL**, 종료1. 결함을 숨기지 않는 것이 검사 도구의 정상 동작이다. 두 HTML의 실제 스킨 함수·상수를 AST 추출해 이미지 성공/실패·DOM 오류 이벤트를 격리 실행했다.

| 조건 | 본편 결과 | 쉬운판 결과 |
|---|---|---|
| UI-07·벨트·얼음 속성 초기 경로 | `img/ui/item-cutouts/belt_phys_cutout.png` | `output/imagegen/item-skins/belt_ice.png` |
| 최초 이미지 실패 후 경로 | 두 판본 모두 `output/imagegen/item-skins/belt_phys.png` | 동일 |
| 물리 폴백 성공 후 검정 마스킹 | **0회 — FAIL** | **1회 — PASS** |
| 두 경로 모두 실패 | `_worldItemSkin` 반환 null | null |
| DOM 이미지 오류 두 번 | 첫 오류 물리 PNG → 두 번째 img 제거, SVG 형제 남음 | 동일 |

본편 원인: `_worldItemSkin`의 `if(cutoutSrc)return img`가 실제로 로드된 이미지 대신 최초 선택 경로를 근거로 마스킹을 생략한다. 물리 벨트는 PNG colorType2(RGB·알파 없음), 정상 컷아웃은 colorType6(RGBA)라는 헤더도 확인했다. 따라서 실패 시 불투명 물리 배경이 남을 수 있는 소스 결함이다. 실제 화면에서 사각 배경을 관찰했다고 주장하지 않는다.

ITEM 후보의 `transparent=!!(uniqueSrcW||cutoutSrc)`도 초기 경로만 보므로 전용/컷아웃 실패 후 불투명 폴백에 같은 문제가 생긴다. **그 후보를 그대로 채택하지 않는다.** 다음 최소 수정은 로드 성공한 현재 소스의 투명 경로 여부를 추적하거나 원본 선택 경로와 폴백 상태를 비교해, 불투명 물리 폴백에 기존 마스킹을 적용하는 것이다. 총괄이 함수 소유권을 배정한 뒤 별도 변경·회귀·실화면 확인이 필요하다.

본편과 쉬운판 스킨이 동일하다는 최초 가정도 정정했다. 쉬운판에는 `_ITEM_CUTOUT_BASES`가 없으며 이를 본편과 같은 코드라고 처리하지 않는다. `uniqueId` 신규 연결·원화 채택·드롭/효과/저장 변경은 없다. `_itemIco`는 경계 스텁이므로 SVG 자체의 그림 품질은 검사하지 않았다.

## SOUND — 후보 인수·경량 디코딩 완료

별도 SOUND SHA `49851bd893c74b502259cf49f6a6457919767465`에서 `audio_review/S-02/`만 새 `sound-receipt-01/` 폴더로 읽기 추출했다. **후보9개+측정3개+README = 13개 / 67,160,083바이트**. 파일별 Git blob 동일성·SHA256·크기는 `sound-result.json`에 보존했다. 작업트리 `audio_review/`나 원본 WAV에 쓰지 않았다.

`ffprobe/ffmpeg`는 없어서 macOS `afinfo`와 CoreAudio `ExtAudioFileRead`를 사용했다. **후보9/9·원본3/3 모두 시작4096프레임을 48kHz·2채널 float PCM으로 메모리 디코딩 성공**, 약0.085초씩이며 전곡 검사가 아니다. Ogg/Opus6개는 전체 컨테이너의 페이지 경계·순서·최종 EOS가 유효했다(CRC는 미검사).

| 대표곡 | 원본 WAV 초 | MP3 메타데이터 초 | OGG 메타데이터 초 | Opus 메타데이터 초 |
|---|---:|---:|---:|---:|
| Ashes Under the Banner | 420.000 | 420.024 | 420.000 | 420.0065 |
| 흰눈의 맹세 | 347.480 | 347.520 | 347.480 | 347.4865 |
| 네메시아의 강림2 | 145.000 | 145.032 | 145.000 | 145.0065 |

컨테이너 길이 차이는 메타데이터 관찰이다. 이를 음질 차이, 실제 전체 디코드 샘플수 차이 또는 루프 공백이라고 단정하지 않는다. Ogg/Opus 최종 granule 기준 길이는 각각 원본과 같았다.

기존 SOUND HTML 후보의 파일명 `Ashes Under the Banner.mp3` 등은 실제 Git 후보명과 다르다. 실제는 `Ashes Under the Banner (Remastered).mp3_256k.mp3`, `.ogg_q6.ogg`, `.opus_160k.opus`이고 다른2곡도 같은 형식이다. 생성·인코딩 대신 정확한 파일명을 인수했다. 브라우저·HTML 청취 도구는 이번 범위에서 배치하거나 열지 않았다.

남은 검수: 동일 출력 장치/볼륨에서 대표3곡의 고역·합창 잔향·네메시아 반복 경계를 실제 A/B 청취하고 브라우저/패키지 재생을 확인한다. **청취·음질·루프 seam·전곡 디코딩·클리핑·게임 반영 PASS는 아니다.**

## docs에 넣을 정확한 변경 문구

아래 문구는 총괄이 관련 docs에 반영할 수 있는 최종 인수안이다. 이 지원 담당은 원문 docs를 수정하지 않았다.

### INTEGRATION_BUILD_TEAM_MASTER.md

> 2026-10-01 Mac 후속 실제 실행: 기준 `bc7cc03756b57fb999a67ca60a29f1fe852df24c`에서 `tools/qa/map020-followup-build/build-audit.py`를 실행해 25 PASS·옵션누락2 WARN·실패0을 확인했다. 본편69·쉬운판52 script/link 참조, 필수 빌드 입력·UI 캐시 상호 일치·boundary easy 가드 no-op·개발3340/패키지3347 격리를 소스로 검증하고 입력95파일 SHA를 남겼다. 옵션누락은 credits.html과 forge-tabs-v3다. 패키징·HTTP·저장 재실행·성능·Mac 배포본 검수는 이번에 수행하지 않았다.

### ITEM_TEAM_MASTER.md 및 UNIQUE_ITEM_GAME_INTEGRATION_CONTRACT_20261001.md

> 2026-10-01 현재 함수 추출 검수: `tools/qa/map020-followup-build/item-audit.cjs`의 격리 VM 검사25 PASS·1 FAIL. 본편 `_worldItemSkin`에서 투명 컷아웃 실패→RGB 물리 PNG 성공 뒤 `if(cutoutSrc)return img` 때문에 마스킹이0회인 결함을 재현했다. 쉬운판은 컷아웃 분기가 없고 같은 물리 폴백을1회 마스킹한다. DOM 오류 두 번의 물리 PNG→img 제거·SVG 형제 보존과 world 양쪽 실패 null은 통과했다. 실제 렌더/이미지 디코딩은 미실시이며 생산코드 미수정이다. ITEM 후보의 초기 `transparent` 고정값도 같은 결함을 보존하므로 실제 성공한 이미지 경로에 따른 알파 처리를 검토한다. 신규22종 채택/uniqueId 연결/드롭/효과/저장 상태는 변경하지 않았다.

### 6사운드디자인.md 또는 SOUND 인수 대장

> 2026-10-01 Mac에서 SOUND SHA `49851bd893c74b502259cf49f6a6457919767465`의 S-02 후보9개·측정3개·README를 고유 출력 경로로 격리 인수했다(13파일, 67,160,083바이트, Git blob/파일 SHA 기록). 원본3곡과 후보9개 모두 CoreAudio 시작4096프레임 디코딩에 성공했고 Ogg/Opus6개 컨테이너 경계·순서·EOS를 확인했다. 이는 약85ms 시작구간 경량 검사이며 전곡·루프·청취·음질 검수가 아니다. 정확한 `(Remastered).mp3_256k.mp3`/`.ogg_q6.ogg`/`.opus_160k.opus` 파일명을 사용했다. 원본 수정·재인코딩·브랜치 병합·게임/패키지 반영은 하지 않았다.

### CHANGELOG_SYNC.md

> Mac 후속 독립 검수 도구3개와 사용/한계 문서를 추가했다. BUILD 정적25 PASS·2 WARN, SOUND 기존 후보9개 격리 인수 및 시작구간 디코딩9/9, ITEM 현재 함수25 PASS·1 FAIL(본편 컷아웃 실패 후 불투명 폴백 마스킹 생략)을 기록했다. 생산 게임·맵·UI·음원·저장 계약은 변경하지 않았다. 상세 결과 JSON과 인수 문구를 보존하고 실제 렌더/청취/패키지 미검수 범위를 분리했다.
