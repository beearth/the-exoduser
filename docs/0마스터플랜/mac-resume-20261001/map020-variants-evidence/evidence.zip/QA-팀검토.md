실제 Read 완료(도구 3파일). 저장된 smoke 결과 파일은 **부재** — 아래 누락에 명시합니다.

## 실제 Read 근거

- **존재 확인**: `tools/qa/map020-followup-observers/`에 `observer.js`·`smoke.mjs`·`README.md` 3개 모두 Read함.
- **부재 확인**: `outputs/map020-variants-20261001/observers/`는 glob 2회 모두 0건 — 디렉터리·저장 결과 **없음**. `smoke.mjs`는 결과를 stdout JSON으로만 출력하고 파일로 저장하지 않음(96~98행). 본 세션은 읽기 전용이라 node 실행 불가 → "smoke 결과 파일" Read는 불가, 대신 `smoke.mjs`가 **무엇을 검증하는지**를 소스로 확인함.
- **포착 메커니즘(핵심)**: `observer.js`는 `window.X` 래핑이 아니라 **동일 classic-script 스코프에서 식별자 자체를 재할당**한다 — `patch(s,'_maskWorldDropBlack', ()=>_maskWorldDropBlack, v=>{_maskWorldDropBlack=v;}, …)`(67행), `_worldDropFxTile`(69행)·`_worldItemSkin`(76행) 동일. setter 직후 `get()!==wrapped`면 `Binding write not observed` 예외로 identity 확인(33행).
- **smoke 검증 내용**(실게임 원문 추출: `const _worldItemSkinCache=new Map();`~`const STAT_SVG=`, 즉 game.html 26345~26412 = 세 함수+캐시 전체를 동일 vm 컨텍스트에 로드, 6~9/32행): `_worldDropFxTile(0,0)` 1회로 `fxTile→mask→getImageData` 계층 생성, `mask.parentId===fxTile.id`(47행)로 **내부 렉시컬 mask 호출 포착**을 증명. 수치 계약: fxTile calls=2·mask calls=1(2번째는 hit라 mask 미진입), `mask.inclusiveMs=20`, `getImageData.selfMs=19`, **Σ selfMs=22**(중복배타, 46행), cache 순서 `['miss','hit']`(48행). 아이템 경로: assetCache `['miss','hit','miss','hit']`, cache `miss/hit/…/cutout-bypass`, mask calls=2(50~56행). notready/oob·limit100에 150콜 `dropped=50`·`stop` 후 `getImageData===originalRead` 원복(57~63행). 2D 메서드는 `stack.length`일 때만 계측(84행) → 드롭 스택 밖 호출 미포착.

## 판정 (이전 "외부계측 불가" 단정 재평가)

- **정정됨**: 이전 세션의 "렉시컬이라 외부 계측 불가" 단정은 **과도했다**. 전역 `window.X` 재할당은 못 가로채지만, **main world·classic-script·같은 스코프에서 식별자( `_maskWorldDropBlack` 등 `function` 선언, 재할당 가능 )를 직접 재바인딩**하면 `_worldDropFxTile` 내부의 렉시컬 호출까지 포착된다. smoke가 실게임 원문으로 이 계층·배타시간·캐시를 PASS 계약으로 못박아 둠(Node vm 한정).
- **도구가 이미 자기정정**: `README.md` §수치의미의 "후보의 lexical 주장" 행이 "lexical이라 외부 계측 불가라는 단정은 쓰지 않음, `parent:null`은 미포착 경로만 의미"라고 명시 — 이전 blind spot(부모 귀속 없는 `getImageData`)은 `stack` 기반 parentId로 메워짐.
- **수치 의미 보존 타당**: inclusive 합산 금지·`selfMs`만 합산·mask self는 순수 픽셀루프 아님·getImageData는 CPU 경과시간(GPU 아님)·cutout-bypass 분리 — 모두 이전 패치 후보 의도와 일치하며 PC329ms/21ms 판정은 하지 않음(명시됨).

## 잔여 (미검증·제약)

- **실브라우저 미실행**: 실제 game.html이 classic 전역 스크립트인지, CDP `Runtime.evaluate`가 main world로 평가되는지, 식별자 재할당이 런타임에서 실제로 내부 호출을 가로채는지는 **브라우저 미검증**(smoke는 vm mock Canvas·synthetic update/draw뿐, GPU/GL/부팅/성능/시각 없음). module/isolated world/`window.X` 경로면 여전히 불가.
- **출력 경로 미생성**: `outputs/map020-variants-20261001/observers/` 미존재 → 총괄 브라우저 실행(stop/report JSON, `running:false`·`conflicts:[]`·`samplingErrors:0`·`dropped:0`)로 생성 대기.
- **실게임 root 1개·브라우저 대기**: 본 CLI는 브라우저 도구 없음 → 설치/회수/실측은 총괄 단독. 나는 읽기만 수행, smoke 미실행(node 권한 없음).
- **동시 실행 주의**: VFX는 전체 적 update/draw 전후 샘플링으로 비용이 커 밀집전투 성능 측정과 동시 설치 금지(README §경량검사 상단).

별도 팀 생성·trust/security 변경 없음. 읽기 전용 유지. 실측 인계 대기합니다.

smoke-result.json 실제 Read 완료. 경로 정정 반영한 최종본을 제공합니다.

---

# MAP020-variants 관측도구 증거 검토 — 최종본 (2026-10-01, 읽기 전용)

## 경로 정정

- **이전 보고 오류**: "`outputs/map020-variants-20261001/observers/` 부재, 출력 경로 미생성"이라 보고했으나, 이는 **프로젝트 상대경로만 확인한 오판**이었다. 결과는 **절대경로** `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/observers/smoke-result.json`에 **실제 존재**하며 Read로 확인함. 상대경로 부재 단정을 철회한다.

## 실제 Read 근거

- **도구 3파일**(프로젝트 내): `tools/qa/map020-followup-observers/observer.js`·`smoke.mjs`·`README.md` Read 완료.
- **저장된 smoke 결과**(절대경로): `smoke-result.json` Read — `status:"PASS"`, `checks:10`(10/10), 10개 테스트명 전부 `smoke.mjs`의 테스트와 일치. `gameSHA256: a7a1b45fb1188e7650459c9998b552dad02b75a0618f88eae59324690ac9d402`. `scope:"Node vm: actual extracted game drop functions with mock canvas; synthetic update/draw. No browser/GPU/gameplay performance or visual validation."`
- **포착 메커니즘**: `observer.js`는 `window.X` 래핑이 아니라 **동일 classic-script 스코프에서 식별자 자체를 재할당**한다(`()=>_maskWorldDropBlack`, `v=>{_maskWorldDropBlack=v;}`, 67행; `_worldDropFxTile` 69행·`_worldItemSkin` 76행). setter 직후 `get()!==wrapped`면 예외로 identity 검증(33행). 2D 메서드는 `stack.length`일 때만 계측(84행)해 드롭 스택 외 호출은 미포착 → 이전 `parent:null` 사각이 parentId 기반으로 해소.
- **smoke 검증 범위**: 실게임 원문(`const _worldItemSkinCache=new Map();`~`const STAT_SVG=`, game.html 26345~26412 = 세 함수+캐시 전체)을 동일 vm 컨텍스트에 로드(6~9/32행). 핵심 계약 — `mask.parentId===fxTile.id`(내부 렉시컬 mask 포착 증명), `mask.inclusiveMs=20`, `getImageData.selfMs=19`, **Σ selfMs=22**(배타), cache `['miss','hit']`(41~48행); 아이템 assetCache `['miss','hit','miss','hit']`·`cutout-bypass`·mask calls=2(50~56행); `dropped=50`·`getImageData===originalRead` 원복(57~63행); dispose conflict 보존(87~91행).

## 판정 (근거 정정 반영)

- **"외부계측 불가" 단정 철회 유지**: 이전 세션의 렉시컬 단정은 과도했다. **main world·classic-script·동일 스코프 식별자 재바인딩**이면 `_worldDropFxTile` 내부 `_maskWorldDropBlack(...)` 렉시컬 호출까지 포착되며, 이제 **디스크에 저장된 10/10 PASS 증거(`smoke-result.json`)로 뒷받침**된다(이전엔 미실행 주장만 가능했음). `window.X` 재할당·module·isolated world 경로는 여전히 불가라는 좁은 제약만 성립.
- **수치 계약 타당**: inclusive 합산 금지·`selfMs`만 합산·mask self는 순수 픽셀루프 아님·getImageData는 CPU 경과시간(GPU 아님)·cutout-bypass 분리 — README §수치의미와 일치. PC329ms/21ms 원인·개선 판정은 하지 않음(scope에도 명시).
- **도구 자기정정 확인**: README의 "후보의 lexical 주장" 행이 "lexical이라 외부계측 불가라는 단정 미사용, `parent:null`은 미포착 경로만 의미"라고 이미 기록.

## 잔여 (미검증·제약)

- **vm 한정 증거**: `smoke-result.json`의 PASS는 **Node vm + mock Canvas + synthetic update/draw**일 뿐이다(scope 명시). **실제 브라우저/GPU/GL 렌더·정규부팅·프레임 성능·시각 검수는 미포함**. 실게임이 classic 전역 스크립트인지, CDP `Runtime.evaluate`가 main world인지, 런타임 식별자 재바인딩이 내부 호출을 실제로 가로채는지는 **브라우저 raw로 확정 대기**(사용자: 곧 제공).
- **SHA 대조 TODO**: `gameSHA256 a7a1b45f…ac9d402`는 smoke가 읽은 game.html 기준. 실브라우저 실측 시 로드된 소스 SHA와 동일한지 대조 필요.
- **실측 소유**: 관측도구 설치/회수(stop/report, `running:false`·`conflicts:[]`·`samplingErrors:0`·`dropped:0`)와 실게임 root 1개 실행은 총괄 브라우저 단독. 본 CLI는 브라우저 없음 → 읽기만 수행, node 미실행.
- **동시성**: VFX는 전수 샘플링 비용이 커 밀집전투 성능 측정과 동시 설치 금지(README).

별도 팀 생성·trust/security 변경 없음. 읽기 전용 유지. 실제 브라우저 raw 수신 후 대조 인계 대기합니다.

browser-drop.json·browser-vfx.json 실제 Read 완료. 최종 합산 검토와 한계입니다. (읽기 전용, 미실행·미수정)

## DROP (12초, 6057 rows) — byLabel 실측

| label | calls | inclusiveMs | selfMs |
|---|---|---|---|
| fxTile | 1428 | 33.3 | 1.6 |
| itemSkin | 4621 | 7.2 | 7.2 |
| mask | **2** | 31.6 | 1.9 |
| 2d.getImageData | 2 | **29.6** | 29.6 |
| 2d.drawImage | 2 | 0.1 | 0.1 |
| 2d.putImageData | 2 | 0.1 | 0.1 |

`dropped:0`, `conflicts:[]`, `running:false`.

## 합산 검토 (중복 배제 검증)

- **rows 정합**: 1428+4621+2+2+2+2 = **6057** ✓.
- **inclusive 합산 금지 — 중첩 확인**: `fxTile 33.3 ⊋ mask 31.6 ⊋ getImageData 29.6`. 세 값을 더하면 삼중 계상. 개별 miss에서도 계층 보존됨 — miss#1 `fxTile incl 19.0 ⊃ mask 18.8 ⊃ getImageData 17.2`(mask self 1.5), miss#2 `12.8 ⊃ 12.8 ⊃ 12.4`(mask self 0.4).
- **올바른 합 = selfMs만**: 1.6+7.2+1.9+29.6+0.1+0.1 = **≈40.5ms**(12초 전체 래핑 동기 CPU). 이 중 **getImageData readback 29.6ms = self합의 73%**, 그리고 그 29.6은 **2회 miss의 합(17.2+12.4), 개별값 아님** — 사용자 명시와 일치.
- **miss/hit/재사용 분리**: fxTile 1428콜 중 **miss 2회만**(그래서 mask·getImageData·draw·put 각 2), 나머지 1426은 캐시 hit로 self 합 1.6ms. itemSkin 4621콜은 mask를 0회 유발(mask calls 2는 전부 fxTile 경유) → 아이템 스킨은 전부 hit/cutout-bypass/notready, 월드아이템 소수(≈6종) 반복 재사용. **결론: 빔타일 첫 등장(티어별 1회) 512² readback이 드롭 경로 CPU를 지배하며 일회성이다.** 밀집·반복 프레임 비용 아님.

## VFX (10초) — 실측과 구조적 한계

- `draws 1188 / pageRafs 1188 / updates 602 / records 70 / samplingErrors 0 / dropped 0 / conflicts:[] / running:false` ✓. updates 602≈60.2/s(physStep16.667=60Hz 고정), draws≈118.8/s(cap0 무제한).
- **GL 수명 PASS 불가 — 게이트 구조적 실패**: 전 records에서 `useGL:false, contextLost:true, runtimeGate:false, glDrawEvidence:false, glMode 0/null`. 이 빌드는 **WebGPU 경로**(dense env의 `gl:false, gpu:true`)이므로 관측기의 **WebGL 게이트(`_useGL`/`GL.isContextLost()`)는 애초에 성립 불가** — `regularBootAttested:true`여도 GL 증거는 나올 수 없다. 즉 이 결과는 **WebGPU 렌더 정상 여부를 반증하지 않으며**, 관측기의 GL 수명 PASS는 이 렌더러에 적용 불가(도구 한계, 게임 결함 아님).
- **부활 0 / 사망·플래시 0**: `transitionRows:[]`, 전 records `hf:0`·events는 install의 60개 first-observed와 이후 10개 신규 스폰 first-observed뿐. **10초 창 안에 death/revive/flash 전이가 관측되지 않음** → VFX 수명·부활 주장은 이번 실행으로 미측정.

## 최종 한계

1. **DROP**: miss 표본 2회로 소수. getImageData는 **CPU readback 경과시간**(mask의 getContext에 `willReadFrequently` 설정됨에도 512² 12~17ms) — GPU 시간 아님. 티어별 일회성, 프레임 반복 비용 아님. **PC329ms와 무관·원인확정 금지.**
2. **VFX**: WebGPU 런에서 GL 게이트 무효 + 창 안에 전이 부재 → 사망/부활/플래시 수명은 **재측정 필요**(처치가 창 안에서 실제 발생하고, WebGPU에 맞는 게이트로). 새 객체는 구울 부활로 분류 안 됨(first-observed로만).
3. **공통**: 래퍼 오버헤드 포함 → 프레임 성능 ABAB 본표 합산 금지. 직렬 실행 후 `dispose`·`running:false`·`conflicts:[]` 확인됨(상호 오염 없음). 시각/가독성/게임플레이 수치 검수는 이 도구로 대체 불가.

별도 팀·trust/security 변경 없음. 읽기 전용 유지. 다음 인계 대기합니다.
