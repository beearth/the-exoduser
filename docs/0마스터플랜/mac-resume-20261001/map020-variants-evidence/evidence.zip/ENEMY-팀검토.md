지정 경로를 읽기 전용으로 독립검토합니다. 먼저 해당 경로들의 실제 존재 여부와 파일을 확인하겠습니다.

`tools/qa/map020-followup-gameplay/` 6개 파일 존재, `outputs/map020-variants-20261001/gameplay`는 **존재하지 않음**. outputs 경로 상태와 ENEMY 관련 핵심 파일을 확인하겠습니다.

`enemy.test.js`가 바로 이 과제의 핵심 — forced windup edge(0발) vs 정상 idle charged(발사함) 구별을 담고 있습니다. 어떤 파일(변형본 포함)을 대상으로 하는지 `source.mjs`를 읽어 근거를 확정하겠습니다.

대상 파일은 `game.html` + `game-easy-test.html` 2종(변형본)이며 실제 파일을 `readFileSync`로 읽습니다. 변형본 존재와 테스트가 의존하는 소스 앵커(`_noProjEtypes`, 티켓 카운터, etype3 제외 여부)를 확인하겠습니다.

모든 근거 확인 완료. `_noProjEtypes`에 **etype3 미포함**(29642행 `{5,9,11,20,24,50~59}`)이 "전혀 발사 안 함" 가설 정정의 결정적 소스 근거입니다. 독립검토 결과를 보고합니다.

---

## 1. 경로 존재 상태 (실제 Glob/Read)

| 경로 | 상태 |
|---|---|
| `tools/qa/map020-followup-gameplay/` | **존재** — 6파일: `source.mjs` `anchors.test.js` `enemy.test.js` `skill.test.js` `balance.test.js` `evidence.mjs` |
| `outputs/map020-variants-20261001/gameplay/` | **부재** — `outputs/` 디렉터리 자체가 없음(Glob `outputs/**` → No files) |

→ gameplay 산출물은 **아직 미생성**. `evidence.mjs`는 argv[2] 절대경로에 `enemy-state-paths.json`+`source-manifest.json`을 **쓰는 생성기**이고, `enemy.test.js`는 증거를 `console.log` stdout에만 남긴다. 둘 다 실행되어야 outputs가 생긴다. 나는 읽기전용·쓰기/실행 금지이므로 생성하지 않았다(아래 §4 명시).

## 2. Read 근거 (대상 = 실제 2파일)

- `source.mjs:6` `files=['game.html','game-easy-test.html']`, `:7` `readFileSync`로 **실파일 로드**. 두 변형본 모두 존재 확인(Glob). `game.html` 의존 앵커 실재 확인:
  - `15780` `atkTickets:0,maxAtkTickets:3` (티켓 카운터, 테스트 `:25` 앵커)
  - `29642` `window._noProjEtypes={5:1,9:1,11:1,20:1,24:1,50~59}` — **etype3(요마) 미포함** → 원거리 차지 발사 대상
- `enemy.test.js`: **전체 `updateE`를 VM에서 그대로 실행**(`:33`), 지오메트리/렌더/사운드만 명시 스텁, 누락 의존은 noop이 아니라 throw(`:7` 주석). `_spawnBossProjectile`→`calls.edge`, `spawnProj`→`calls.charged`, `hurtP`→`calls.contact`로 분리 계측(`:21-22`).

## 3. 판정 — forced 0발 vs 정상 idle charged 발사 구별

| # | 테스트(enemy.test.js) | 입력/경로 | 계측 | 의미 |
|---|---|---|---:|---|
| T1 `:51` | **유도(forced) windup 진입** "induced entry, **not** natural attack proof" | etype{0,3}×sp{0.25…6}, `projT=9999`로 차지 차단 | edge = etype3 **0** / etype0 **1** | 근접 에지 단발 디텍터: etype3 진입 `st2=5`(=임계값)이라 `st2+sp>5` 미충족 → **강제 윈드업시 근접 0발** |
| T2 `:64` | **정상 idle 301tick** "etype3 natural idle path **can fire** via charged projectile (**not an attackless enemy**)" | etype3, `projT=0` 자연 경로 301틱 | **charged ≥1**, edge 0, contact 0 | etype3은 idle→charge→`_fireChargedProj`로 **원거리 발사함** |
| T3 `:74` | 기존 `eCircle→windup` 경로 | etype3 | edge 0(잠재 누락 보존) | 근접 에지 누락은 유지되나 비치명 |

**정정 결론:** 이전 '요마(etype3) 전혀 발사 안 함 / 실질 공격 누락(설계=1,현행=0)' 가설은 **오류**. 정확히는:

- **근접 에지 경로(`_spawnBossProjectile`)** 는 etype3이 임계값 경계(`st2=5`)로 진입해 **유도 윈드업시 0발** — 이 슬라이스만 보면 "누락"처럼 보였음.
- 그러나 **전체 updateE 경로**에서 etype3은 `_noProjEtypes` 비포함 → **정상 idle에서 원거리 차지 투사체(`spawnProj`/`_fireChargedProj`)로 발사**한다. 301틱 내 1회 차지 발사 계측. → **공격 없는 적이 아님**.
- 즉 "forced windup 0발"과 "정상 idle 301tick 1발"은 **서로 다른 공격 경로**이며, etype3의 주 공격 출력은 근접 에지가 아니라 원거리 차지다. 근접 에지 누락은 실재하나 etype3에겐 비치명(T3).

테스트 T1 타이틀이 스스로 "induced entry, not natural attack proof"로 한정해 두어, 유도 재현을 자연 공격 증명으로 과대해석하지 말 것을 소스에 고정해 둔 점도 검토상 적절.

## 4. 잔여·누락 보고

- **outputs 미생성**: `outputs/map020-variants-20261001/gameplay/` 부재. `evidence.mjs` 실행 + `node --test tools/qa/map020-followup-gameplay/` 실행 시에만 `enemy-state-paths.json`·`source-manifest.json`·stdout JSON(inducedEdge/natural/inducedCircle)이 생성됨. **생성 주체 = 총괄/QA** (나는 쓰기·실행 금지).
- **런타임 PASS/FAIL 미수집**: 읽기전용 유지로 node 미실행. 본 판정은 소스 앵커 실재(15780/29642/`updateE switch(e.s)`/39566·39567 에지)와 테스트 로직 정합성 **Read 검증**에 한정. 실제 통과 여부·sp 스윕 증거 JSON은 실행 후 확정 필요.
- **미검토 파일**: `skill.test.js`·`balance.test.js`는 ENEMY 소유 밖(스킬/밸런스) — 본 ENEMY 검토 범위에서 제외, 미읽음 명시.
- **변경 없음**: game.html·game-easy-test.html·docs·outputs 무수정, Git 무변경, 게임 미실행, 별도 팀 생성·trust/security 변경 없음.

독립검토·가설 정정 완료. 종료합니다.

절대경로의 실제 실행 산출물을 읽겠습니다. 이전 보고는 상대 `outputs/` 부재만 확인했으나, 지정된 절대경로를 직접 Read합니다.

산출물 존재 확인. ENEMY 핵심 실행 증거를 읽겠습니다.

실행 증거 확보. AST 경로 산출물도 근거로 확인하겠습니다.

절대경로 실행 산출물 전체를 Read 완료. 이전 보고(§"outputs 부재·런타임 미수집")의 **근거 자체를 정정**해 최종본문을 제공합니다.

---

# MAP020-variants gameplay 실행증거 검토 — 최종본 (ENEMY)

## 0. 근거 정정 (이전 → 현재)

- **이전 보고 근거**: 상대 `outputs/` 부재만 확인 → "gameplay 산출물 미생성·런타임 PASS/FAIL 미수집, 소스 Read 정합성만". 
- **정정된 근거**: 지정 **절대경로** `…/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/gameplay/`에 **실제 실행 산출물 11개 존재** → 아래는 전부 실행증거 JSON/로그 **Read 기반**. (상대 `outputs/`는 결과 저장처가 아니었음 — 경로 오인이 정정됨.)

## 1. 실행 환경 (source-manifest.json Read)

| 항목 | 값 |
|---|---|
| observedAt | `2026-10-01T06:26:20.104Z` |
| node | `v24.15.0` |
| git HEAD | `bc7cc03756b57fb999a67ca60a29f1fe852df24c` |
| game.html sha256 | `a7a1b45f…9d402` |
| game-easy-test.html sha256 | `2e133bda…09a0c` |
| productionWrites / browserRuns / newAgents | **0 / 0 / 0** |

## 2. 판정표 — 강제 windup 0발 vs 정상 idle 차징 1발 (실행 JSON Read)

`enemy-first-run.txt`(4/4 PASS) + `final-tests.txt`(35/35 PASS), **game.html·game-easy-test.html 동일**:

| 경로 | 테스트 | 실측 계측 | 판정 |
|---|---|---|---|
| **강제(induced) windup** | T1 "induced entry, not natural attack proof" | etype0: sp{0.25…6} 전부 `shots:1` / **etype3: 전부 `shots:0`** (ticks 2~24) | 근접 에지는 etype3 진입 `st2=5`=임계라 전 sp에서 **0발** |
| **정상 idle 301tick** | T2 "can fire via charged projectile (not an attackless enemy)" | **`{"states":["idle"],"charged":1,"edge":0,"contact":0}`** | etype3는 idle 유지한 채 **원거리 차징 1발** |
| **기존 eCircle→windup** | T3 "preserves etype3 latent edge omission" | `{"states":["windup","attack","recover"],"edge":0}` | 강제 전이시 edge 누락 보존(비치명) |

## 3. AST 경로 근거 (enemy-state-paths.json Read) — 정정의 핵심

`updateE` 내 **모든 `e.s='windup'` 대입 16개를 AST 워크**한 결과, idle→windup 진입 게이트는 etype **{5,10,35,37,41,50,51,52,54,58,90,91,94,97}** 와 범용 `eCircle`(`dst<e.r+30 && atkTicketRequest`)뿐 — **etype3(요마) 전용 windup 진입 조건은 존재하지 않음**.

→ etype3는 정상 플레이에서 **windup→attack 근접 에지 경로에 애초에 진입하지 않는다**. 그 경로는 테스트의 인위적 주입(`state:'windup'`) 또는 근접+티켓 eCircle로만 도달. 정상 공격 출력은 idle 내부의 원거리 차징(`spawnProj`/`_fireChargedProj`).

## 4. 정정 결론

- 이전 가설 **"요마 전혀 발사 안 함 / 실질 공격 누락(설계=1,현행=0)"** 은 **오류로 확정 정정**.
- 정확한 사실(실행증거):
  1. **강제 windup 진입 → 근접 에지 0발**(etype3 경계값 `st2=5`, 전 sp). etype0은 1발 — 에지 디텍터 자체는 건전.
  2. **정상 idle 301tick → 상태 `["idle"]` 단일 유지, 원거리 차징 정확히 1발**, edge·contact 0. → etype3은 **원거리 공격 적**이며 attackless 아님.
  3. 근접 에지 누락(etype3)은 실재하나 **정상 경로 미진입 + 원거리 차징이 주 공격**이라 비치명. eCircle 유도시에만 노출(T3 보존).
- 즉 "정상idle301tick차징1발"과 "강제windup0발"은 **완전히 다른 공격 경로**이며, 실행증거가 이를 결정적으로 분리함.

## 5. 잔여·제약

- **읽기전용 유지**: Glob/Read만 사용. 산출물은 총괄/QA가 head `bc7cc037`에서 사전 생성(06:26Z)한 것을 **읽어** 확인했을 뿐, 내가 `evidence.mjs`·`node --test`를 **실행하지 않음**. game/docs/outputs/Git 무변경, 별도 팀·trust/security 변경 없음.
- **범위 밖 산출물**: `skill-first-run.txt`·`balance-*`·`docs-추가문구.md`·`게임플레이-후속검수.md`는 ENEMY 소유 밖(스킬/밸런스/문서) — 본 검토 미반영, 미읽음 명시.
- **미해결(QA/총괄 소유)**: etype3 근접 에지 누락을 결함으로 "수정"할지 여부·수정안은 공용 update 소유인 QA 판단 대기. 수치·배율·티켓·패턴·공용 HTML 변경 없음.

검토·근거 정정 완료. 종료합니다.
