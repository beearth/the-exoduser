소스 조사를 완료했습니다. R 입력 경로의 실제 구조를 근거로, 게임 결함 단정 없이 root 실브라우저 입력표에 필요한 게이트를 제시합니다.

---

# R-input 20261001 — R 입력 재현 요소 소스 조사 (읽기 전용)

## 0. 선행 Read·누락
- Read 완료: `AGENTS.md`, 프로젝트 `CLAUDE.md`(시스템 리마인더), `docs/0마스터플랜/mac-resume-20261001/item-fallback-evidence/다음작업-감사.md`.
- **누락 명시**: "자기팀대장"에 해당하는 `.claude/agents/*.md`는 repo에 **미존재**(Glob 0건). R-input 전용 팀대장 문서도 없음 — 가장 가까운 근거는 감사문서 §4·§5(“R키 짧은 입력 일부 누락” 별도 관찰)와 입력 바인딩 SSOT(`docs/3.3 키바인딩+설정/`, 이번 미열람).
- HEAD는 배정상 `dd3bdc18`(git 조회 미실행 — 아래 미실행 참조).

## 1. R 입력 경로 소스 구조 (사실)
| 요소 | 소스 근거 |
|---|---|
| R = interact 바인딩 | `BINDS.interact:'KeyR'` (game.html:6066), 기본복원도 동일(:46792) |
| 메인 키다운 핸들러 | `addEventListener('keydown',…)` window 레벨 (:12570), keyup (:12722) |
| 키상태 셋 | 핸들러 말미 `K[e.code]=true;KH[e.code]=true` (:12607) — **code 기반** |
| "just" 판정 | `_chkJust(b){… if(K[b]){K[b]=false;return true}return false}` (:13678) — `K`를 **읽고 소비(즉시 false)** |
| interact 소비 | `isJust('interact')` → update 루프 `// Pick up items with R` (:31278), 홀드 `isHeld('interact')`(:31406) |
| KH 성격 | `KH` = keyup에서만 해제, isJust가 소비 안 함(:12261); interact는 KH 아닌 K 기반 |
| 탭 버퍼 | shield만 `_sdTapBuf=G.frame` 서브프레임 탭 보존(:12609). **interact(R)에는 동등 버퍼 없음** |
| 루프/FPS 캡 | `if(OPT.fpsCap){… if(_elapsed<_fpsCapInterval-1){raf;return}}` 프레임 스킵(:59469-59473); 고정 물리스텝 `while(_acc>=PHYS_STEP)`(:59540) |
| blur/hidden | `_clearHeldInput()`가 K·KH·MB 전부 clear(:12761-12771) |

## 2. 요청 요소별 소스 사실
1. **key vs code**: 전 경로 `e.code`('KeyR') 기준(:6066/12607/13678). 키보드 레이아웃(AZERTY·Dvorak)·IME 한/영 토글은 `e.code`를 바꾸지 않음 → **물리키 기준, 레이아웃/언어에 강건**. 코드레벨 유일 실패는 일부 브라우저가 IME 조합 중 `e.code=''`·`keyCode=229`를 내보내는 경우.
2. **IME(isComposing)**: `isComposing`은 game.html에 **참조 0건**. 메인 핸들러에 IME·조합 가드 없음. 게임 캔버스에 상시 텍스트 입력이 없어 통상 IME가 R을 가로채지 않으나, 설정 입력(input/select)에 포커스+IME 조합 시 가드 부재로 K가 셋될 수 있음(양방향 로깅 필요).
3. **포커스**: window 레벨 리스너. 포커스 이탈 시 keydown 미수신 → R 미도달. blur/visibilitychange에서 `_clearHeldInput`로 K·KH clear(:12770-12771) → blur 후 stale R 없음(대신 blur 중 R은 유실). `document.hasFocus()`/`activeElement`가 판정에 필요.
4. **키바인딩 패널(listeningBind)**: 리바인드 청취 중 keydown을 새 바인딩으로 소비 후 `return`(:12589-12597) → 그때 R은 interact 아님(설계). 설정 패널이므로 동시에 G.paused.
5. **인벤토리/설정 열림**: `togglePanel`/`openPanel`가 패널 ON 시 `G.paused=true`(:42292-42293), closePanel에서 false(:42321). 또 포커스가 패널 버튼/입력일 때 Space/Enter/Tab만 early-return(:12606) — **KeyR는 early-return 아님** → 패널 중에도 K['KeyR']은 셋됨. 단 interact 소비(:31278)는 update 경로라 G.paused 중 미실행.
6. **paused/on**: interact 블록(:31278)은 update 내부 → `G.paused`·`G.on` 영향. 패널 open 중 R은 무시(설계). 패널 close로 재개 시, 패널 중 눌린 K['KeyR'] 잔류가 재개 첫 프레임 `_chkJust`에 소비될 "유령 트리거" 가능성(기록 필요, 단정 아님).
7. **optFps(정규 옵션)**: `OPT.fpsCap`(:6153 기본0), `$('optFps')` 정규 옵션이 `_FPS_STEPS`로 설정(:47087). 캡 설정 시 루프가 프레임 스킵(:59472). 스킵 구간에 keydown+keyup이 모두 들어오면 `K['KeyR']`가 셋→(소비 전) keyup에서 clear → `_chkJust`가 **그 프레임을 샘플 못 함** → R 누락 가능. **캡이 낮을수록 프레임 간격↑ → 서브프레임 R 탭 유실 확률↑**. (shield와 달리 interact엔 탭 버퍼 없음 — §1.)

> 위 5·6·7은 감사문서의 "R 짧은 입력 일부 누락" 관찰과 정합하는 **재현 가설**이며, 이 조사만으로 게임 결함으로 단정하지 않음. 확정은 아래 게이트 입력표로 검증.

## 3. root 실브라우저 입력표에 필요한 Gate (제안)
R keydown/keyup/프레임 샘플을 1건마다 아래 컬럼으로 기록해야 원인 귀속이 가능:

**(A) 이벤트 게이트(per keydown/keyup)**
- `e.code`(=KeyR?), `e.key`, `e.keyCode`(229 여부), `e.isComposing`, `e.repeat`, `e.ctrlKey/metaKey/altKey`(Ctrl+R early-return :12585-12587), `type`(down/up), `timeStamp`.

**(B) 상태 게이트(이벤트 시점 스냅샷)**
- `document.hasFocus()`, `document.activeElement.tagName/ id`, `G.on`, `G.paused`, `listeningBind`(truthy?), `#invPanel.on`·`#settings.on`·`skillPanel/forge/statPanel` open 여부, `OPT.fpsCap` 현재값, 실측 FPS, 입력모드(`_gpActive` 패드/kbm).

**(C) 프레임 상관 게이트(결과 귀속)**
- keydown→keyup 간격(ms), 그 사이 경과한 update 프레임 수(0이면 서브프레임 탭), 직후 update에서 `isJust('interact')` 관측 true/false(=소비 여부), K['KeyR']·KH['KeyR'] 전후값, `_usePlayerPortal()` 동시성(:31278 분기).

**(D) 재현 매트릭스(교차 조건)**
- fpsCap: 0(무제한)/저캡(예 30·24) × R탭 길이(초단타/일반) → 누락율.
- 포커스: 캔버스 포커스/다른 요소·창 포커스 × R.
- 패널: 없음/인벤열림/설정열림/리바인드청취 × R → 소비 여부·재개 후 유령 트리거.
- IME: 영문/한글 조합 상태 × 포커스 텍스트입력 유무 × R → e.code·isComposing·K 반영.

각 셀에 (A)(B)(C) 로그를 남기면, 누락이 **포커스/패널/Ctrl(early-return) 때문인지** vs **서브프레임+fpsCap(탭버퍼 부재) 때문인지** vs **IME 코드공백** 인지 분리 귀속 가능.

## 4. 검수 전제 / 미실행 구분
**검수 전제(이번 확인한 소스 사실)**: 바인딩·핸들러·`_chkJust` 소비 방식·KH/K 성격·탭버퍼 부재·FPS 캡 스킵·패널 pause·blur clear 라인은 모두 game.html 실 Read 근거(§1 라인).

**미실행(이번 범위 밖)**:
- 실브라우저·게임·입력 이벤트 실측, 위 입력표 실데이터 수집 — 미실행(브라우저/게임 금지).
- Git HEAD `dd3bdc18` 대조·커밋 — 미실행(Git 금지).
- `index.html`/쉬운판(`game-easy-test.html`)·게임패드 synth(`10:'interact'` :12823, L3) 경로의 동일성 — 미확인.
- IME 조합 중 `e.code` 실제 브라우저별 동작(Chrome/Mac) — 소스 가드 부재만 확인, 실동작 미측정.
- 바인딩 SSOT(`docs/3.3 키바인딩+설정/`) 수치 대조 — 미열람.
- 출력 파일 작성(`outputs/r-input-20261001`) — **미작성**(파일 변경 금지; root 작성 몫. 본 보고 본문을 인계).

## 5. 준수
Read/Glob/Grep만 사용. 파일/HTML/Git/게임/브라우저/인코딩/빌드/새 팀/trust 변경 없음. 기존 상단 UI(COMBO 스트립 등) 재검 안 함. 중복 팀 없음. 게임 결함 단정 없이 재현 게이트만 제시.