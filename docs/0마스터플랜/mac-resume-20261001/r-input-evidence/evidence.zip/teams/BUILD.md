앞 업무(INT-004 사전검토) 종료 확인하고 후속 실행 결과를 이어받았습니다. `asset-manifest.json`·`실행결과.md`를 읽고 LFS 포인터 3파일을 각각 repo 전수 grep으로 분류했습니다. Read/Glob/Grep만 사용, LFS 다운로드·수정·파일/Git 무변경.

## LFS 포인터 3파일 분류 (read 근거)

**① `assets/map/ch1/production_finish/CH1_1_PRODUCTION_MASTER.png` → 제작 원본**
- 참조처: `tools/build_ch1_production_finish.mjs`, `tools/build_ch1_floor_unification.mjs`(빌드 시 베이크 생성 도구), `test/vercelUpload.test.js`, `docs`(VERCEL_UPLOAD_FAILURE·PUBLISH_20260928_LFS_HISTORY), `.gitattributes`.
- **game.html·런타임 JS·maps_data.js·layout.js에 직접 로드 없음**(정확 파일명 grep에 game.html 불포함). 8192² 마스터를 64개 청크(`baked_spike/.../chunk_N_N.png`, 매니페스트상 전부 `lfs_pointer:false`)로 분할한 **오프라인 베이크 원본**. 런타임은 분할 청크를 로드.

**② `assets/map/ch1/production_finish/outer76_81-provenance.zip` → 출처 자료**
- 참조처: `docs`(OUTER81_FILES 행 — "76~81차 오프라인 출처를 묶음: 각 pass/input-base·edited_connection·crop·generation.json·prep.json 총30+manifest=31엔트리, SHA대조"), `.gitattributes`, `CHANGELOG_SYNC`.
- 코드/런타임 참조 **0**. ZIP 아카이브라 런타임 로드 불가. 생성 출처 보존용 **provenance 자료**.

**③ `assets/map/ch1/production_finish/outer90_sources/outer90_patch.png` → 제작 원본**
- 참조처: `docs`(MAP_IMPROVEMENT_PROJECT:132 "원본 소스 … 8192×8192", BOUNDARY_PASS95:17 "BAKE-95 … 8192² master와 64개 1026² 청크"), `composition.json:183`·`retouch-layers.json:182`(베이크 합성 매니페스트의 `"file"` 입력), `.gitattributes`.
- **런타임 직접 로드 없음.** `ch1-border-foreground.js:99`가 참조하는 것은 같은 폴더의 **다른 파일** `rotforest_mass_0{variant}.png`(매니페스트상 LFS 아님, 실바이트)이지 `outer90_patch.png`가 아님. 이 패치는 composition/retouch 매니페스트를 통해 청크로 구워지는 **빌드 입력 원본**.

## 판정
- **3파일 모두 런타임 직접 참조 아님** — 2개는 베이크 제작 원본(8192² master/patch), 1개는 provenance ZIP. 런타임이 실제 로드하는 CH1 베이크 청크·mass/root 스프라이트는 매니페스트상 전부 실바이트(`lfs_pointer:false`).
- 따라서 exit1(LFS 포인터 130B가 에셋 바이트 대신 복사됨)은 **런타임 CH1 비주얼에 영향 없음**. 영향 범위는 "재베이크용 원본·출처 아카이브가 패키지에 포인터로 들어감"에 한정 — **실제 패키지 실패로 확대하지 않음**(지시 준수). 플레이 화면 렌더는 분할 청크로 정상.
- `실행결과.md`의 "소스 복사 계약 FAIL"은 **LFS 미해결 상태에서 재귀 복사 시 이 3개가 포인터로 복사된다**는 계약 경고이며, 런타임 자산 결손이 아님.

## 제약·미실행 구분
- LFS 포인터 **자동 다운로드·수정·.gitattributes 변경 없음**(지시 준수). 실제 바이트 내용·픽셀은 미검증(포인터만 확인).
- 실제 통합 패키지 생성·내용 비교·Windows 실행 검수는 미실시(`실행결과.md:29`와 동일). 이 분류는 매니페스트+repo 참조 grep 기반이며 게임 실행 결과가 아님.
- 권고(총괄 소유, 본 세션 미실행): 빌드 전 이 3경로만 `git lfs pull` 또는 LFS 포함 복사로 실바이트 보장하면 제작 원본·출처까지 패키지에 온전. 런타임 플레이에는 선택 사항.

읽기 전용, 무변경 유지. 완료 후 종료합니다.