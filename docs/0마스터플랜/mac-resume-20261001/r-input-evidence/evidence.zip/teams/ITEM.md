조사 완료. 지정 문서·R 수거 코드 경로·획득 증거를 Read 근거로 확인했습니다. 아래는 root가 `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/r-input-20261001`에 저장할 **산출본문**이며, 검수 전제/미실행을 구분합니다.

---

# R-input 재현 fixture 전제 + 관측 필드 최소안 — 2026-10-01

## 1. Read 근거 (실파일)

**R 수거 핸들러:** `game.html` S16 업데이트, 진입 게이트 `if(isJust('interact')&&!_usePlayerPortal())` **31278**. interact 바인드=`KeyR`(6066). 우선순위 체인(실제 순서):
1. **포털 우선** — `_usePlayerPortal()` true면 전체 수거 블록 스킵(31278).
2. **MAP_OBJS 상호작용(우선)** 31280–31304 — bonfire<60/lore<60/breakable<50/altar<60, 각 `break`(루프 1개). **단, chestOpened 플래그를 세우지 않아** 뒤의 아이템 수거를 막지 않음(같은 R 프레임에 MAP_OBJS+아이템 동시 가능).
3. **보물상자(우선)** 31305–31331 — chest<60 → `chestOpened=true` → 잔해/HP/O2/장비 게이트.
4. 잔해<50(31333)·HP 최근접<60(31363)·O2<30(31377), 모두 `!chestOpened`.
5. **장비 아이템** 31383–31393 — **화면 내**(`_sx/_sy ∈ ±(VW/2+40, VH/2+40)`) **최상 rarity 우선·동급이면 근접**, **1회 1개**, `pickupItem()` 성공 시만 `picked=true`.
6. **악의+물약 일괄** 31395–31403 — chestOpened 무관, 화면 내 최대 20개.
7. **홀드 연속줍기** 31406–31429 — `!isJust&&isHeld('interact')`, `_pickHoldT>=9`(sp 단위) 간격으로 5·6 반복.

**가방공간:** `pickupItem`(15559) → `INV.bag.length>=BAG_MAX`면 `notify('가방에 공간이 없습니다!')`·`return false`(44073). BAG_MAX 기본 **300**(3721), 세이브 `bagMax`(3542). 반환 false면 장비는 바닥 잔류(31391).

**필터:** `OPT.minPickRar`(30511)·`_minPickLvThr`(30486,30517)는 **드롭 생성 시점 필터**이며 **R 수거 시점엔 미적용**(지면 개체군만 좌우, R 동작 자체엔 영향 없음).

**획득 증거:** `/Users/.../outputs/item-fallback-20261001/browser-pickup.json` 실측 내용 = `{"bag":12,"normal":true,"fallback":true,"remaining":[],"maskRecords":[{256,256,2.9ms}]}`. → **bag 최종값 12만 기록, before(10)는 json에 없음**(10→12는 `ITEM-폴백마스킹-검수.md:43/97` 본문에만 존재). 감사문서(다음작업-감사.md:97)는 "짧은 R 입력 일부 누락→재입력"을 **별도 입력 경계 관찰**로, 폴백 수정 결함으로 단정 말라고 명시.

## 2. 재현 fixture 전제 (최소안 · 제안)

- **입력 모델 추출:** `isJust`/`isHeld`/입력 큐 폴 함수 + `_usePlayerPortal`·`pickupItem`·`VW/VH`·`BAG_MAX`를 실소스에서 추출해 결정적 틱 구동(브라우저 無). 짧은 입력 누락 재현의 핵심 전제 = **keydown→keyup 간격이 프레임당 `isJust` 소비보다 짧거나 두 폴 경계에 걸치는 타이밍** 모사(엣지 1회 소비 규칙).
- **월드 전제:** `worldItems`에 `type:'item'` 2개(정상 armor + 폴백 belt, `picked:false`), 화면 내 좌표. 가지별 검증용으로 chest(<60)/debris/hp/o2/mat/potion/MAP_OBJS(bonfire 등) 옵션 배치.
- **등급·거리 전제:** (a) 이급+거리 상반 → "최상 rarity 우선" 판정, (b) 동급+거리 상이 → "근접 타이브레이크" 판정.
- **가방공간 전제:** `INV.bag.length` 초기 10, 경계는 `BAG_MAX-2/-1/0`로 설정해 성공/부분/차단(`pickupItem=false`, 바닥 잔류) 재현.
- **우선순위 전제:** `_usePlayerPortal()=true`(전체 스킵) / chest 존재(chestOpened 게이트) / MAP_OBJS 비게이트 동시수거를 각각 독립 케이스로.
- **결정성:** 상자·드롭 생성 가지의 `Math.random`은 픽업 판정과 섞이지 않게 시드 격리 또는 생성 비활성(테스트용 난수만 격리, **생산 확률·수치 불변**).

## 3. 관측 필드 최소안 (browser-pickup.json 확장 · 제안)

현행 `{bag, normal, fallback, remaining, maskRecords}`에 아래 추가:
- `bagBefore`/`bagAfter` (10→12 **before 명시**, 현재 누락분 보강)
- `picked[]`: `{type, rarity, dist, onScreen, branch, viaHold}` — 어느 우선순위 가지로 수거됐는지
- `pickupItemResult`(bool)·`bagFullBlocked`(bool)·`groundRemainingByType`(remaining을 type별 집계)
- **입력 경계**: `interactPresses`(시도)·`interactConsumed`(isJust 성공)·`interactMissed`(누락)·`reinputCount`(재입력) — 짧은 R 입력 누락 정량화
- **우선순위 관측**: `portalConsumed`·`chestOpened`·`mapObjInteract`·`equipmentPickedRarity`·`tieBrokenByDistance`
- `tick/frame` 타임스탬프로 홀드 간격(`_pickHoldT>=9`) 검증

## 4. 검수 전제 / 미실행 구분

- **검수 전제:** 실제 `isJust/isHeld/입력큐/_usePlayerPortal/pickupItem/BAG_MAX/VW/VH` 추출이 선행. before(bag=10)은 json 미기록이라 root가 `bagBefore`를 실측에 포함해야 비교 가능.
- **미실행:** fixture·관측안은 **제안**이며 추출·실행·브라우저·게임·저장·커밋·파일작성 **안 함**(Read/Glob/Grep만 사용). 짧은 R 입력 누락은 **입력 경계 관찰**로 남기고 폴백 마스킹 수정의 결함으로 단정하지 않음(감사문서 지침 준수). 생산 코드/수치/확률/저장 무변경, 새 팀·trust 변경 없음.
- **추측 수정 금지 준수:** 누락 원인(엣지 소비 타이밍)은 **재현 대상 가설**로만 제시, 수정안 제시 안 함.

---

산출본문·검수전제·미실행 구분 완료. 실제 작성/실행/저장은 root 소유로 위임하고 종료합니다.