선행 문서(AGENTS.md, 감사 문서 §5 ANIMVFX 행, 직전 ANIMVFX 대장)를 읽고 game.html source로 GL 생성 경로·조건·부재 원인을 확인했습니다. 아래가 root 출력 폴더(`/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/r-input-20261001`)에 넣을 **산출 본문**입니다.

---

## R-input 20261001 — ANIMVFX: 정규 GL 활성 사망/부활 검수 선행 원인분리 + 읽기 게이트 probe

### 0. 범위·근거
- 배정(감사 §5 ANIMVFX 행): "GL 활성 정규 경로의 사망→부활 첫 draw 수명 인수 — 먼저 실제 GL 존재를 기록, GL 부재면 미검수로 남기고 contextLost를 임의 true로 대체 금지."
- 본 작업은 **source 확인 + 읽기 게이트 probe 본문 작성**까지. 실제 파일/HTML/Git/게임/브라우저/빌드 변경 없음. probe 실행도 안 함(총괄 순차 슬롯 대기).

### 1. 실제 GL 생성 경로·조건 (source 확정)
| 단계 | game.html | 조건·결과 |
|---|---|---|
| 렌더러 부팅 | `_bootRenderer()` 6024 | WebGPU→WebGL2→Canvas2D 순 폴백 |
| WebGPU 선택 | 6030–6031 | `_useWebGPU=(!IS_ELECTRON)&&(?webgpu==='1' \|\| (?webgpu===null && IS_MAC && navigator.gpu))`. **Mac 브라우저 기본 = WebGPU** |
| WebGPU 성공 | `_initWebGPU` 5417→5611 | `_useGPU=true`, **`_useGL`은 false·`GL`은 null 유지** |
| WebGL2 폴백 | 6038 → `_initWebGL` 5628 | `GL=C.getContext('webgl2',{…preserveDrawingBuffer:true})` 5629 → 성공 시 `_useGL=true` 5631, 실패 시 `GL` null·false 유지 5630 |
| 2D 폴백 | 6039/6041/6042 | `X=C.getContext('2d')` |
| GL 인스턴싱 파이프라인 | `_ensGLProg`/`_ensGLVao` 생성 4940·4943 | WebGL2 백엔드에서만 빌드 |
| GL 8dir draw 게이트 | 5003 `if(!_useGL\|\|!GL\|\|!_ensGLProg\|\|_ens8GLTotal<1)return 0` | `_useGL`/`GL`/프로그램 없으면 GL 경로 전체 skip |
| **§11 GL 플래시 루프** | `_prepEnemyInstanced` 말미 5192–5213(`_ensGLMode===1`만) | **WebGL2 백엔드 전용 경로** |
| 2D 폴백 플래시 | 51587(`!_ensGLQueued`) / 사망 소거 50624 | WebGPU·2D 경로에서 플래시는 여기로 처리 |
| 컨텍스트 로스트 | `webglcontextlost` 5768→`_useGL=false;GL=null` 5772 / `webglcontextrestored` 5785→`_initWebGL` 재구축 | **이 경로만 "진짜 context lost"** |
| 워밍업 | `_ensWarmDone` 21893/22008 | GL 아틀라스 준비 완료 플래그 |

### 2. GL 부재 원인 분류 (source 기준 4종)
| # | 원인 | source 상태 | GL 인스턴싱 플래시 | 비고 |
|---|---|---|---|---|
| 1 | **WebGPU 백엔드 선택(Mac 기본)** | `_useGPU=true`,`_useGL=false`,`GL=null` | 비활성(설계상) — ProxyX 2D 경로로 렌더·플래시 정상 | **실패 아님**. §11 GL 루프 미구동 |
| 2 | WebGL2 미지원/생성 실패 | `GL=null`,`_useGL=false`→2D | 비활성 | 실제 미지원 |
| 3 | WebGL2 컨텍스트 로스트 | 이벤트로 `GL=null`,`_useGL=false` | 비활성(복구 전) | **유일한 진짜 lost** |
| 4 | ProxyX 빌드 실패 6040 | `_useGPU/_useGL` 되돌림→2D | 비활성 | 드묾 |

**MAP020 VFX raw 재해석(정정)**: raw `useGL:false`+`contextLost:true`는 **원인 3(lost) 확정 불가**. 관측도구 `contextLost: safe(()=>GL.isContextLost(),true)`는 `GL=null`(원인 1·2)이면 throw→**가짜 true fallback**. **Mac 기본이 WebGPU(6031)이므로 유력 원인은 #1(WebGPU 선택)** — 즉 애초에 WebGL2를 안 쓴 것이지 "상실"이 아님. 직전 보고의 "컨텍스트 상실" 표현은 철회하고 "GL 검수 게이트 미충족(원인 미분리)"로 남긴다.

### 3. 읽기 게이트 probe 본문 (관측 전용, 미실행)
> classic-script main-world 스냅샷. 게임 상태·HTML·옵션 **불변**. `contextLost`는 **GL 존재 시에만 호출, 없으면 `null`**(가짜 true 금지). 무GL 10초 표본 재수집 아님(단발 스냅샷).

```js
(() => {
  'use strict';
  const safe=(f,d=null)=>{try{const v=f();return v===undefined?d:v}catch(e){return d}};
  const glObj = safe(()=>GL, null);
  const glPresent = glObj!==null && typeof glObj==='object';
  // contextLost — nullable: GL 객체가 있을 때만 실제 호출, 없으면 null(측정불가). 과거 raw의 fallback true와 구분.
  let contextLost=null, contextLostSource;
  if(glPresent && typeof glObj.isContextLost==='function'){
    contextLost = safe(()=>glObj.isContextLost(), null);
    contextLostSource = (contextLost===null)?'call-threw':'measured';
  } else { contextLostSource = glPresent?'no-isContextLost-method':'GL-null(not-applicable)'; }
  const useGL  = safe(()=>_useGL, null);
  const useGPU = safe(()=>_useGPU, null);
  const backend = useGPU===true?'webgpu':(useGL===true?'webgl2':'canvas2d-or-unknown');
  // WebGL2 인스턴싱 파이프라인 초기화 여부 (§11 GL 플래시 루프 전제)
  const ensGLProg = safe(()=>!!_ensGLProg, null);
  const ensGLVao  = safe(()=>!!_ensGLVao, null);
  const glInstInitialized = glPresent && ensGLProg===true && ensGLVao===true;
  // capability: 격리 캔버스로 WebGL2 "생성 가능성"만 확인(게임 C 미접촉; 일회용 컨텍스트, 게임 상태 불변)
  const glAvailable = safe(()=>!!document.createElement('canvas').getContext('webgl2'), null);
  const options = {
    fpsCap: safe(()=>OPT&&OPT.fpsCap, null), quality: safe(()=>OPT&&OPT.quality, null),
    resScale: safe(()=>OPT&&OPT.resScale, null),
    webgpuParam: safe(()=>new URLSearchParams(location.search).get('webgpu'), null),
    isMac: safe(()=>IS_MAC, null), isElectron: safe(()=>IS_ELECTRON, null),
    navigatorGpu: safe(()=>!!navigator.gpu, null),
    visibility: safe(()=>document.visibilityState, null), hidden: safe(()=>document.hidden, null),
    bootActive: safe(()=>_bootLoadActive, null), warmDone: safe(()=>_ensWarmDone, null),
    gameOn: safe(()=>G&&G.on, null), paused: safe(()=>G&&G.paused, null)
  };
  // 직전 draw 기준 GL 구동 지표(after-draw에서만 신뢰; ens8GLTotal은 프레임 큐 수=비누적)
  const glDrawCounters = { dbgEns8GL: safe(()=>_dbgEns8GL,null), ens8GLTotal: safe(()=>_ens8GLTotal,null), dbgEnsGL: safe(()=>_dbgEnsGL,null) };
  let glAbsenceCause;
  if(backend==='webgl2') glAbsenceCause = glInstInitialized ? (contextLost===true?'webgl2-context-lost':'none(webgl2-active)') : 'webgl2-pipeline-not-initialized';
  else if(backend==='webgpu') glAbsenceCause = 'webgpu-backend-selected (설계상 GL-instancing 비활성; 실패 아님)';
  else glAbsenceCause = (glAvailable===true) ? 'canvas2d-fallback-despite-webgl2-capable' : 'webgl2-unavailable';
  const flashPathReady = backend==='webgl2' && glInstInitialized && contextLost===false
    && options.visibility==='visible' && options.hidden===false && options.bootActive===false && options.warmDone===true;
  return {
    probe:'animvfx-gl-readgate', version:1, readonly:true, mutatedGameState:false, now:safe(()=>performance.now(),null),
    backend, useGL, useGPU, glPresent, glAvailable,
    contextLost, contextLostSource,                 // GL=null → contextLost:null (가짜 true 아님)
    glInstInitialized, ensGLProg, ensGLVao, glDrawCounters, options,
    flashPathReady, glAbsenceCause,
    deathReviveVerdictPremise: flashPathReady
      ? 'GL instancing flash path READY — 정규 옵션으로 사망/부활 첫 draw 수명 캡처 진행 가능'
      : ('GL instancing flash path NOT READY — 사망/부활 GL 수명은 미검수로 남김. cause='+glAbsenceCause),
    macGlForceHint: (options.isMac===true && backend==='webgpu')
      ? 'Mac 기본=WebGPU(_bootRenderer 6029-6031). WebGL2 인스턴싱 플래시 경로 검수는 정규 옵션 ?webgpu=0 으로 GL 백엔드 부팅 시 활성(총괄 순차 실행).'
      : null,
    note:'glAvailable은 격리 캔버스 생성 가능성(capability)일 뿐 게임 백엔드와 무관. contextLost=null=측정불가(GL 미존재). dbgEns8GL/ens8GLTotal은 직전 draw 기준이며 after-draw에서만 신뢰.'
  };
})();
```

### 4. 검수 전제 / 미실행 구분
- **검수 전제(선행 분리)**: 사망/부활 GL 수명 검수는 `flashPathReady===true`일 때만 유효 — 즉 **backend=webgl2 + 파이프라인 초기화 + contextLost=false + visible/부팅완료/워밍업완료**. Mac 기본 WebGPU(원인 1)에서는 §11 GL 루프가 구동되지 않으므로, 정규 GL 검수를 하려면 **총괄이 정규 옵션 `?webgpu=0`으로 WebGL2 부팅** 후 실행해야 한다(source 6029–6031 근거). WebGPU로 유지하면 GL-instancing 플래시는 설계상 비활성이며, 이는 결함이 아니라 백엔드 분기다.
- **미실행(이번 금지 범위)**: probe 실제 실행·게임/브라우저 구동·raw 수집·사망/부활 캡처·파일/HTML/Git/빌드 변경 **전부 안 함**. probe는 본문만 제출, 실행은 root 순차 슬롯.
- **가짜 true·무GL 반복 금지 준수**: probe는 `GL=null`일 때 `contextLost:null`로 보고(가짜 true 강제 없음)하고, 10초 무GL 표본을 재수집하지 않는 단발 게이트 스냅샷이다. 과거 MAP020 raw는 보존하며 재해석만 기록.

### 5. 제약·소유
- Read/Glob/Grep만 사용. 실제 파일/HTML/Git/게임/브라우저/인코딩/빌드/새 팀/trust 변경 없음. 중복 팀 없음.
- 출력 파일은 **root가** `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/r-input-20261001`에 작성(본 세션은 읽기 전용, 본문만 제공).
- 다음: root가 정규 옵션(필요 시 `?webgpu=0`)으로 probe 실행 → `flashPathReady` 확인 후, GL 활성이면 사망/부활 첫 draw 수명 캡처 진행, GL 부재면 원인(`glAbsenceCause`)과 함께 **미검수**로 기록.

**요약**: Mac 정규 경로의 GL 부재는 대부분 **WebGPU 기본 선택(원인 1)**이지 컨텍스트 상실이 아니며, 이를 `contextLost:null`·`backend`·`glAbsenceCause`로 분리 보고하는 읽기 게이트 probe 본문을 작성했습니다(실행은 총괄 대기). 가짜 true·무GL 표본 반복 없이 선행 원인분리를 완료합니다.