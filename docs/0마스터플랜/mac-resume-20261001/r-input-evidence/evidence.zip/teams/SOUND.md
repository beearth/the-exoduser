필요한 사실을 모두 확인했습니다. 경로 존재 여부와 주의점을 먼저 정리하고, 요청하신 로컬 HTML 청취 페이지 완성 본문을 산출합니다.

## 경로 존재 사실 (Read/Glob 근거)

| 대상 | 경로 | 상태 |
|---|---|---|
| 감사 문서 | `docs/0마스터플랜/mac-resume-20261001/item-fallback-evidence/다음작업-감사.md` | **존재**(읽음) — §5 SOUND 행 = "네메시아 한 곡 원본/후보 루프 접점 A/B 청취, 85ms 디코딩은 루프 청취 대체 아님" |
| 원본 WAV | `bgm/공통/네메시아의 강림2 (Remastered).wav` | **존재**(전체 디렉터리 Glob + `sound-result.json` originals에서 afinfo exit 0·27,840,172B 확인). ⚠️ 단일경로 Glob은 **미스**(디스크 파일명이 NFD 분해형, NFC 질의와 불일치) |
| MP3 256k | `…/build-item-sound/sound-receipt-01/네메시아의 강림2 (Remastered).mp3_256k.mp3` | **존재** |
| OGG q6 | `…/sound-receipt-01/네메시아의 강림2 (Remastered).ogg_q6.ogg` | **존재** |
| Opus 160k | `…/sound-receipt-01/네메시아의 강림2 (Remastered).opus_160k.opus` | **존재** |
| 출력 루트 | `…/dho/outputs/r-input-20261001/` | **존재**(`initial-status.bin`, `initial-team-status.json` — root 선작성) |

> **NFD 주의**: 원본 WAV 파일명은 디스크에서 NFD(자소 분해) Unicode. HTML의 `src`는 **디스크 실제 바이트와 동일한 문자열**이어야 하며, 재입력한 NFC 문자열은 브라우저 fetch에서 404날 수 있음. 아래 HTML은 `encodeURI`만 적용하고 파일명 자체는 **미검증 상태**로 명시 — root가 저장 시 실제 디렉터리 엔트리에서 복사해 대조해야 함.

## 산출: 로컬 HTML 청취 페이지 완성 본문

저장 제안 위치: `…/dho/outputs/r-input-20261001/S02-nemesia-loop-ab.html` (root 작성). 상단 `SOURCES` 경로만 실제 파일명과 대조 후 쓰면 됩니다.

```html
<!DOCTYPE html>
<!--
  S-02 네메시아의 강림2 — 루프 접점(끝→시작) A/B 청취 페이지 (후보, 미실행)
  목적: 이미 인수된 원본 WAV + MP3 256k + OGG q6 + Opus 160k를, 같은 레벨·같은 구간에서
        끝→시작 접점과 왜곡을 "사람이 직접" 비교 청취하기 위한 로컬 도구.
  제약:
   - 자동재생 없음. 반드시 '오디오 시작(사용자 제스처)' 버튼을 눌러야 소리가 난다.
   - 원본/후보 파일 무변경, 재인코딩 없음. 이 페이지는 읽기 전용 재생만 한다.
   - 기존 4096프레임 디코딩 수치의 재검이 아니며, 이 페이지로 그 수치를 바꾸지 않는다.
   - 파일명(특히 WAV의 NFD 정규화)·구간·청취 결과는 "미검수" 상태. 실제로 들었다고 단정하지 말 것.
  저장: root가 소유 파일로 저장하고, 브라우저 슬롯에서 연 뒤 검수한다.
  경로: file:// 로 직접 열 때 WAV와 후보가 서로 다른 폴더에 있으므로 절대경로를 사용한다.
        브라우저 로컬파일 보안으로 재생이 막히면 같은 상위 폴더로 모아 서빙(server.cjs)해야 할 수 있다(미검증).
-->
<html lang="ko">
<head>
<meta charset="utf-8">
<title>S-02 네메시아의 강림2 — 루프 접점 A/B 청취 (미검수)</title>
<style>
  :root{--bone:#dfd6c2;--gold:rgba(164,147,115,.5);--iron:#1c1510}
  body{background:#15110e;color:var(--bone);font-family:'Nanum Myeongjo',serif;margin:0;padding:20px;line-height:1.6}
  h1{font-size:19px;border-bottom:1px solid var(--gold);padding-bottom:8px;margin-top:0}
  .note{color:#b9a98a;font-size:12px;margin:10px 0 18px}
  .warn{color:#e0b86a}
  fieldset{border:1px solid var(--gold);border-radius:6px;margin:12px 0;padding:12px 14px;background:rgba(28,21,16,.5)}
  legend{color:#e6d9bf;padding:0 6px;font-size:13px}
  button{background:#241c16;color:#e6d9bf;border:1px solid var(--gold);padding:7px 13px;border-radius:4px;
    cursor:pointer;font-family:inherit;margin:3px 2px;font-size:13px}
  button:hover{background:#3a2c20} button:disabled{opacity:.4;cursor:not-allowed}
  button.active{background:#5a2420;border-color:#b05a4a;color:#ffdccf}
  label{font-size:13px;margin-right:10px}
  input[type=number]{width:72px;background:var(--iron);color:var(--bone);border:1px solid var(--gold);border-radius:3px;padding:3px 5px}
  input[type=range]{vertical-align:middle;width:180px}
  #status{font-size:13px;color:#c9b98f;margin-left:8px}
  #clock{font-variant-numeric:tabular-nums;color:#e6d9bf}
  code{color:#cdbf9e;font-size:12px}
  .row{margin:6px 0}
</style>
</head>
<body>
<h1>네메시아의 강림2 — 루프 접점(끝→시작) A/B 청취</h1>
<div class="note">
  절차: ① <b>오디오 시작</b> → ② <b>경로 존재 검사</b> → ③ 포맷 버튼으로 음원 선택(A/B는 재생 위치 유지) →
  ④ <b>레벨 고정</b>으로 네 음원 동일 볼륨 → ⑤ <b>끝→시작 미리듣기</b>로 루프 접점 청취, 또는 <b>구간 A–B 반복</b>.<br>
  <span class="warn">자동재생 없음 · 파일 무변경 · 아래 결과란은 비워 두고 실제 청취 후에만 채울 것(미검수).</span>
</div>

<!-- 상단: 음원 경로. root가 실제 디렉터리 엔트리에서 복사해 대조할 것(특히 WAV NFD). -->
<script>
const SOURCES = [
  { key:'wav',  label:'원본 WAV',   dur:145.0,
    path:'/Users/fordeargamers/Projects/exoduser-migration-20261001/bgm/공통/네메시아의 강림2 (Remastered).wav' },
  { key:'mp3',  label:'MP3 256k',   dur:145.032,
    path:'/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/build-item-sound/sound-receipt-01/네메시아의 강림2 (Remastered).mp3_256k.mp3' },
  { key:'ogg',  label:'OGG q6',     dur:145.0,
    path:'/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/build-item-sound/sound-receipt-01/네메시아의 강림2 (Remastered).ogg_q6.ogg' },
  { key:'opus', label:'Opus 160k',  dur:145.0065,
    path:'/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/map020-variants-20261001/build-item-sound/sound-receipt-01/네메시아의 강림2 (Remastered).opus_160k.opus' },
];
</script>

<fieldset>
  <legend>1 · 시작 / 존재</legend>
  <button id="startBtn">① 오디오 시작 (사용자 제스처 필요)</button>
  <button id="probeBtn" disabled>② 경로 존재 검사</button>
  <span id="status">AudioContext: 미시작</span>
</fieldset>

<fieldset>
  <legend>2 · 음원 선택 (A/B — 재생 위치 유지)</legend>
  <div id="srcBtns"></div>
  <div class="row">현재: <b id="curLabel">—</b> · 위치 <span id="clock">0.000 / 0.000</span> ·
    존재 <span id="curExist">—</span></div>
</fieldset>

<fieldset>
  <legend>3 · 레벨 고정 (네 음원 동일 볼륨)</legend>
  <label>volume <input type="range" id="vol" min="0" max="1" step="0.01" value="0.8"></label>
  <span id="volVal">0.80</span>
  <span class="note">※ 모든 음원에 같은 값 적용 → 볼륨 정합 A/B. 피크 보정 아님(귀 판정).</span>
</fieldset>

<fieldset>
  <legend>4 · 루프 접점(끝→시작) 미리듣기</legend>
  <div class="row">
    <label>끝 전 <input type="number" id="preSec" value="2.0" min="0.2" max="10" step="0.1"> 초</label>
    <label>시작 후 <input type="number" id="postSec" value="2.0" min="0.2" max="10" step="0.1"> 초</label>
    <button id="seamBtn" disabled>끝→시작 미리듣기</button>
    <button id="stopBtn" disabled>정지</button>
  </div>
  <div class="note">loop=true 상태로 (전체길이 − 끝전)으로 이동 → 끝을 지나 시작으로 wrap되는 이음부를 들음.
    wrap 후 '시작 후'초가 지나면 자동 정지. 끝시각은 포맷마다 수 ms 다름(패딩).</div>
</fieldset>

<fieldset>
  <legend>5 · 구간 A–B 반복 (선택)</legend>
  <div class="row">
    <label>A <input type="number" id="segA" value="0" min="0" step="0.1"> s</label>
    <label>B <input type="number" id="segB" value="10" min="0" step="0.1"> s</label>
    <button id="segBtn" disabled>구간 반복 켜기/끄기</button>
    <span id="segState">꺼짐</span>
  </div>
</fieldset>

<fieldset>
  <legend>6 · 청취 결과 기록 (실제로 들은 뒤에만 작성)</legend>
  <div class="note">파일명·포맷·구간·청취자·장치/볼륨을 적고, 객관 수치(=별도 sound-result.json)와 주관 청취 의견을 분리해 기록할 것.
    <b>이 페이지는 들었다는 증거가 아니다.</b></div>
  <textarea style="width:100%;height:90px;background:var(--iron);color:var(--bone);border:1px solid var(--gold);border-radius:4px"
    placeholder="예) 청취자: __ / 장치: __ / volume 0.80 고정 / 접점 pre2.0 post2.0 / wav↔opus 끝→시작: (관찰)…"></textarea>
</fieldset>

<audio id="player" preload="none" loop></audio>

<script>
const el=id=>document.getElementById(id);
let AC=null, cur=null, seamTimer=null, segOn=false;
const player=el('player');

// 음원 버튼 생성
SOURCES.forEach((s,i)=>{
  const b=document.createElement('button');
  b.textContent=s.label+' ('+s.dur+'s)'; b.dataset.key=s.key;
  b.onclick=()=>selectSource(i);
  el('srcBtns').appendChild(b);
});

el('startBtn').onclick=async()=>{
  try{
    AC=new (window.AudioContext||window.webkitAudioContext)(); await AC.resume();
    el('status').textContent='AudioContext: '+AC.state+' / sr='+AC.sampleRate;
    el('probeBtn').disabled=false; el('seamBtn').disabled=false;
    el('stopBtn').disabled=false; el('segBtn').disabled=false; el('startBtn').disabled=true;
  }catch(e){ el('status').textContent='시작 실패: '+e; }
};

async function exists(url){
  try{ let r=await fetch(url,{method:'HEAD'});
    if(r.status===405||r.status===501) r=await fetch(url,{headers:{Range:'bytes=0-0'}});
    return r.ok? r.status : r.status;
  }catch(e){ return 'ERR(로컬 보안/경로)'; }
}
el('probeBtn').onclick=async()=>{
  for(const s of SOURCES){ const st=await exists(encodeURI('file://'+s.path)); s._exist=st; }
  if(cur!=null) el('curExist').textContent=String(SOURCES[cur]._exist);
  el('status').textContent='존재검사 완료: '+SOURCES.map(s=>s.label+'='+s._exist).join(' · ');
};

function selectSource(i){
  const keep = player.currentTime||0;      // A/B 위치 유지
  const wasPlaying = !player.paused;
  cur=i; const s=SOURCES[i];
  [...el('srcBtns').children].forEach((b,bi)=>b.classList.toggle('active',bi===i));
  el('curLabel').textContent=s.label;
  el('curExist').textContent = (s._exist!=null?String(s._exist):'—');
  player.src=encodeURI('file://'+s.path);
  player.volume=parseFloat(el('vol').value);
  player.addEventListener('loadedmetadata',function once(){
    try{ player.currentTime=Math.min(keep, (player.duration||keep)); }catch(e){}
    if(wasPlaying) player.play().catch(()=>{});
    player.removeEventListener('loadedmetadata',once);
  });
  player.load();
}

el('vol').oninput=()=>{ el('volVal').textContent=parseFloat(el('vol').value).toFixed(2); player.volume=parseFloat(el('vol').value); };

player.addEventListener('timeupdate',()=>{
  el('clock').textContent=(player.currentTime||0).toFixed(3)+' / '+(player.duration||0).toFixed(3);
  if(segOn){ const a=parseFloat(el('segA').value),b=parseFloat(el('segB').value);
    if(player.currentTime>=b || player.currentTime<a) player.currentTime=a; }
});

el('seamBtn').onclick=()=>{
  if(cur==null){ alert('먼저 음원 선택'); return; }
  const pre=parseFloat(el('preSec').value), post=parseFloat(el('postSec').value);
  segOn=false; el('segState').textContent='꺼짐';
  const go=()=>{ const d=player.duration; if(!d||!isFinite(d)){ setTimeout(go,120); return; }
    player.loop=true; player.currentTime=Math.max(0,d-pre); player.play();
    clearTimeout(seamTimer);
    // wrap 감지: 끝 근처였다가 앞쪽으로 넘어온 뒤 post초 더 듣고 정지
    let wrapped=false;
    const watch=()=>{ if(player.currentTime < pre) wrapped=true;
      if(wrapped){ seamTimer=setTimeout(()=>player.pause(), post*1000); player.removeEventListener('timeupdate',watch);} };
    player.addEventListener('timeupdate',watch);
  };
  if(!player.src) selectSource(cur);
  go();
};
el('stopBtn').onclick=()=>{ clearTimeout(seamTimer); player.pause(); };
el('segBtn').onclick=()=>{ segOn=!segOn; el('segState').textContent=segOn?'켜짐 (A→B 반복)':'꺼짐';
  if(segOn && cur!=null){ player.currentTime=parseFloat(el('segA').value); player.play().catch(()=>{}); } };
</script>
</body>
</html>
```

## 검수 전제 / 미실행 구분

**이미 확인된 것(Read 근거)**
- 감사 문서 §5 SOUND 행·§4가 "네메시아 한 곡 루프 접점 A/B 청취 선행, 85ms 디코딩은 루프 청취 대체 아님"을 과업으로 지정 — 산출 방향 일치.
- 원본 WAV + 후보 3포맷 파일 모두 **존재**(디렉터리 Glob + `sound-result.json`). 후보는 앞서 decode 9/9 PASS·컨테이너 6/6 PASS(기계, 재검 안 함).

**미실행/미검수 (명시)**
1. **실제 청취 안 함** — 이 페이지는 완성 본문일 뿐, 브라우저로 열거나 소리를 들은 바 없음. "청취했다"고 단정하지 않음.
2. **파일명 미검증** — WAV 파일명이 디스크에서 NFD이며, 단일경로 Glob은 미스였음. HTML의 `src` 문자열은 root가 **실제 엔트리에서 복사해 대조**해야 함.
3. **구간/레벨 미검수** — 기본값(끝전 2.0s·시작후 2.0s·volume 0.80)은 예시. 실제 접점 구간·정합 볼륨은 청취로 확정.
4. **로컬 보안 미검증** — 서로 다른 폴더의 `file://` 재생이 브라우저 보안으로 막힐 수 있음(미확인). 막히면 한 폴더로 모아 `server.cjs` 서빙 필요 — 이 역시 미실행.
5. **파일/HTML/Git/게임/브라우저/인코딩/빌드 변경 0** — Read/Glob만 사용, 프로젝트 읽기 전용 유지. 저장·브라우저 슬롯 검수는 root 소유.

**요약**: 네메시아의 강림2 원본/MP3/OGG/Opus 4음원을 동일 레벨·구간 유지로 끝→시작 루프 접점과 A/B 비교 청취하는 자동재생 없는 로컬 HTML 완성 본문을 산출했습니다. 실제 청취·파일명·구간은 미검수이며, root가 소유 파일로 저장 후 브라우저에서 검수합니다. 종료합니다.