모든 소스 근거 확보했습니다. 정규 CH1 스폰에서 etype3는 `projCd=240`·`ETYPE_RANGE[3]=200`으로 등장하며, 자연 발사는 `_spawnBossProjectile` 에지가 아니라 **idle 내부 `projT→_projChargeT(60f)→_fireChargedProj→spawnProj(_commit)`** 경로입니다. 이 자연 경로를 강제 windup 없이 **실게임 순차 실행용**으로 관측하는 산출물을 제출합니다.

---

# R-input 20261001 — 정규 필드 etype3 자연 idle→차징→첫 탄막 관측 (ENEMY 독립 후속)

## A. Read 근거 (game.html, HEAD dd3bdc18 기준 조사)

| 항목 | 값·위치 | 의미 |
|---|---|---|
| CH1-1 스폰풀 | `HELL_SPAWN[0]`에 `[3,4]` 포함(`29460`) | etype3(요마)는 1장 정규 스폰 대상(가중치 4) |
| 돌진 제외셋 | `_CH1_OPENING_EXCLUDED_ET={2,22,30,43}`(`29481`) — **3 미포함** | etype3 리매핑 안 됨 |
| 레인지드 분류 | `_RANGED_ET`(`29480`) — **3 미포함** | `rollEtype(0)` 근접롤 분기로 스폰 |
| 접촉공격셋 | `_meleeET={0,2,4,5,6,10,12,18,19}`(`38844`) — **3 미포함** | etype3은 접촉타도 아님(스웜) |
| 투사체 쿨 | `_projCd`: etype3은 `_noProjEtypes` 비포함 → **240**(`29644-46`) | 자연 탄막 발사 대상 |
| 초기 projT | 비보스 `180+rand*120` ∈ [180,300](`29657`) | 첫 발사까지 카운트다운 |
| 사거리 | `ETYPE_RANGE[3]=200`(`29361`) | d<200일 때만 차징 개시 |
| 차징 트리거 | idle 내부 `projCd<9000` 분기(`38852-38862`): `projT-=sp`→`projT<=0&&d<_eRange`→`_projChargeT=60` | **windup 아님** |
| 발사 | `_tickProjCharge`(`37223`,`18890`)가 `_projChargeT` 감소→0에서 `_fireChargedProj`(`18860`)→`spawnProj(_commit:true)` | 첫 탄막 실발사 |
| 에지 경로 | windup→attack `_spawnBossProjectile`(`39567`) | 강제 진입시에만, etype3 0발(별건) |

→ 자연 타임라인(d<200 지속·random=0.5): projT0=240 → tick 240에 차징 개시 → +60f → **tick 300경 첫 탄막 1발**, 그동안 `e.s==='idle'` 유지. (이전 절대경로 실행증거 `natural:{"states":["idle"],"charged":1,"edge":0}`와 정합.)

## B. 산출 본문 — 실게임 순차 실행용 관측 프로브 (root가 출력 경로에 저장)

> 저장 제안: `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/r-input-20261001/enemy_et3_natural_firstfire_probe.js` (**root 작성**). 정규 CH1-1 필드 실행 중 콘솔/주입으로 `install()` 후 자연 교전, 첫 발사 후 `report()`. 게임 상태·수치 **불변**(함수 pass-through 래핑만), 강제 windup **미사용**.

```js
/* ENEMY R-input 20261001 — 정규 필드 etype3 자연 첫 탄막 관측 프로브 (read-only 관측)
 * 대상: 실행 중 game.html(정규 CH1-1 필드). 강제 windup/상태주입 금지. 밸런스·수치 불변.
 * 근거 라인(game.html HEAD dd3bdc18): 37223 _tickProjCharge / 38852-62 차징개시(idle내부)
 *   / 18860 _fireChargedProj→spawnProj(_commit) / 39567 _spawnBossProjectile(에지,별건)
 *   / 29361 ETYPE_RANGE[3]=200 / 29644-46 projCd=240 / 29657 projT0∈[180,300]
 * 기존 enemy.test.js 6검사(강제windup edge/단일 idle301/eCircle)와 중복 아님:
 *   본 프로브는 '정규 스폰 실인스턴스'의 차징 하위단계(projT→_projChargeT→fire)를
 *   프레임 단위로 귀속·관측하고 사거리 체류를 판정에 반영한다. */
(function (root) {
  if (root.__ET3_PROBE) { try { root.__ET3_PROBE.stop(); } catch (e) {} }
  var P = {
    KEY: 'et3-natural-firstfire',
    startedFrame: null, target: null, targetTag: 0,
    spawn: null,            // 최초 포착 스냅샷
    projTStart: null,       // projT가 0을 하향 교차해 차징 개시된 프레임
    chargeStartFrame: null, chargeStartD: null, chargeStartProjChargeT: null,
    firstFire: null,        // 첫 발사 이벤트
    edgeFire: null,         // 에지 경로(_spawnBossProjectile) 발사 있으면 기록
    inRangeTicks: 0,        // d<ETYPE_RANGE[3] 체류 tick
    aliveTicks: 0, frozenTicks: 0, stunnedTicks: 0,
    sampleStates: {},       // 관측된 e.s 분포
    dHistory: [],           // (tick,d,s,projT,projChargeT) 희소 기록
    raf: 0, wrapped: {}, done: false, err: null
  };

  function g(n) { return (typeof root[n] === 'function') ? root[n] : null; }
  function curFrame() { return (root.G && typeof root.G.frame === 'number') ? root.G.frame : -1; }
  function distToP(e) {
    var pl = root.P; if (!pl) return Infinity;
    return Math.hypot(pl.x - e.x, pl.y - e.y);
  }
  function range3() {
    try { return (root.ETYPE_RANGE && root.ETYPE_RANGE[3]) || 200; } catch (e) { return 200; }
  }
  // 정규 스폰된 자연 etype3 1마리 고정(보스/레어/디코이/강제상태 제외)
  function findTargetEt3() {
    var ens = root.ens; if (!Array.isArray(ens)) return null;
    for (var i = 0; i < ens.length; i++) {
      var e = ens[i];
      if (e && e.alive && e.etype === 3 && !e.ib && !e._isRare && !e._isDecoy) return e;
    }
    return null;
  }

  function wrap(name, make) {
    var orig = g(name); if (!orig) { P.wrapped[name] = false; return; }
    P.wrapped[name] = orig;
    root[name] = make(orig);
  }

  P.install = function () {
    P.startedFrame = curFrame();
    var R = range3();

    // 차징 발사(정상 경로): _fireChargedProj(e) — e 전달받음 → 귀속 가능
    wrap('_fireChargedProj', function (orig) {
      return function (e) {
        if (!P.done && e && e === P.target && !P.firstFire) {
          P.firstFire = {
            path: 'charged(spawnProj _commit)',
            frame: curFrame(), tickSinceInstall: curFrame() - P.startedFrame,
            tickSinceChargeStart: P.chargeStartFrame != null ? curFrame() - P.chargeStartFrame : null,
            s: e.s, projChargeT: e._projChargeT, projCd: e.projCd,
            bean: e._projChargeBean || null, el: e.el, d: distToP(e)
          };
        }
        return orig.apply(this, arguments);   // 원함수 그대로 호출(상태 불변)
      };
    });
    // 에지 발사(강제/eCircle→windup→attack 경로): _spawnBossProjectile(e,shot)
    wrap('_spawnBossProjectile', function (orig) {
      return function (e, shot) {
        if (!P.done && e && e === P.target && !P.edgeFire) {
          P.edgeFire = { path: 'edge(_spawnBossProjectile)', frame: curFrame(),
            s: e.s, d: distToP(e) };
        }
        return orig.apply(this, arguments);
      };
    });

    var R2 = R * R, lastProjT = null;
    function sample() {
      if (P.done) return;
      try {
        var e = P.target && P.target.alive ? P.target : findTargetEt3();
        if (e && e !== P.target) {              // 최초 포착 1회 고정
          P.target = e;
          P.spawn = { frame: curFrame(), s: e.s, projCd: e.projCd, projT0: e.projT,
            st2: e.st2, el: e.el, d: distToP(e), x: e.x, y: e.y };
          lastProjT = e.projT;
        }
        if (P.target) {
          var tgt = P.target, d = distToP(tgt), f = curFrame();
          P.aliveTicks += tgt.alive ? 1 : 0;
          if (tgt.alive && d < R) P.inRangeTicks++;
          if ((tgt._frozen || 0) > 0) P.frozenTicks++;
          if ((tgt.stunned || 0) > 0) P.stunnedTicks++;
          P.sampleStates[tgt.s] = (P.sampleStates[tgt.s] || 0) + 1;
          // projT 0 하향 교차 = 차징 개시 프레임 귀속
          if (lastProjT != null && lastProjT > 0 && tgt.projT <= 0 &&
              P.chargeStartFrame == null && (tgt._projChargeT || 0) > 0) {
            P.chargeStartFrame = f; P.chargeStartD = d;
            P.chargeStartProjChargeT = tgt._projChargeT;
          }
          lastProjT = tgt.projT;
          if (P.dHistory.length < 2000 && (f % 15 === 0))
            P.dHistory.push([f, Math.round(d), tgt.s, Math.round(tgt.projT || 0),
              Math.round(tgt._projChargeT || 0)]);
        }
      } catch (err) { P.err = String(err && err.stack || err); }
      P.raf = root.requestAnimationFrame(sample);
    }
    P.raf = root.requestAnimationFrame(sample);
    return { installedAtFrame: P.startedFrame, range: R,
      wrapped: Object.keys(P.wrapped).filter(function (k) { return P.wrapped[k]; }) };
  };

  P.stop = function () {
    P.done = true;
    if (P.raf) { try { root.cancelAnimationFrame(P.raf); } catch (e) {} }
    for (var k in P.wrapped) if (P.wrapped[k]) root[k] = P.wrapped[k];  // 원복
    return P.report();
  };

  // ── 실패/판정 로직 ──
  P.report = function () {
    var R = range3();
    var budget = 300 + 60 + 90;   // projT0 최대300 + 차징60 + 여유90 = 450 tick
    var elapsed = curFrame() - P.startedFrame;
    var v = { verdict: 'INCONCLUSIVE', reasons: [] };

    if (P.err) v.reasons.push('probe_error:' + P.err);
    if (!P.target) { v.verdict = 'FAIL_DETECT'; v.reasons.push('정규 CH1 필드에서 자연 etype3 미포착(스폰/필드 조건 확인 필요, 공격전무로 단정 금지)'); }
    else if (P.firstFire) {
      var okState = P.firstFire.s === 'idle';
      var okPath  = P.firstFire.path.indexOf('charged') === 0;
      var okTick  = P.firstFire.tickSinceChargeStart == null ||
                    (P.firstFire.tickSinceChargeStart >= 55 && P.firstFire.tickSinceChargeStart <= 70);
      if (okState && okPath) {
        v.verdict = 'PASS';
        v.reasons.push('자연 idle→차징→spawnProj(_commit) 첫 탄막 1발 확인');
        if (!okTick) v.reasons.push('주의: 차징→발사 간격이 60f(±) 밖 — ' + P.firstFire.tickSinceChargeStart);
      } else {
        v.verdict = 'FAIL_PATH';
        if (!okState) v.reasons.push('첫 발사시 e.s!==idle (' + P.firstFire.s + ') — 자연경로 아님');
        if (!okPath)  v.reasons.push('첫 발사가 charged 경로 아님(' + P.firstFire.path + ')');
      }
    } else if (P.edgeFire && !P.firstFire) {
      v.verdict = 'FAIL_PATH';
      v.reasons.push('charged 발사 없이 edge(_spawnBossProjectile)만 — 강제/eCircle 경로. 공격전무 재주장 아님');
    } else {
      // 발사 없음: 사거리 체류 있었는가로 결함/정상 구분
      if (P.inRangeTicks >= 120 && P.aliveTicks >= budget && P.frozenTicks === 0 && P.stunnedTicks === 0) {
        v.verdict = 'FAIL_NO_FIRE';
        v.reasons.push('d<' + R + ' 체류 ' + P.inRangeTicks + 'tick·생존 ' + P.aliveTicks +
          'tick인데 차징 발사 0 — 자연 발사 누락(실결함 후보)');
      } else {
        v.verdict = 'INCONCLUSIVE';
        v.reasons.push('사거리 체류 ' + P.inRangeTicks + 'tick/생존 ' + P.aliveTicks +
          'tick/빙결 ' + P.frozenTicks + '/스턴 ' + P.stunnedTicks +
          ' — 미발사가 결함인지 판정 불가(더 오래 사거리 유지 필요)');
      }
    }

    return {
      key: P.KEY, observedAt: new Date().toISOString(),
      gameFrameNow: curFrame(), elapsedTicks: elapsed, range: R, budgetTicks: budget,
      spawnSnapshot: P.spawn, chargeStart: P.chargeStartFrame == null ? null :
        { frame: P.chargeStartFrame, d: Math.round(P.chargeStartD),
          projChargeT: P.chargeStartProjChargeT },
      firstFire: P.firstFire, edgeFire: P.edgeFire,
      residency: { inRangeTicks: P.inRangeTicks, aliveTicks: P.aliveTicks,
        frozenTicks: P.frozenTicks, stunnedTicks: P.stunnedTicks },
      stateHistogram: P.sampleStates, dHistory: P.dHistory,
      wrapped: Object.keys(P.wrapped).filter(function (k) { return P.wrapped[k]; }),
      probeError: P.err, ...v
    };
  };

  root.__ET3_PROBE = P;
  return P;
})(window);
// 사용:  window.__ET3_PROBE.install();  …정규 CH1-1 교전…  JSON.stringify(window.__ET3_PROBE.stop())
```

## C. 실패 판정 요약

| verdict | 조건 | 해석 |
|---|---|---|
| `PASS` | 첫 발사 = charged(spawnProj `_commit`) **또한** 발사시 `e.s==='idle'` | 자연 idle→차징 첫 탄막 정상. (차징 60f±는 주의로만) |
| `FAIL_DETECT` | 정규 필드에서 자연 etype3 미포착 | 스폰/필드 조건 문제 — **공격 전무로 단정 금지** |
| `FAIL_PATH` | 첫 발사가 edge(`_spawnBossProjectile`)뿐이거나 발사시 `s!=='idle'` | 자연 charged 경로 아님(강제/eCircle) — 별건 |
| `FAIL_NO_FIRE` | `d<200` 체류 ≥120tick·생존 ≥450tick·빙결/스턴 0인데 발사 0 | **자연 발사 누락 실결함 후보** |
| `INCONCLUSIVE` | 사거리 체류·생존 부족, 또는 빙결/스턴 간섭 | 더 긴 사거리 유지 필요 — 미판정 |

핵심: **강제 windup edge 0발은 재주장하지 않으며**, 사거리 체류(`inRangeTicks`)를 분모로 삼아 "미발사"가 설계상 거리 홀드인지 실누락인지 분리한다.

## D. 검수 전제 (root가 실행 시 확보) vs 미실행 (내가 안 한 것)

**검수 전제 — 실게임 순차 실행 시 root가 보장:**
- **정규 CH1-1 필드**에서 실행(`?stage=1` 정식 진입 등). `?stage=0` dev QA plate는 ENEMY master §검수환경메모대로 일반 원거리 발사 재현 부적합 → 사용 금지.
- 자연 교전으로 etype3가 플레이어 `d<200`에 **최소 ~450tick** 체류하도록 유지(사거리 밖이면 홀드는 정상).
- QA의 격리 게임 슬롯 1개 규칙(AGENTS §우선순위) 준수 — 다른 게임/빌드 동시 실행 금지.
- 프로브는 `_fireChargedProj`/`_spawnBossProjectile`를 **pass-through 래핑**만 하며 상태·수치·발사량을 바꾸지 않음. `stop()`에서 원복.

**미실행 — 이번 지원이 하지 않음(읽기전용):**
- 나는 **Read/Glob/Grep만** 수행. 위 본문은 **후보 산출물**이며 파일로 저장(출력 경로는 **root 작성**)·게임/브라우저 실행·Node 실행을 하지 않았다. 따라서 PASS/FAIL 실결과·tick 실측치는 **미수집**.
- game.html·docs·HTML·Git·인코딩·빌드 **무변경**, 새 팀·trust/security **무변경**, 기존 enemy.test.js 6검사 **미재실행**(중복 금지 준수).
- 밸런스 수치(projCd 240/projT/사거리 200/차징 60f) **불변** — 관측만.

## E. 잔여

- `FAIL_NO_FIRE` 또는 `INCONCLUSIVE`가 실제로 나오면, 그때 비로소 "자연 발사 누락" 여부가 데이터로 확정됨. 수정 여부·공용 update 변경은 QA 소유(ENEMY는 재현·관측·후보까지).
- etype3가 `d<e.r+30`(~44px)까지 접근하면 eCircle→windup→attack 에지 경로(0발, enemy.test.js T3)로도 들어갈 수 있어, `edgeFire` 필드로 그 교차를 함께 기록하도록 설계했다 — 중거리(44~200px) charged와 근접(<44px) edge의 공존을 구분 관측.

산출본문·실패판정·검수전제/미실행 구분 완료. 종료합니다.