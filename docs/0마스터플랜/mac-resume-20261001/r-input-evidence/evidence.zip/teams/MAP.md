선행 문서(AGENTS·_MAP_SSOT_INDEX·다음작업-감사·MAP020 대장 이력)와 `game.html` 심볼(`G`,`P`,`T`,`K[]`+KeyboardEvent 입력, `G.cam`,`G.map`,`VW/VH`)을 실제 Read/Grep로 확인했습니다. **읽기 전용** — 파일/HTML/Git/게임/브라우저/빌드 변경, 새 팀/trust 변경 없음. 아래 fixture는 산출 본문이며 **이번 세션은 파일로 쓰지 않았습니다**(제약: Read/Glob/Grep만).

## 1) 좌표 불일치 판정 (인수)
SSOT 계약: `T=40`, world 8000², master 8192² core1024px→**world 1000px** ⇒ bake→world = ×1000/1024 (`_MAP_SSOT_INDEX` §PRODUCTION 적용계약). `before-map-collision.json`의 `coordinateCheck`와 대조:

| 좌표(해석) | 환산 world | 타일(tx,ty) | g.map | 벽? |
|---|---|---|---|---|
| 문서 M5 `7000,6900` (world로) | 7000,6900 | 175,172 | `[172][175]=1` | **벽** (documentIsWall:true, tile=1) |
| 문서 `7000,6900` (bake px로) | **6835.94,6738.28** | 170,168 | 1 | **벽** (bakeConversionIsWall:true) |
| 실제 접근점 `6660,6140` | 6660,6140 | 166,153 | `[153][166]=0` | 비벽 (approachIsWall:false) |

**판정**: 문서/SSOT의 M5 주머니 좌표 `7000,6900`은 **월드·베이크 어느 해석으로도 벽 타일**이라 오기다. 보행 검수의 접근 기준은 검증된 **`6660,6140`(비벽)**로 인수한다. (SSOT 이력 "M5문서7000,6900은 현재벽이며 주머니 보행 승인보류" 및 `MAP020-뿌리변주-검수` 미검수 상태와 일치.)

## 2) M5 접근→진입→이탈 fixture (산출 본문, 실입력·읽기전용)
경로·좌표·중단조건·좌표관측을 포함한 단일 게임용 fixture. **충돌/맵 미변경**, 정지캡처·앵커검사 없음. 권위적 "막힘" 신호 = **키 유지 중 P 좌표 flatline**(게임 자체 충돌 결과), 타일 분류기는 시각 경계와의 대조용 참고.

```js
/* MAP-020 M5 주머니 보행 fixture — 접근→진입→이탈, 읽기전용 관측.
   전제: stage0(CH1-1), 기본 B, 게임 포커스·일시정지 아님. 약 9.7초 실시간 소요.
   충돌/맵(G.map·collision) 쓰기 0. 정지캡처/경계앵커 덤프 없음. */
(function(){'use strict';
  if(typeof G==='undefined'||typeof P==='undefined'||typeof T==='undefined'){console.error('M5FIX: G/P/T 심볼 없음 — 실게임 전제 미충족');return;}
  if(G.stage!==0)console.warn('M5FIX: stage0 아님 →',G.stage);

  // 읽기전용 타일 분류기(documentTile 규약: 1=벽) + 게임 isW 있으면 참고 병기
  const tile=(wx,wy)=>[Math.floor(wx/T),Math.floor(wy/T)];
  const wallTile=(wx,wy)=>{const[tx,ty]=tile(wx,wy),r=G.map&&G.map[ty];return !(r&&r[tx]===0);};
  const gIsW=(typeof isW==='function')?((wx,wy)=>{try{return !!isW(wx,wy);}catch(e){return null;}}):(()=>null);

  // 좌표 계약 감사(읽기): 문서7000,6900 vs 베이크환산 vs 접근점
  const b2w=b=>b*1000/1024;
  const coordAudit={
    document:{world:[7000,6900],tile:tile(7000,6900),wallTile:wallTile(7000,6900),gameIsW:gIsW(7000,6900)},
    bakeConv:{world:[b2w(7000),b2w(6900)],tile:tile(b2w(7000),b2w(6900)),wallTile:wallTile(b2w(7000),b2w(6900)),gameIsW:gIsW(b2w(7000),b2w(6900))},
    approach:{world:[6660,6140],tile:tile(6660,6140),wallTile:wallTile(6660,6140),gameIsW:gIsW(6660,6140)}
  };

  // 원본맵 보존 시그니처(읽기): 포켓 주변 타일창 체크섬 전후 비교
  const win={x0:150,y0:150,x1:178,y1:178};
  const sig=()=>{let h=2166136261>>>0;for(let ty=win.y0;ty<=win.y1;ty++){const r=G.map[ty]||[];for(let tx=win.x0;tx<=win.x1;tx++){h=Math.imul(h^((r[tx]|0)+1),16777619)>>>0;}}return h>>>0;};
  const mapRef=G.map, sigBefore=sig();

  // 입력(게임 K[]+KeyboardEvent 경로) — 게임플레이/바인드 변경 없음
  const Kg=(typeof K!=='undefined')?K:null;
  const hold=(c,on)=>{if(Kg)Kg[c]=on;document.dispatchEvent(new KeyboardEvent(on?'keydown':'keyup',{code:c,key:c,bubbles:true}));};
  const relAll=()=>['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].forEach(c=>hold(c,false));

  // 샘플러: 50ms, 중단조건=키유지 중 Δ<0.5px가 5표본(≈250ms) 연속=막힘
  const EPS=0.5,FLAT=5;
  const leg=(name,code,maxMs,dir)=>new Promise(res=>{
    const pr={N:[0,-20],S:[0,20],E:[20,0],W:[-20,0]}[dir]||[0,0];
    const t0=performance.now(),S=[];let flat=0,last=null,blockedAt=null;
    hold(code,true);
    const id=setInterval(()=>{
      const t=performance.now()-t0;
      S.push({t:Math.round(t),x:P.x,y:P.y,camx:G.cam.x,camy:G.cam.y,held:Kg?!!Kg[code]:null,
        hp:P.hp,pState:(P._anim||P.state||null),paused:!!G.paused,
        wallAhead:wallTile(P.x+pr[0],P.y+pr[1]),gameWallAhead:gIsW(P.x+pr[0],P.y+pr[1]),mapSame:(G.map===mapRef)});
      if(last&&Math.hypot(P.x-last.x,P.y-last.y)<EPS){if(++flat>=FLAT&&!blockedAt)blockedAt={x:P.x,y:P.y,t:Math.round(t)};}else flat=0;
      last={x:P.x,y:P.y};
      if(t>=maxMs){clearInterval(id);hold(code,false);res({name,code,dir,maxMs,blockedAt,endPos:{x:P.x,y:P.y},samples:S});}
    },50);
  });

  (async()=>{
    relAll();
    const setupFrom={x:P.x,y:P.y};
    // SETUP(검수 PASS 아님): 검증된 비벽 접근점으로 1회 배치. 충돌/맵 미변경.
    if(!coordAudit.approach.wallTile){P.x=6660;P.y=6140;}
    const legs=[];
    legs.push(await leg('A_enter_south','KeyS',2500,'S'));  // 진입: 포켓 남진 → 막힌 남측 정지 기대 ~y6304
    legs.push(await leg('B_inside_north','KeyW',1500,'N')); // 내부 북상(입구) ~y6137
    legs.push(await leg('C_entry_east','KeyD',800,'E'));    // 입구 동측 개구 ~x6746
    legs.push(await leg('D_block_south2','KeyS',2500,'S')); // 동측 남진 → 곡선 남측벽 정지 기대 ~y6223
    legs.push(await leg('E_exit_north','KeyW',1200,'N'));   // 이탈(북)
    legs.push(await leg('E2_exit_west','KeyA',1200,'W'));   // 이탈(서) 개활지 복귀
    relAll();
    const out={fixture:'MAP020-M5-walk',stage:G.stage,T,viewWorld:[typeof VW!=='undefined'?VW:null,typeof VH!=='undefined'?VH:null],
      coordAudit,setupFrom,mapUnchanged:(G.map===mapRef&&sig()===sigBefore),mapSig:{before:sigBefore,after:sig()},legs};
    console.log('M5FIX_RESULT_JSON\n'+JSON.stringify(out));
    window._m5fix=out; // 총괄이 콘솔 JSON을 출력폴더에 저장(파일 쓰기는 fixture가 하지 않음)
  })();
})();
```

**경로/좌표/중단조건 요약**: 접근점 `6660,6140`(비벽) 배치 후 — A) S 2.5s 진입→남측벽(~y6304) · B) W 1.5s 입구복귀(~y6137) · C) D 0.8s 동측개구(~x6746) · D) S 2.5s 동측 남진→곡선벽(~y6223) · E/E2) W·A로 이탈. 중단조건 = 키유지 중 Δ<0.5px가 5표본 연속(막힘) 또는 레그 타임아웃. 관측 = 50ms마다 `x,y,cam,held,hp,pState,paused,wallAhead(타일),gameWallAhead,mapSame` + 전후 맵 시그니처.

## 3) 검수 전제 / 미실행 구분
- **전제(실행 전 확인 필요, 미검증)**: ① 이동 키코드 `KeyW/A/S/D`가 현재 BINDS와 일치하는지(게임이 커스텀 바인드면 교체) ② `P._anim/P.state`·`VW/VH` 심볼 존재 ③ 1회 `P.x/P.y` 배치를 root 방법론상 SETUP으로 허용(기존 walk 증거와 동일 방식) ④ stage0·기본 B·포커스·비일시정지 상태.
- **미실행(이번 세션)**: fixture **실행 안 함**, 게임·브라우저 미기동, 파일 미작성. 산출물은 본 코드이며 `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/r-input-20261001/`에 **root가 저장**해야 함(이 세션은 read-only라 쓰지 않음).
- **중복 방지**: 정지캡처·경계앵커 검사 재탕 없음(§다음작업-감사 MAP 행 준수), 충돌/공용 함수 변경 없음, 새 팀 없음.

## 4) 잔여
- M5 **전체 보행 경로(접근→진입→이탈)**는 fixture 실행·관측 전까지 **미검수**. MAP-020 전체 **RETOUCH 유지**.
- fixture는 좌표 불일치(7000,6900=벽)를 런타임으로 재확인하는 `coordAudit` 포함 — 실행 시 문서 좌표 오기를 로그로 확정 가능(SSOT M5 좌표 정정은 생산수정 소유자 몫, 이번엔 판정만).
- 완료로 **종료**합니다.