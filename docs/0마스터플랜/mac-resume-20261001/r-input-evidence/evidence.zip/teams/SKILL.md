선행 산출에 필요한 입력 라우트 사실을 모두 확인했습니다. 아래가 독립 선행 산출(관측 JS 본문 + 입력 순서)과 전제/미실행 구분입니다.

---

# R-input 20261001 — SKILL: iceStorm 취소→다음 LMB 입력경계 선행 관측 산출

HEAD `dd3bdc18`. 선행 문서(`다음작업-감사.md` §5 SKILL 행) 확인: "정상 조준→RMB 취소→다음 LMB를 실제 입력해 MP/쿨·지연 발동·잔류 소비 기록, 브라우저 입력 라우트의 확정/취소는 미검수". 본 산출은 **읽기 관측 하니스 + 입력 순서 명세**이며, 실제 게임 입력은 R조사와 공용 root 순차 슬롯에서 root가 실행합니다(나는 미실행).

## 읽은 입력 라우트 사실 (Grep/Read 근거, game.html)
- `const MBjust={}`(`12298`) = just-pressed 엣지. `MB[]`=홀드. mousedown에서 `MB[e.button]=true;MBjust[e.button]=true`(`12798`), button 0=LMB·2=RMB.
- **프레임 flush** `for(const b in MBjust)MBjust[b]=false`(`12765`) — 매 프레임 입력 처리 끝에 전 엣지 소거 → DOM에서 눌린 엣지는 **정확히 한 프레임만** 유효.
- iceStorm 확정 블록(`34872–34902`)은 `MBjust[0]` 직접 읽음, 취소는 `MBjust[2]||K['Escape']` 우선(`34878`). 조준 게이트는 `if(P._isAiming)` 가드.
- **LMB=무기 공격 바인드**: `weapon:'mouse0'`(`6061`), 라우팅 `isJust('weapon')→_chkJust(BINDS.weapon)`(`13678,13680`)가 `MBjust[0]`을 소비. → **취소 후 다음 LMB는 iceStorm이 아니라 일반 공격 입력**이다. 핵심 경계: 그 LMB가 (a) iceStorm으로 지연 발동되는가(버그 신호) vs (b) 공격으로만 소비되는가(정상)를 분리 관측해야 함.
- iceStorm은 쿨다운 스킬이 아님 → "쿨"은 스택 리차지 `P._isRech`(`34862–34870`), 자원은 `P.mp`·`P._isStk`. 설치 성공의 유일한 관측 가능 효과 = `G._fireZones`에 `type:'iceStorm'` push + `mp-=40` + `_isStk--`.

## 산출 1 — 관측 하니스 JS 본문 (읽기 전용, dispose 포함)
> DevTools 콘솔(페이지 전역 스코프)에 붙여 실행. 게임 함수·리스너를 **패치하지 않고** 캡처단계 수동 리스너 + rAF 샘플러로만 관측(passive, preventDefault/stopPropagation 없음). `P/G/MBjust/K/mouse`는 전역 스크립트 심볼로 직접 참조.

```javascript
window.__iceCancelProbe = (() => {
  // iceStorm 취소→다음 LMB 입력경계 읽기 관측기. 생산코드 무변경·입력 무간섭.
  const CAP = 1200;                     // 프레임 링버퍼 상한
  const frames = [], events = [];
  let f = 0, raf = 0, disposed = false;
  const now = () => (performance.now() | 0);
  const iceZones = () => { try { return (G._fireZones || []).reduce((n, z) => n + (z && z.type === 'iceStorm' ? 1 : 0), 0); } catch { return -1; } };
  const snap = () => { try { return { aim: !!P._isAiming, mp: +P.mp, stk: +P._isStk, rech: +P._isRech, zones: iceZones(),
    mb0: !!MBjust[0], mb2: !!MBjust[2], esc: !!(K && K.Escape) }; } catch { return null; } };

  // ── DOM 입력 로그 (캡처단계, 무간섭) ──
  const onDown = e => events.push({ k: e.button === 0 ? 'LMB' : e.button === 2 ? 'RMB' : ('B' + e.button), ph: 'down', t: now(), f });
  const onUp   = e => events.push({ k: e.button === 0 ? 'LMB' : e.button === 2 ? 'RMB' : ('B' + e.button), ph: 'up',   t: now(), f });
  const onCtx  = () => events.push({ k: 'contextmenu', ph: 'fire', t: now(), f });
  addEventListener('mousedown', onDown, { capture: true, passive: true });
  addEventListener('mouseup',   onUp,   { capture: true, passive: true });
  addEventListener('contextmenu', onCtx, { capture: true, passive: true });

  // ── 프레임 샘플 + 지연발동/잔류소비 검출 ──
  let prev = snap();
  const tick = () => {
    if (disposed) return;
    const s = snap();
    if (s) {
      // 이전 프레임 대비 iceStorm 효과 변화
      const dZone = prev ? s.zones - prev.zones : 0;
      const dMp   = prev ? s.mp   - prev.mp   : 0;
      const dStk  = prev ? s.stk  - prev.stk  : 0;
      const installed = dZone > 0;                               // 실제 설치 발생
      const resSpent  = dMp < 0 || dStk < 0;                     // 자원 감소 발생
      // 지연발동 신호: 조준 OFF 상태에서 설치/자원소모가 일어나면 누수(버그)
      const aimWasOff = prev && !prev.aim && !s.aim;
      const flag = (installed || resSpent) && aimWasOff ? 'DELAYED_FIRE?'
                 : (resSpent && !installed) ? 'RESIDUAL_SPEND?'  // 자원만 깎이고 설치 없음
                 : null;
      if (dZone || dMp || dStk || flag || (prev && prev.aim !== s.aim))
        frames.push({ f, t: now(), ...s, dZone, dMp, dStk, flag });
      prev = s;
    }
    f++;
    if (frames.length > CAP) frames.splice(0, frames.length - CAP);
    if (events.length > CAP) events.splice(0, events.length - CAP);
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);

  return {
    mark: label => events.push({ k: 'MARK', label: String(label), t: now(), f }),   // 입력 단계 수동 구분용
    dump: () => ({ head: 'dd3bdc18', sampledFrames: f,
      flags: frames.filter(r => r.flag),
      aimTransitions: frames.filter(r => 'aim' in r),
      events: events.slice(), frames: frames.slice() }),
    dispose: () => { disposed = true; cancelAnimationFrame(raf);
      removeEventListener('mousedown', onDown, { capture: true });
      removeEventListener('mouseup', onUp, { capture: true });
      removeEventListener('contextmenu', onCtx, { capture: true });
      return 'disposed'; }
  };
})();
```

판정 해석(덤프 기준):
- `flags`가 비어 있으면 = 취소 이후 **iceStorm 지연 발동·잔류 자원 소모 없음**(정상). `DELAYED_FIRE?`는 조준 OFF 프레임에서 설치/자원변화 = 버그 신호. `RESIDUAL_SPEND?`는 설치 없이 자원만 감소 = 누수 신호.
- 취소 후 LMB가 `events`에 LMB로 남지만 `frames`에 iceStorm 효과 변화가 없으면 = LMB가 무기 공격으로만 소비됨(설계상 정상, iceStorm 범위 밖). 무기 공격 자체의 발동 확인은 이 관측기의 1차 신호가 아니며, 필요 시 root가 공격 상태 필드로 2차 확인.

## 산출 2 — 입력 순서 명세 (root가 공용 게임 슬롯에서 실행)
전제: KBM, iceStorm 슬롯 장착·습득, MP≥40, 스택≥1, 빈 지역 조준. 각 단계 전 `__iceCancelProbe.mark('X')`.
1. **mark('A') 베이스라인** — 30프레임 무입력. (기준 스냅)
2. **mark('B') 정상 설치 1회** — iceStorm 슬롯키→(조준 ON)→유효 빈 지점 LMB. 기대: `dZone +1, dMp -40, dStk -1, aim OFF`. (관측기가 실제 설치를 포착하는지 확인)
3. **mark('C') 취소→다음프레임 LMB** — 슬롯키(조준 ON)→RMB(취소)→1프레임 이상 경과→LMB. 기대: `flags 공백`, zone/mp/stk 불변, aim False 유지.
4. **mark('D') 동일프레임 경합** — 슬롯키(조준 ON)→같은 프레임 내 RMB 직후 LMB 연속. 기대: 취소 우선, 설치 없음, `flags 공백`.
5. **mark('E') Escape 취소→LMB** — 슬롯키→Escape→LMB. 기대: C와 동일.
6. **mark('F') C 3회 반복** — 간헐 지연발동 포착용. 기대: 전 회차 `flags 공백`.
종료: `const out = __iceCancelProbe.dump(); __iceCancelProbe.dispose();` → `out`을 결과 파일로 저장(root).

## 검수 전제 / 미실행 구분
- **전제(선행 산출)**: 위 JS는 입력 라우트(`MBjust` 엣지·`12765` flush·확정/취소 분기·weapon=mouse0)를 실제 코드에서 대조해 심볼을 정확히 연결한 **읽기 관측기**이며, 지연발동/잔류소비를 결정적으로 표면화하는 1차 신호(zone·mp·stk·aim)를 수집한다.
- **미실행/미검수**: 실제 브라우저 입력·게임 실행·덤프 수집은 **이번에 수행하지 않음**(R조사와 공용 root 순차 슬롯 필요). 무기 공격 라우트의 발동 확정은 2차 관측(별도). 패드 경로·합체(holyIce) 자동 설치 상호작용·전 M5 실플레이는 범위 밖.
- **제약 준수**: Read/Glob/Grep만 사용. 파일/HTML/Git/게임/브라우저/인코딩/빌드/새 팀/trust 변경 없음. 보호 설계(패링·돌진) 무변경. 기존 SKILL18 소스추출 회귀를 반복하지 않음(본 건은 라이브 입력 라우트 계층). 중복 팀 없음.
- **출력 위치**: `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/r-input-20261001/` — 현재 `initial-status.bin`·`initial-team-status.json`만 존재(관측 산출 없음=정상). 위 본문·명세의 파일화는 **root 작성** 소관이며, 나는 본문만 제공한다.

읽기 검토 및 선행 산출 제공 완료로 종료합니다.