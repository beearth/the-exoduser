R-input 20261001 읽기 검수 완료. 필수 문서·실제 입력 코드 경로를 Read/Glob/Grep로 확인하고 검수 설계를 제출합니다. (Read/Glob/Grep만 사용 — 파일/HTML/Git/게임/브라우저/빌드/팀/trust 변경 없음)

## A. 읽은 근거

- `AGENTS.md`(최우선 Mac 재개·총괄 관리 규칙), `docs/0마스터플랜/mac-resume-20261001/item-fallback-evidence/다음작업-감사.md`, 자기팀 대장 `docs/12퍼포먼스·최적화/QA_PERFORMANCE_TEAM_MASTER.md`(§7.4·백로그 **QA-B14/QA-B09**), `game.html` 입력·루프·수거 경로.
- **HEAD 주의**: 사용자 제시 HEAD `dd3bdc18`은 git 미조회(읽기 전용·Git 금지)로 본 세션이 대조하지 않음. 감사 문서의 인수 HEAD는 `7ad4d52c`로 상이 — provenance는 총괄이 확정.
- **지원 QA 하니스**: `test/interactTap.test.js`는 Glob 0건 = **아직 미작성**(root 작성 중). 본 보고는 설계만, root가 작성·실행.

## B. 확정한 입력 계약 (코드 라인 근거)

| 요소 | 실제 동작 | 라인 |
|---|---|---|
| `K[code]` | 엣지(눌림) 플래그. `_chkJust`가 **소비**(`if(K[b]){K[b]=false;return true}`) | 12260, 13678 |
| `KH[code]` | held 플래그. **keyup에서만 해제**, isJust가 소비 안 함. `_chkHeld`=`!!KH[b]`(비소비) | 12261, 13681 |
| keydown | `K[e.code]=true;KH[e.code]=true` — **`e.repeat` 무필터**(R). E(shield) 탭버퍼·T토글은 `!e.repeat` 가드 있음, **R(interact)은 탭버퍼·repeat 가드 둘 다 없음** | 12607·12609·12612 |
| keyup | `K=false;KH=false` | 12723 |
| 고정 스텝 | `while(_acc>=PHYS_STEP){ _gameTime+=PHYS_STEP; update(); _acc-=PHYS_STEP }` — 한 rAF에 update **다중 틱**(경량 5·중량 3·모바일 2틱 catch-up, `_acc` 캡) | 59540~59546 |
| R=interact | `BINDS.interact='KeyR'`. 수거: `if(isJust('interact')&&…){…}` MAP_OBJS/worldItems 루프를 **`break`로 1개만** | 6066, 31278~ |
| 두 번째 호출 | `if(!isJust('interact')&&isHeld('interact'))` — 같은 틱에서 isJust **재호출** | 31406 |
| 테스트베드 훅 | `_btFramePause`/`_btFrameStep`(1틱 허용), `_btSpeedMul`(frameTime 배율) | 59493~59498 |

**핵심 해석(가설, 원인확정 아님)**:
1. **프레임 사이 keyup 유실** — keydown·keyup이 두 update 틱 사이에 끝나면(짧은 탭/긴 프레임) 다음 틱의 `isJust`가 `K=false`를 보고 **수거 누락**. R은 E 같은 탭버퍼가 없어 특히 취약 → 관측된 "R 짧은 입력 일부 씹힘" = **QA-B14/§7.4의 실사용 발현**.
2. **고정 스텝 중복소비 방어** — 다중 틱 catch-up에서도 첫 틱이 `K`를 소비해 1 keydown=1 수거. 단 **같은 틱 내 31278(소비)+31406(재호출)** 조합은 pickup 소비 후 `!isJust→true`·`isHeld→true`로 held 분기 동시 발화 가능 → 별도 확인 대상.
3. **OS 오토리핏 중복** — repeat 가드 없어 600ms hold가 OS repeat 임계(~500ms) 초과 시 추가 keydown→`K=true`→추가 수거 가능.

## C. 검수 설계 (타임라인)

**시나리오 매트릭스** — R 입력폭 `0 / 20 / 50 / 100 ms` + `600ms hold`, 각 ×(정상 프레임 16.7ms / 긴 프레임 주입). 측정 축을 **DOM수신 → K/KH 전이 → isJust/isHeld 반환 → update 틱 수 → bag.length·worldItems.length 델타** 한 시간축으로 정렬.

| 입력폭 | 프레임 조건 | 기대 | 관찰 포인트 |
|---|---|---|---|
| 0ms(keydown+keyup 동일 순간) | 정상 | **수거 0**(틱 전 K 소거) | K true→false가 update 전, isJust=false, bag Δ0 = 유실 재현 |
| 20ms | 정상 | 대개 1 수거(프레임 경계 1회 포함) | 경계 직후/직전 keydown 시 유실 경계값 |
| 50/100ms | 정상 | 1 수거(hold 길이 무관, 리핏 전) | 첫 틱만 isJust=true, 이후 K=false·KH=true |
| 0~100ms | **긴 프레임 주입**(`_btSpeedMul`/부하로 1틱>100ms) | 탭이 틱 간극에 통째로 들어가면 **유실** | §7.4 긴 프레임 유실 직접 재현 |
| 600ms hold | 정상 | 1 수거 + (OS repeat 시) 추가 | e.repeat keydown→K 재set→중복 수거 계수 |

**두 필수 구분**:
- **고정 스텝 중복소비**: 한 rAF에 `_acc`를 2~5틱 쌓아 catch-up을 강제(긴 프레임 후 복귀)하고, 단일 keydown이 **정확히 1회** bag 증가로 끝나는지 + 31406 held 분기가 같은 틱에 동시 발화하는지 계수.
- **프레임 사이 keyup**: keydown→(update 경계)→keyup 순서를 결정적으로 배치해 `K` 소비 전 소거가 일어나는 창을 재현. 탭폭을 프레임타임에 대해 스윕.

**결정적 제어 권고**: 가짜 `performance.now`/`_acc` 주입 또는 `_btFramePause`+`_btFrameStep`로 틱을 1개씩 전진시켜 DOM 이벤트와 update 경계의 상대 순서를 고정. `worldItems`에 1개 드롭을 둔 뒤 R 입력당 `bag.length`·`worldItems.length` 델타로 수거를 판정(수거 로그·SFX.pickup 호출도 보조 계측).

## D. test/interactTap.test.js 설계(root 작성용)

- MAP020 하니스 방식 준용 — game.html에서 AST로 `isJust`/`isHeld`/`_chkJust`/`_chkHeld`/`K`/`KH`/keydown·keyup 핸들러 및 수거 틱 호출부를 **실제 추출**(앵커 부재·중복 시 실패), 통제 시계로 틱을 구동. 기대값 완화·실패 제외 금지.
- 케이스: ①0ms 탭→bag Δ0(유실), ②50/100ms→Δ1, ③다중 틱 catch-up에서 1 keydown→Δ1(중복소비 없음) + 31406 동시발화 유무, ④e.repeat 모사 600ms→추가 수거 계수, ⑤긴 프레임(틱 간극>탭폭)→유실. 각 케이스에 K/KH 전이·isJust/isHeld 반환 시퀀스를 assert.
- 브라우저 실측(실게임 DOM·OS repeat·실제 rAF 지터)은 root 단독 — 테스트는 함수 계약, 브라우저는 실발현.

## E. 검수 전제 vs 미실행 구분

- **전제(코드로 확인됨)**: B표의 라인별 계약, keyup 소거·repeat 무가드·다중 틱 catch-up·수거 1개 break·31406 재호출. §7.4/QA-B14가 동일 메커니즘을 등록(“코드 확인, 실사용 재현 미확보”).
- **미실행(본 세션 안 함)**: 테스트 작성·실행, 브라우저 타임라인 수집, OS 오토리핏 실임계 측정, 긴 프레임 실발현, bag/worldItems 실델타, HEAD/SHA 대조. 전부 root(구현·브라우저) 소유.
- **원인확정 금지**: "R 씹힘"의 실제 빈도·사용자 체감은 미재현이므로 설계 가설일 뿐 결함 확정 아님. PC329ms·성능 게이트와 무관.

## F. 산출/소유 경계

- 출력 위치 `/Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/r-input-20261001` 및 `test/interactTap.test.js`는 **root 작성** — 본 지원은 설계·검수 전제만 제출, 아무 파일도 생성/변경하지 않음. 브라우저 독점은 root.
- 중복 팀·새 trust 변경 없음. QA-B14/§7.4·QA-B09(0ms 탭) 기존 등록과 정합(중복 신규 등록 아님).

구현 후 최종 증거(테스트 TAP·브라우저 타임라인 JSON) 수신 시 읽기 검수로 대조 대기합니다.