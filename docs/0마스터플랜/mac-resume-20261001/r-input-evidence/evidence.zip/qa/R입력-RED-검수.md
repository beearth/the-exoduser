# R 짧은 입력: 소스 회귀 RED — 2026-10-01

## 결과

main/easy 각각 13개, 합계 **26개 중 16 PASS / 10 FAIL**, 종료 코드 1. 생산 파일을 수정하지 않았다. 전부 실제 소스 입력 콜백과 상호작용 분기를 실행한 Node 하니스 결과이며, root의 실브라우저 측정과 구분한다.

| 조건(각 HTML 동일) | 결과 | 해석 |
|---|---|---|
| keydown→keyup→update, 간격 0ms | FAIL: 1개 기대, 0개 획득 | 인위적 같은 시각 경계 검사 |
| keydown→keyup→update, 간격20/50/100ms, 그 사이 update 없음 | 3 FAIL: 모두 0개 | update 공백을 명시적으로 만든 가상 일정. 실제 프레임 정체를 측정한 것이 아님 |
| 같은20/50/100ms에60Hz update 삽입 | 3 PASS: 각1개 | 시간 길이보다 update가 press를 읽기 전에 release되는 순서가 핵심 |
| 한 번 누른 뒤 실제 fixed-step while 4+4+1틱 | PASS:1개,1개,2개 | 한 탭 중복 소비 없음. 기존9틱 홀드 주기 유지 |
| 30틱 정상 홀드(500ms) 뒤501ms repeat=true 주입 | FAIL:4개 기대,5개 | repeat keydown이 K를 다시 true로 하여 hold와 별도 즉시 획득. 기존 동작 후보이며 짧은 탭 원인과 별도 |
| 열린 패널에서 down/up 및 누른 직후 패널 열기→release→닫기 | PASS | 패널 중 획득0, 종료 후 잔류0 |
| 실제 blur/hidden 콜백, visible 콜백 | PASS | blur/hidden은 취소. visible 알림만으로는 취소하지 않음. fresh press 재입력 성공 |
| 바인딩 캡처 repeat/Escape취소, 새 키 지정 | PASS | 캡처 이벤트는 획득0, 이후 새 키 정상 |
| 보조 키 KeyB | PASS | 실제 BINDS2 경로에서1개 획득 |

## 원인과 수정 전 검토

- game.html:12607 / easy:12106: keydown은 K와 KH를 모두 true로 기록한다. repeat 여부와 무관하게 K를 재설정한다.
- game.html:12723 / easy:12222: keyup은 K와 KH를 모두 false로 바꾼다.
- _chkJust는 K의 true만 소비한다. keyup을 먼저 처리하면 다음 update의 isJust('interact')는 false, isHeld도 false이므로 탭/홀드 양쪽 획득 경로가 실행되지 않는다. 정확한 현재 줄 번호는 red-sources.json을 따른다.
- E 전용 _sdTapBuf는 존재하지만 R용 press 보존은 없다. 전체 K semantics를 바꾸면 다른 공격/토글 입력에 영향을 줄 수 있으므로 권하지 않는다.
- 반복 키 실패는 repeat=true를 가상 이벤트로 주입한 결과다. 실제 OS의 반복 시작 시간·빈도는 측정하지 않았다. 이 실패까지 자동으로 이번 수정 범위에 넣지 않는다.

최소 후보는 R 액션 전용 pending press를 새 keydown(!repeat, 게임 활성, 비일시정지, 캡처/튜토리얼/수정키 차단 이후)에 기록하고, keyup은 held만 해제하며 첫 유효 상호작용 검사에서 press를 한 번 소비하는 것이다. 기존 K 경로와 함께 소비할 때 같은 키가 남아 두 번 실행되지 않게 해야 한다. _chkJust 전역 계약·공격 입력·9틱 홀드 주기는 유지한다. 새로운 버퍼는 blur/hidden, 패널 진입·일시정지, 바인딩 캡처/취소·게임 종료 등 경계에서 폐기해 닫은 뒤 유령 획득을 만들지 않아야 한다. 실제 생산 변경은 root의 브라우저 재현과 범위 확정 후 진행한다.

## 하니스 범위

- test/interactTap.test.js 하나만 소유·작성했다. 소스 앵커가 없거나 중복이면 실패한다.
- 양 HTML의 전체 실제 keydown/keyup 콜백, _chkJust/isJust/_chkHeld/isHeld, 패널 열기/닫기/뒤로가기, 바인딩 함수, blur/visibility 등록을 추출했다.
- update 초입 패널 처리·paused 가드, 실제 sp 식, 전체 R탭 및 홀드 블록, loop의 fixed-step while을 AST에서 추출해 실행했다. key 상태→아이템의 picked 변화와 pickupItem 호출을 검증한다.
- 실제 전투·월드 갱신과 렌더링은 생략했다. 픽업 수신 함수·UI 렌더·이펙트는 관측용 대역이다. 가상 시각을 썼으며 실제 sleep/프레임/HTTP/브라우저/OS 키 입력을 실행하지 않았다. 메인 루프의 누적 시간 상한 자체는 이 검사 대상이 아니다.
- 첫 하니스 시도에서 easy가 포탈 검사 없는 isJust('interact') 조건임을 발견하여 정확히1개의 상호작용 IfStatement를 선택하도록 수정했다. 이는 추출기 앵커 결함이며 제품 결함으로 집계하지 않았다. 최종10실패는 모두 값 비교(0 vs1 또는5 vs4)이며 ReferenceError/파싱 오류가 아니다.

## 실행과 문서 인수

작업 디렉터리: /Users/fordeargamers/Projects/exoduser-migration-20261001

`/Users/fordeargamers/.local/node-runtime/node-v24.15.0-darwin-arm64/bin/node --test --test-reporter=tap test/interactTap.test.js`

최종237.28ms. 원본 red.tap, 양 HTML SHA-256·실제 줄 번호 red-sources.json. Git 명령/HTML 수정/브라우저 실행 없음.

SSOT 인수 문구 후보(수정 전 조사 상태): “2026-10-01 R 입력 소스 검사에서 keydown과 keyup 사이 update가 없는 경우 press가 지워지는 경로를 확인했다. 0ms는 인위적 경계,20·50·100ms는 업데이트 공백 통제조건이며 실제 브라우저 재현과 구분한다. 정상60Hz 일정은 통과했다. 생산 수정과 실화면 확인 전 해결 완료로 표기하지 않는다.”
