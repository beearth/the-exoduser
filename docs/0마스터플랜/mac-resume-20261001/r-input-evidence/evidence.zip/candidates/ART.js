/* wa24 타임라인 인수 관측기 (읽기 전용). ?test=1&cutscene=1 _cutSeq='PRO'에서 실행.
   게임 상태·렌더 경로 변경 없음. 순수 전역 읽기 + 순수 함수(_ease.out,_cutShake) 샘플.
   저장: /Users/fordeargamers/Documents/Codex/2026-10-01/dho/outputs/r-input-20261001/ (root).
   정지: window.__wa24obs.cleanup()  →  요약 JSON 반환. */
(function () {
  if (window.__wa24obs) { console.warn('[wa24obs] 이미 실행 중 — 기존 cleanup 후 재시작'); window.__wa24obs.cleanup(); }
  const g = (n) => { try { return eval(n); } catch (e) { return undefined; } }; // 스크립트 스코프 const/ let 접근
  const EXPECT = { // 소스 대조 기대값 (드리프트 감지)
    wa23: { t: 68200, dur: 5400, img: 'warintro/cin_remember.jpg', fadeIn: 1 },
    wa24: { t: 73600, dur: 2400, img: 'warintro/cin_fallhell_custom.jpg', col: undefined,
            cam: { zs: 1.08, ze: 1.04, ease: 'out' }, vfx: { vig: .5, shake: 1 }, fadeIn: 400 },
    wa25: { t: 76000, dur: 2900, img: null, fadeIn: 400 }
  };
  const PL = g('PROLOGUE_LINES'); const easeOut = (g('_ease') || {}).out;
  const shakeFn = g('_cutShake');
  const model = {}; let modelOk = true;
  if (PL && PL.ko) for (const id of ['wa23', 'wa24', 'wa25']) {
    const L = PL.ko.find((x) => x.id === id), e = EXPECT[id]; const diff = [];
    if (!L) { diff.push('엔트리없음'); }
    else {
      if (L.t !== e.t) diff.push(`t ${L.t}≠${e.t}`);
      if (L.dur !== e.dur) diff.push(`dur ${L.dur}≠${e.dur}`);
      if ((L.img || null) !== (e.img || null)) diff.push(`img ${L.img}≠${e.img}`);
      if (((L.fade || {}).in) !== e.fadeIn) diff.push(`fadeIn ${(L.fade || {}).in}≠${e.fadeIn}`);
      if (id === 'wa24') {
        if ('col' in L) diff.push(`col 지정됨(${L.col}) — 기본 #d8d4cc 기대`);
        const c = L.cam || {}; if (c.zs !== 1.08 || c.ze !== 1.04 || c.ease !== 'out') diff.push('cam 불일치');
        if ((L.vfx || {}).shake !== 1) diff.push('shake≠1');
      }
    }
    model[id] = { ok: !diff.length, diff }; if (diff.length) modelOk = false;
  } else modelOk = false;
  console.log('[wa24obs] 모델 대조', modelOk ? 'PASS' : 'DRIFT', model);

  // 라이브 샘플: 활성 컷·경과·줌·이미지 흔들림. 경계(진입/종료/전환) 1회 로그.
  const samples = []; const marks = {}; let raf = 0, stopped = false, t0wall = performance.now();
  const shakeRange = { xmin: 9, xmax: -9, ymin: 9, ymax: -9, nonzero: 0, n: 0 };
  function activeCut(e) { return PL && PL.ko.find((x) => e >= x.t && e < x.t + x.dur); }
  function tick() {
    if (stopped) return;
    const state = g('_cutsceneState'), start = g('_cutsceneStartMs');
    const now = performance.now();
    if (state === 'INTRO_CUTSCENE' && typeof start === 'number') {
      const e = now - start; const L = activeCut(e);
      if (L) {
        const el = e - L.t, t = Math.min(1, el / (L.dur || 1));
        const cam = L.cam || { zs: 1, ze: 1 };
        const zoom = easeOut ? cam.zs + (cam.ze - cam.zs) * easeOut(t) : null;
        const sk = shakeFn ? shakeFn((L.vfx || {}).shake || 0, now) : { x: 0, y: 0 };
        if (L.id === 'wa24') { // 흔들림 집계 (±2 검증)
          shakeRange.n++; if (sk.x || sk.y) shakeRange.nonzero++;
          shakeRange.xmin = Math.min(shakeRange.xmin, sk.x); shakeRange.xmax = Math.max(shakeRange.xmax, sk.x);
          shakeRange.ymin = Math.min(shakeRange.ymin, sk.y); shakeRange.ymax = Math.max(shakeRange.ymax, sk.y);
        }
        if (!marks['enter_' + L.id]) { marks['enter_' + L.id] = +e.toFixed(0);
          console.log(`[wa24obs] ▶ ${L.id} 진입 seqE=${e.toFixed(0)}ms (t=${L.t}, dur=${L.dur}, fadeIn=${(L.fade || {}).in})`); }
        if (['wa23', 'wa24', 'wa25'].includes(L.id))
          samples.push({ e: +e.toFixed(0), id: L.id, el: +el.toFixed(0), zoom: zoom != null ? +zoom.toFixed(4) : null, sx: sk.x, sy: sk.y });
      }
      if (e >= EXPECT.wa25.t + 400 && marks['enter_wa25'] && !marks.done) { marks.done = 1;
        console.log('[wa24obs] ✔ wa25 블랙 전환 구간 통과 — 수집 종료 가능. cleanup() 호출.'); finish(); return; }
    }
    raf = requestAnimationFrame(tick);
  }
  function summary() {
    return {
      modelCheck: { ok: modelOk, detail: model },
      marks, // 각 컷 진입 seqElapsed(ms): 전환/구간 경계 타임스탬프
      windows: { transition_in_wa24: [73600, 74000], cut_wa24: [73600, 76000], transition_in_wa25: [76000, 76400] },
      shake_wa24: { ...shakeRange, within_pm2: shakeRange.xmin >= -2 && shakeRange.xmax <= 2 && shakeRange.ymin >= -2 && shakeRange.ymax <= 2 },
      subtitle_fixed: { source: 'game.html:60650-60651 자막은 cx.restore() 후 렌더, shake 항 없음', applied: false },
      sampleCount: samples.length, samples: samples.slice(-600)
    };
  }
  function finish() { if (stopped) return; stopped = true; cancelAnimationFrame(raf);
    const s = summary(); window.__wa24obs.result = s; console.log('[wa24obs] 요약', s); return s; }
  window.__wa24obs = { cleanup: finish, snapshot: summary, _samples: samples };
  raf = requestAnimationFrame(tick);
  setTimeout(() => { if (!stopped) { console.warn('[wa24obs] 120s 안전 타임아웃 — 종료'); finish(); } }, 120000);
  console.log('[wa24obs] 시작. wa24(73.6s)까지 재생되면 자동 포착. 수동 종료: window.__wa24obs.cleanup()');
})();
