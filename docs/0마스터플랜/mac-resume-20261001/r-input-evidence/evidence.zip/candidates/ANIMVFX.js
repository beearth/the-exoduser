(() => {
  'use strict';
  const safe=(f,d=null)=>{try{const v=f();return v===undefined?d:v}catch(e){return d}};
  const glObj = safe(()=>GL, null);
  const glPresent = glObj!==null && typeof glObj==='object';
  // contextLost — nullable: GL 객체가 있을 때만 실제 호출, 없으면 null(측정불가). 과거 raw의 fallback true와 구분.
  let contextLost=null, contextLostSource;
  if(glPresent && typeof glObj.isContextLost==='function'){
    contextLost = safe(()=>glObj.isContextLost(), null);
    contextLostSource = (contextLost===null)?'call-threw':'measured';
  } else { contextLostSource = glPresent?'no-isContextLost-method':'GL-null(not-applicable)'; }
  const useGL  = safe(()=>_useGL, null);
  const useGPU = safe(()=>_useGPU, null);
  const backend = useGPU===true?'webgpu':(useGL===true?'webgl2':'canvas2d-or-unknown');
  // WebGL2 인스턴싱 파이프라인 초기화 여부 (§11 GL 플래시 루프 전제)
  const ensGLProg = safe(()=>!!_ensGLProg, null);
  const ensGLVao  = safe(()=>!!_ensGLVao, null);
  const glInstInitialized = glPresent && ensGLProg===true && ensGLVao===true;
  // capability: 격리 캔버스로 WebGL2 "생성 가능성"만 확인(게임 C 미접촉; 일회용 컨텍스트, 게임 상태 불변)
  const glAvailable = safe(()=>!!document.createElement('canvas').getContext('webgl2'), null);
  const options = {
    fpsCap: safe(()=>OPT&&OPT.fpsCap, null), quality: safe(()=>OPT&&OPT.quality, null),
    resScale: safe(()=>OPT&&OPT.resScale, null),
    webgpuParam: safe(()=>new URLSearchParams(location.search).get('webgpu'), null),
    isMac: safe(()=>IS_MAC, null), isElectron: safe(()=>IS_ELECTRON, null),
    navigatorGpu: safe(()=>!!navigator.gpu, null),
    visibility: safe(()=>document.visibilityState, null), hidden: safe(()=>document.hidden, null),
    bootActive: safe(()=>_bootLoadActive, null), warmDone: safe(()=>_ensWarmDone, null),
    gameOn: safe(()=>G&&G.on, null), paused: safe(()=>G&&G.paused, null)
  };
  // 직전 draw 기준 GL 구동 지표(after-draw에서만 신뢰; ens8GLTotal은 프레임 큐 수=비누적)
  const glDrawCounters = { dbgEns8GL: safe(()=>_dbgEns8GL,null), ens8GLTotal: safe(()=>_ens8GLTotal,null), dbgEnsGL: safe(()=>_dbgEnsGL,null) };
  let glAbsenceCause;
  if(backend==='webgl2') glAbsenceCause = glInstInitialized ? (contextLost===true?'webgl2-context-lost':'none(webgl2-active)') : 'webgl2-pipeline-not-initialized';
  else if(backend==='webgpu') glAbsenceCause = 'webgpu-backend-selected (설계상 GL-instancing 비활성; 실패 아님)';
  else glAbsenceCause = (glAvailable===true) ? 'canvas2d-fallback-despite-webgl2-capable' : 'webgl2-unavailable';
  const flashPathReady = backend==='webgl2' && glInstInitialized && contextLost===false
    && options.visibility==='visible' && options.hidden===false && options.bootActive===false && options.warmDone===true;
  return {
    probe:'animvfx-gl-readgate', version:1, readonly:true, mutatedGameState:false, now:safe(()=>performance.now(),null),
    backend, useGL, useGPU, glPresent, glAvailable,
    contextLost, contextLostSource,                 // GL=null → contextLost:null (가짜 true 아님)
    glInstInitialized, ensGLProg, ensGLVao, glDrawCounters, options,
    flashPathReady, glAbsenceCause,
    deathReviveVerdictPremise: flashPathReady
      ? 'GL instancing flash path READY — 정규 옵션으로 사망/부활 첫 draw 수명 캡처 진행 가능'
      : ('GL instancing flash path NOT READY — 사망/부활 GL 수명은 미검수로 남김. cause='+glAbsenceCause),
    macGlForceHint: (options.isMac===true && backend==='webgpu')
      ? 'Mac 기본=WebGPU(_bootRenderer 6029-6031). WebGL2 인스턴싱 플래시 경로 검수는 정규 옵션 ?webgpu=0 으로 GL 백엔드 부팅 시 활성(총괄 순차 실행).'
      : null,
    note:'glAvailable은 격리 캔버스 생성 가능성(capability)일 뿐 게임 백엔드와 무관. contextLost=null=측정불가(GL 미존재). dbgEns8GL/ens8GLTotal은 직전 draw 기준이며 after-draw에서만 신뢰.'
  };
})();
