/* ENEMY R-input 20261001 — 정규 필드 etype3 자연 첫 탄막 관측 프로브 (read-only 관측)
 * 대상: 실행 중 game.html(정규 CH1-1 필드). 강제 windup/상태주입 금지. 밸런스·수치 불변.
 * 근거 라인(game.html HEAD dd3bdc18): 37223 _tickProjCharge / 38852-62 차징개시(idle내부)
 *   / 18860 _fireChargedProj→spawnProj(_commit) / 39567 _spawnBossProjectile(에지,별건)
 *   / 29361 ETYPE_RANGE[3]=200 / 29644-46 projCd=240 / 29657 projT0∈[180,300]
 * 기존 enemy.test.js 6검사(강제windup edge/단일 idle301/eCircle)와 중복 아님:
 *   본 프로브는 '정규 스폰 실인스턴스'의 차징 하위단계(projT→_projChargeT→fire)를
 *   프레임 단위로 귀속·관측하고 사거리 체류를 판정에 반영한다. */
(function (root) {
  if (root.__ET3_PROBE) { try { root.__ET3_PROBE.stop(); } catch (e) {} }
  var P = {
    KEY: 'et3-natural-firstfire',
    startedFrame: null, target: null, targetTag: 0,
    spawn: null,            // 최초 포착 스냅샷
    projTStart: null,       // projT가 0을 하향 교차해 차징 개시된 프레임
    chargeStartFrame: null, chargeStartD: null, chargeStartProjChargeT: null,
    firstFire: null,        // 첫 발사 이벤트
    edgeFire: null,         // 에지 경로(_spawnBossProjectile) 발사 있으면 기록
    inRangeTicks: 0,        // d<ETYPE_RANGE[3] 체류 tick
    aliveTicks: 0, frozenTicks: 0, stunnedTicks: 0,
    sampleStates: {},       // 관측된 e.s 분포
    dHistory: [],           // (tick,d,s,projT,projChargeT) 희소 기록
    raf: 0, wrapped: {}, done: false, err: null
  };

  function g(n) { return (typeof root[n] === 'function') ? root[n] : null; }
  function curFrame() { return (root.G && typeof root.G.frame === 'number') ? root.G.frame : -1; }
  function distToP(e) {
    var pl = root.P; if (!pl) return Infinity;
    return Math.hypot(pl.x - e.x, pl.y - e.y);
  }
  function range3() {
    try { return (root.ETYPE_RANGE && root.ETYPE_RANGE[3]) || 200; } catch (e) { return 200; }
  }
  // 정규 스폰된 자연 etype3 1마리 고정(보스/레어/디코이/강제상태 제외)
  function findTargetEt3() {
    var ens = root.ens; if (!Array.isArray(ens)) return null;
    for (var i = 0; i < ens.length; i++) {
      var e = ens[i];
      if (e && e.alive && e.etype === 3 && !e.ib && !e._isRare && !e._isDecoy) return e;
    }
    return null;
  }

  function wrap(name, make) {
    var orig = g(name); if (!orig) { P.wrapped[name] = false; return; }
    P.wrapped[name] = orig;
    root[name] = make(orig);
  }

  P.install = function () {
    P.startedFrame = curFrame();
    var R = range3();

    // 차징 발사(정상 경로): _fireChargedProj(e) — e 전달받음 → 귀속 가능
    wrap('_fireChargedProj', function (orig) {
      return function (e) {
        if (!P.done && e && e === P.target && !P.firstFire) {
          P.firstFire = {
            path: 'charged(spawnProj _commit)',
            frame: curFrame(), tickSinceInstall: curFrame() - P.startedFrame,
            tickSinceChargeStart: P.chargeStartFrame != null ? curFrame() - P.chargeStartFrame : null,
            s: e.s, projChargeT: e._projChargeT, projCd: e.projCd,
            bean: e._projChargeBean || null, el: e.el, d: distToP(e)
          };
        }
        return orig.apply(this, arguments);   // 원함수 그대로 호출(상태 불변)
      };
    });
    // 에지 발사(강제/eCircle→windup→attack 경로): _spawnBossProjectile(e,shot)
    wrap('_spawnBossProjectile', function (orig) {
      return function (e, shot) {
        if (!P.done && e && e === P.target && !P.edgeFire) {
          P.edgeFire = { path: 'edge(_spawnBossProjectile)', frame: curFrame(),
            s: e.s, d: distToP(e) };
        }
        return orig.apply(this, arguments);
      };
    });

    var R2 = R * R, lastProjT = null;
    function sample() {
      if (P.done) return;
      try {
        var e = P.target && P.target.alive ? P.target : findTargetEt3();
        if (e && e !== P.target) {              // 최초 포착 1회 고정
          P.target = e;
          P.spawn = { frame: curFrame(), s: e.s, projCd: e.projCd, projT0: e.projT,
            st2: e.st2, el: e.el, d: distToP(e), x: e.x, y: e.y };
          lastProjT = e.projT;
        }
        if (P.target) {
          var tgt = P.target, d = distToP(tgt), f = curFrame();
          P.aliveTicks += tgt.alive ? 1 : 0;
          if (tgt.alive && d < R) P.inRangeTicks++;
          if ((tgt._frozen || 0) > 0) P.frozenTicks++;
          if ((tgt.stunned || 0) > 0) P.stunnedTicks++;
          P.sampleStates[tgt.s] = (P.sampleStates[tgt.s] || 0) + 1;
          // projT 0 하향 교차 = 차징 개시 프레임 귀속
          if (lastProjT != null && lastProjT > 0 && tgt.projT <= 0 &&
              P.chargeStartFrame == null && (tgt._projChargeT || 0) > 0) {
            P.chargeStartFrame = f; P.chargeStartD = d;
            P.chargeStartProjChargeT = tgt._projChargeT;
          }
          lastProjT = tgt.projT;
          if (P.dHistory.length < 2000 && (f % 15 === 0))
            P.dHistory.push([f, Math.round(d), tgt.s, Math.round(tgt.projT || 0),
              Math.round(tgt._projChargeT || 0)]);
        }
      } catch (err) { P.err = String(err && err.stack || err); }
      P.raf = root.requestAnimationFrame(sample);
    }
    P.raf = root.requestAnimationFrame(sample);
    return { installedAtFrame: P.startedFrame, range: R,
      wrapped: Object.keys(P.wrapped).filter(function (k) { return P.wrapped[k]; }) };
  };

  P.stop = function () {
    P.done = true;
    if (P.raf) { try { root.cancelAnimationFrame(P.raf); } catch (e) {} }
    for (var k in P.wrapped) if (P.wrapped[k]) root[k] = P.wrapped[k];  // 원복
    return P.report();
  };

  // ── 실패/판정 로직 ──
  P.report = function () {
    var R = range3();
    var budget = 300 + 60 + 90;   // projT0 최대300 + 차징60 + 여유90 = 450 tick
    var elapsed = curFrame() - P.startedFrame;
    var v = { verdict: 'INCONCLUSIVE', reasons: [] };

    if (P.err) v.reasons.push('probe_error:' + P.err);
    if (!P.target) { v.verdict = 'FAIL_DETECT'; v.reasons.push('정규 CH1 필드에서 자연 etype3 미포착(스폰/필드 조건 확인 필요, 공격전무로 단정 금지)'); }
    else if (P.firstFire) {
      var okState = P.firstFire.s === 'idle';
      var okPath  = P.firstFire.path.indexOf('charged') === 0;
      var okTick  = P.firstFire.tickSinceChargeStart == null ||
                    (P.firstFire.tickSinceChargeStart >= 55 && P.firstFire.tickSinceChargeStart <= 70);
      if (okState && okPath) {
        v.verdict = 'PASS';
        v.reasons.push('자연 idle→차징→spawnProj(_commit) 첫 탄막 1발 확인');
        if (!okTick) v.reasons.push('주의: 차징→발사 간격이 60f(±) 밖 — ' + P.firstFire.tickSinceChargeStart);
      } else {
        v.verdict = 'FAIL_PATH';
        if (!okState) v.reasons.push('첫 발사시 e.s!==idle (' + P.firstFire.s + ') — 자연경로 아님');
        if (!okPath)  v.reasons.push('첫 발사가 charged 경로 아님(' + P.firstFire.path + ')');
      }
    } else if (P.edgeFire && !P.firstFire) {
      v.verdict = 'FAIL_PATH';
      v.reasons.push('charged 발사 없이 edge(_spawnBossProjectile)만 — 강제/eCircle 경로. 공격전무 재주장 아님');
    } else {
      // 발사 없음: 사거리 체류 있었는가로 결함/정상 구분
      if (P.inRangeTicks >= 120 && P.aliveTicks >= budget && P.frozenTicks === 0 && P.stunnedTicks === 0) {
        v.verdict = 'FAIL_NO_FIRE';
        v.reasons.push('d<' + R + ' 체류 ' + P.inRangeTicks + 'tick·생존 ' + P.aliveTicks +
          'tick인데 차징 발사 0 — 자연 발사 누락(실결함 후보)');
      } else {
        v.verdict = 'INCONCLUSIVE';
        v.reasons.push('사거리 체류 ' + P.inRangeTicks + 'tick/생존 ' + P.aliveTicks +
          'tick/빙결 ' + P.frozenTicks + '/스턴 ' + P.stunnedTicks +
          ' — 미발사가 결함인지 판정 불가(더 오래 사거리 유지 필요)');
      }
    }

    return {
      key: P.KEY, observedAt: new Date().toISOString(),
      gameFrameNow: curFrame(), elapsedTicks: elapsed, range: R, budgetTicks: budget,
      spawnSnapshot: P.spawn, chargeStart: P.chargeStartFrame == null ? null :
        { frame: P.chargeStartFrame, d: Math.round(P.chargeStartD),
          projChargeT: P.chargeStartProjChargeT },
      firstFire: P.firstFire, edgeFire: P.edgeFire,
      residency: { inRangeTicks: P.inRangeTicks, aliveTicks: P.aliveTicks,
        frozenTicks: P.frozenTicks, stunnedTicks: P.stunnedTicks },
      stateHistogram: P.sampleStates, dHistory: P.dHistory,
      wrapped: Object.keys(P.wrapped).filter(function (k) { return P.wrapped[k]; }),
      probeError: P.err, ...v
    };
  };

  root.__ET3_PROBE = P;
  return P;
})(window);
// 사용:  window.__ET3_PROBE.install();  …정규 CH1-1 교전…  JSON.stringify(window.__ET3_PROBE.stop())
