
'use strict';
const $=id=>document.getElementById(id);
const definitions=[['wav','A · 원본 WAV','.wav,audio/wav'],['mp3','B · MP3 256k','.mp3,audio/mpeg'],['ogg','B · OGG q6','.ogg,audio/ogg'],['opus','B · Opus 160k','.opus,audio/ogg']];
const tracks=new Map(), history=[], downloads=new Set();
let active=null, frame=0, serial=0;
function say(message){$('status').textContent=message}
function ready(key){const t=tracks.get(key);return !!(t?.audio&&Number.isFinite(t.audio.duration)&&t.audio.duration>0&&t.ready)}
function refresh(){
  $('play-a').disabled=!ready('wav');$('play-b').disabled=!ready($('candidate').value);
  $('stop').disabled=!active;
  for(const id of ['pre','post','volume'])$(id).disabled=!!active;
}
function finish(reason){
  serial++;cancelAnimationFrame(frame);frame=0;
  if(active){
    active.track.audio.pause();active.track.audio.loop=false;
    active.record.stopReason=reason;active.record.endPosition=active.track.audio.currentTime;
    active.record.stoppedAt=new Date().toISOString();active=null;
  }
  refresh();
}
function release(t){
  if(active?.track===t)finish('파일 교체/해제');
  if(t.audio){t.audio.onloadedmetadata=null;t.audio.onerror=null;t.audio.pause();t.audio.removeAttribute('src');t.audio.load();t.audio=null}
  if(t.url){URL.revokeObjectURL(t.url);t.url=null}
  t.file=null;t.ready=false;t.info.textContent='선택 안 됨';t.info.className='muted';
}
for(const [key,label,accept] of definitions){
  const card=document.createElement('div');card.className='track';
  const name=document.createElement('strong');name.textContent=label;
  const input=document.createElement('input');input.type='file';input.accept=accept;input.id='file-'+key;input.setAttribute('aria-label',label+' 파일 선택');
  const info=document.createElement('p');info.className='muted';info.textContent='선택 안 됨';
  card.append(name,input,info);$('tracks').append(card);
  const t={key,label,input,info,file:null,url:null,audio:null,ready:false};tracks.set(key,t);
  input.addEventListener('change',()=>{
    const file=input.files?.[0];if(!file)return;
    release(t);t.file=file;t.url=URL.createObjectURL(file);
    const a=new Audio();t.audio=a;a.preload='metadata';a.volume=Number($('volume').value);
    info.textContent=file.name+' · 길이 확인 중';
    a.onloadedmetadata=()=>{
      if(t.audio!==a)return;
      t.ready=Number.isFinite(a.duration)&&a.duration>0;
      info.textContent=file.name+' · '+(file.size/1024/1024).toFixed(2)+' MiB · '+(t.ready?a.duration.toFixed(3)+'초':'길이 확인 불가');
      info.className=t.ready?'muted ready':'muted error';
      if(t.ready)say(t.label+' 준비됨. 재생 버튼을 눌러 비교하세요.');refresh();
    };
    a.onerror=()=>{
      if(t.audio!==a)return;
      if(active?.track===t)finish('미디어 오류');t.ready=false;
      info.textContent=file.name+' · 재생 불가 (미디어 오류 '+(a.error?.code??'알 수 없음')+')';info.className='muted error';
      say('선택 파일 또는 브라우저의 오디오 형식 지원을 확인해 주세요.');refresh();
    };
    a.src=t.url;a.load();refresh();
  });
}
async function play(key){
  finish('A/B 전환 또는 다시 듣기');
  const t=tracks.get(key);if(!ready(key)){say('선택 음원이 아직 준비되지 않았습니다.');return}
  const pre=Number($('pre').value),post=Number($('post').value),volume=Number($('volume').value),a=t.audio;
  if(!Number.isFinite(pre)||!Number.isFinite(post)||pre<.2||post<.2||pre>10||post>10||pre+post>=a.duration){say('구간은 각각 0.2~10초이며, 합계가 음원 길이보다 짧아야 합니다.');return}
  const ticket=serial;
  const record={file:t.file.name,format:t.label,duration:a.duration,preSeconds:pre,postSeconds:post,volume,startedAt:new Date().toISOString(),wrapObserved:false};
  history.push(record);active={track:t,record};
  a.volume=volume;a.loop=true;
  refresh();
  try{a.currentTime=a.duration-pre;await a.play()}
  catch(error){if(ticket===serial){finish('재생 실패');say('재생 실패: '+error.message)}return}
  if(ticket!==serial)return;
  let previous=a.currentTime,wrapped=false;
  $('segment').textContent=t.label+' · '+t.file.name+' · '+(a.duration-pre).toFixed(3)+'→'+a.duration.toFixed(3)+'초, 0→'+post.toFixed(3)+'초 · 볼륨 '+volume.toFixed(2);
  say(t.label+' 재생 중 · 끝부분');refresh();
  function tick(){
    if(ticket!==serial||!active)return;
    const now=a.currentTime;$('clock').textContent=now.toFixed(3)+' / '+a.duration.toFixed(3)+' 초';
    if(!a.seeking&&previous-now>.2){wrapped=true;record.wrapObserved=true;say(t.label+' 재생 중 · 시작부분')}
    if(wrapped&&now>=post){finish('접점 구간 완료');say(t.label+' 구간 재생 종료. 실제 들은 점을 기록하세요.');return}
    previous=now;frame=requestAnimationFrame(tick);
  }
  frame=requestAnimationFrame(tick);
}
$('play-a').addEventListener('click',()=>play('wav'));
$('play-b').addEventListener('click',()=>play($('candidate').value));
$('stop').addEventListener('click',()=>{finish('사용자 정지');say('정지했습니다.');});
$('candidate').addEventListener('change',()=>{finish('후보 선택 변경');say('후보 B를 선택했습니다. 재생 버튼을 눌러 주세요.');refresh()});
$('volume').addEventListener('input',()=>{$('volume-value').textContent=Number($('volume').value).toFixed(2)});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&active){finish('탭이 숨겨짐');say('탭이 숨겨져 재생을 정지했습니다. 다시 재생 버튼을 눌러 주세요.')}});
function cleanup(){finish('페이지 닫기/파일 해제');for(const t of tracks.values()){release(t);t.input.value=''}for(const url of downloads)URL.revokeObjectURL(url);downloads.clear();refresh()}
$('clear').addEventListener('click',()=>{cleanup();$('clock').textContent='0.000 / 0.000 초';$('segment').textContent='재생 구간: —';say('파일과 접근 URL을 해제했습니다. 청취 메모는 유지됩니다.')});
window.addEventListener('pagehide',cleanup);
window.addEventListener('pageshow',e=>{if(e.persisted)say('페이지 복귀: 파일을 다시 선택해 주세요. 자동재생은 하지 않습니다.')});
$('save').addEventListener('click',()=>{
  const data={title:'S-02 네메시아 끝→시작 A/B',exportedAt:new Date().toISOString(),automaticQualityVerdict:'미검수 — 자동 음질 판정 없음',
    listener:$('listener').value,deviceAndSystemVolume:$('device').value,notes:$('notes').value,
    settings:{preSeconds:Number($('pre').value),postSeconds:Number($('post').value),volume:Number($('volume').value)},
    files:[...tracks.values()].filter(t=>t.file).map(t=>({role:t.label,name:t.file.name,size:t.file.size,type:t.file.type,lastModified:t.file.lastModified,duration:t.ready?t.audio.duration:null})),history};
  const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
  downloads.add(url);
  const link=document.createElement('a');link.href=url;link.download='S02-loop-listening-notes.json';link.click();
  setTimeout(()=>{URL.revokeObjectURL(url);downloads.delete(url)},1000);
});
refresh();
