// Local QA observation only. No player, enemy, RNG, option, or input writes.
(() => {
  window.__normalFirstKill?.stop('reinstall');
  const start = performance.now(), initialKills = G.kills;
  const rows = [], inputs = [], events = [], restores = [];
  let raf = 0, timer = 0, previousRaf = null, previousDraw = null;
  const snapshot = () => ({ at: performance.now(), kills:G.kills, stage:G.stage,
    on:G.on, paused:G.paused, hp:P.hp, lv:P.lv, x:P.x, y:P.y,
    alive:ens.filter(e=>e.alive).length, hidden:document.hidden, focus:document.hasFocus(),
    gl:_useGL, gpu:_useGPU, boot:_bootLoadActive, warm:_ensWarmDone });
  const api = window.__normalFirstKill = { start, initialKills, rows, inputs, events,
    initial:snapshot(), firstKill:null, end:null, reason:null, stopped:false,
    environment:{url:location.href,ua:navigator.userAgent,viewport:[innerWidth,innerHeight],
      dpr:devicePixelRatio,canvas:[C.width,C.height],options:JSON.parse(JSON.stringify(OPT)),
      bindings:JSON.parse(JSON.stringify(BINDS))},
    stop(reason='manual') {
      if(api.stopped)return api;
      api.end=snapshot();api.reason=reason;api.stopped=true;
      cancelAnimationFrame(raf);clearTimeout(timer);
      for(const restore of restores.reverse())restore();
      window.__qaFirstKill?.stop();
      return api;
    }
  };
  function observeKill(){
    if(!api.firstKill&&G.kills>initialKills)api.firstKill=snapshot();
  }
  function wrap(name,read,write){
    const original=read();
    const wrapped=function(...args){const at=performance.now();
      try{return original.apply(this,args)}
      finally{
        const end=performance.now();const row={kind:name,at,ms:end-at,kills:G.kills,on:G.on,paused:G.paused};
        if(name==='draw'){row.dt=previousDraw===null?null:at-previousDraw;previousDraw=at;}
        rows.push(row);observeKill();
      }
    };
    write(wrapped);restores.push(()=>{if(read()===wrapped)write(original)});
  }
  wrap('update',()=>update,v=>{update=v});wrap('draw',()=>draw,v=>{draw=v});
  for(const kind of ['keydown','keyup','mousedown','mouseup']){
    const fn=e=>inputs.push({kind,at:performance.now(),trusted:e.isTrusted,code:e.code||null,
      button:e.button??null,x:e.clientX??null,y:e.clientY??null,repeat:e.repeat||false});
    addEventListener(kind,fn,true);restores.push(()=>removeEventListener(kind,fn,true));
  }
  for(const kind of ['blur','focus','resize','visibilitychange']){
    const target=kind==='visibilitychange'?document:window;
    const fn=()=>events.push({kind,...snapshot()});
    target.addEventListener(kind,fn);restores.push(()=>target.removeEventListener(kind,fn));
  }
  if(PerformanceObserver.supportedEntryTypes.includes('longtask')){
    const po=new PerformanceObserver(list=>{for(const e of list.getEntries())events.push({kind:'longtask',at:e.startTime,ms:e.duration})});
    po.observe({type:'longtask',buffered:false});restores.push(()=>po.disconnect());
  }
  function frame(at){
    if(api.stopped)return;
    rows.push({kind:'raf',at,dt:previousRaf===null?null:at-previousRaf,kills:G.kills,on:G.on,paused:G.paused});
    previousRaf=at;observeKill();
    if(api.firstKill&&performance.now()-api.firstKill.at>=1500){api.stop('first-kill-plus-1500ms');return;}
    raf=requestAnimationFrame(frame);
  }
  raf=requestAnimationFrame(frame);timer=setTimeout(()=>api.stop('deadline-120s'),120000);
  return {installed:true,initial:api.initial,environment:api.environment};
})();
